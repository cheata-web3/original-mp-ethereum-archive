import { Feature, Service, RevenueModel, TokenInfo } from "../lib";

export const features: Feature[] = [
  {
    id: "feature-1",
    title: "🌐 Multi-Chain Wallet",
    label: "統合ウォレット",
    description: "Ethereum、Solana、Polygon等の主要ブロックチェーンをネイティブサポート。複数チェーンの資産を一元管理。",
    value: "拡張機能不要で、DAppへの接続や資産管理が飛躍的に向上。",
    icon: "🌐",
  },
  {
    id: "feature-2",
    title: "🤖 AI-Powered DeFi",
    label: "AI DeFi支援",
    description: "複雑なDeFiプロトコルをAIが自動分析。最適なイールドファーミングやステーキング戦略を提案。",
    value: "DeFi初心者でも、プロトレーダーレベルの運用が可能。",
    icon: "🤖",
  },
  {
    id: "feature-3",
    title: "🔒 Zero-Knowledge Privacy",
    label: "ゼロ知識証明",
    description: "zk-SNARKsを活用した完全プライベートブラウジング。個人情報を一切漏らさずWeb3を利用。",
    value: "プライバシーを完全に保護しながら、分散型サービスを安全に利用。",
    icon: "🔒",
  },
  {
    id: "feature-4",
    title: "🏛️ DAO Governance",
    label: "分散型ガバナンス",
    description: "ブラウザの機能追加や改善をコミュニティが決定。トークンホルダーによる民主的な意思決定。",
    value: "ユーザー自身がプラットフォームの未来を決める、真の分散型ブラウザ。",
    icon: "🏛️",
  },
];

export const services: Service[] = [
  {
    id: "comm-1",
    title: "📹 Secure Video Call",
    description: "エンドツーエンド暗号化されたビデオ通話。Web3プロジェクトの機密な議論も安全に。",
    icon: "📹",
    btnText: "通話開始 ▶",
    category: "communication",
  },
  {
    id: "comm-2",
    title: "💬 Decentralized Chat",
    description: "分散型メッセージング。中央サーバーに依存しない、検閲耐性のあるコミュニケーション。",
    icon: "📞",
    btnText: "チャット開始 ▶",
    category: "communication",
  },
  {
    id: "comm-3",
    title: "🤖 Web3 AI Assistant",
    description: "DeFi、NFT、DAOの複雑な操作をAIがサポート。初心者でも安心してWeb3を利用可能。",
    icon: "✉️",
    btnText: "AI相談 ▶",
    category: "communication",
  },
  {
    id: "web3-1",
    title: "🛡️ Smart Contract Audit",
    description: "接続前にスマートコントラクトを自動監査。ラグプルやハニーポットから資産を保護。",
    icon: "🔒",
    btnText: "監査開始 ▶",
    category: "web3",
  },
  {
    id: "web3-2",
    title: "📊 DeFi Yield Optimizer",
    description: "複数のDeFiプロトコルを横断して最適なイールドファーミング戦略を自動実行。",
    icon: "📊",
    btnText: "最適化開始 ▶",
    category: "web3",
  },
  {
    id: "web3-3",
    title: "🌐 DApp Discovery",
    description: "厳選されたDAppを安全性とユーザビリティでランキング。新しいプロトコルを安心して発見。",
    icon: "🌐",
    btnText: "DApp探索 ▶",
    category: "web3",
  },
  {
    id: "creative-1",
    title: "🖥️ Web3 Site Builder",
    description: "IPFS対応の分散型Webサイトを簡単作成。ENSドメインとの連携で完全分散型サイトを構築。",
    icon: "🖥️",
    btnText: "サイト作成 ▶",
    badge: "ENS対応",
    category: "creative",
  },
  {
    id: "creative-2",
    title: "🪙 Token Launcher",
    description: "ERC-20トークンの発行からリクイディティ提供まで。コミュニティトークンを簡単にローンチ。",
    icon: "🪙",
    btnText: "トークン発行 ▶",
    category: "creative",
  },
];

export const revenueModels: RevenueModel[] = [
  {
    id: "rev-b1",
    title: "💎 Premium DeFi Tools",
    description: "高度なDeFi分析ツール、MEV保護、ガス最適化などのプレミアム機能を月額サブスクリプションで提供。",
    icon: "💎",
    type: "browser",
  },
  {
    id: "rev-b2",
    title: "🤖 AI Transaction Fees",
    description: "AI支援によるスマートコントラクト監査、最適なDeFi戦略提案の利用に応じた従量課金。",
    icon: "🤖",
    type: "browser",
  },
  {
    id: "rev-b3",
    title: "🏛️ DAO Treasury",
    description: "プラットフォームの成功をコミュニティと共有。DAOトレジャリーからの配当とガバナンス参加。",
    icon: "🏛️",
    type: "browser",
  },
  {
    id: "rev-u1",
    title: "🎯 Web3 Activity Mining",
    description: "DApp利用、トランザクション実行、コミュニティ貢献などのWeb3活動でトークンを獲得。",
    icon: "🎯",
    type: "user",
  },
  {
    id: "rev-u2",
    title: "⛏️ Liquidity Mining",
    description: "ブラウザ内蔵DEXでの流動性提供、ステーキング参加で自動的にリワードを獲得。",
    icon: "⛏️",
    type: "user",
  },
  {
    id: "rev-u3",
    title: "🔗 Referral Protocol",
    description: "新規ユーザー紹介、DApp推薦の成功に応じて、永続的なロイヤリティトークンを獲得。",
    icon: "🔗",
    type: "user",
  },
];

export const tokenInfo: TokenInfo[] = [
  {
    id: "token-1",
    name: "CHEATA Balance",
    value: "1,250.50 CHEATA",
    icon: "🪙",
    btnText: "Manage Wallet",
    isPrimary: true,
  },
  {
    id: "token-2",
    name: "DeFi Rewards",
    value: "+45.75 CHEATA",
    icon: "⛏️",
    btnText: "Claim Rewards",
  },
  {
    id: "token-3",
    name: "Governance Power",
    value: "Tier 3 Voter",
    icon: "🏛️",
    btnText: "Vote on Proposals",
  },
];