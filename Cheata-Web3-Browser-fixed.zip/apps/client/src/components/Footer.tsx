import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  Github,
  Twitter,
  Linkedin,
  Mail,
  ExternalLink,
  Heart
} from "lucide-react";

export function Footer() {
  const navigate = useNavigate();

  const footerLinks = {
    product: [
      { label: "CheatAブラウザ", href: "/" },
      { label: "MPウォレット", href: "/mp-wallet" },
      { label: "MPコインスワップ", href: "/mp-coin-swap" },
      { label: "DApps作成ツール", href: "/dapps-builder" }
    ],
    templates: [
      { label: "NFTマーケットプレイス", href: "/templates/nft-marketplace" },
      { label: "分散型取引所", href: "/templates/dex" },
      { label: "DAO運営ツール", href: "/templates/dao" },
      { label: "ゲーミングプラットフォーム", href: "/templates/gaming-platform" }
    ],
    company: [
      { label: "会社概要", href: "/about" },
      { label: "収益予測", href: "/revenue-forecast" },
      { label: "投資家向け資料", href: "/investor-deck" },
      { label: "ビジネスガイド", href: "/business-guide" }
    ],
    resources: [
      { label: "Web3ベストプラクティス", href: "/best-practices" },
      { label: "トークンエコノミクス", href: "/token-economics" },
      { label: "ダウンロード", href: "/download" },
      { label: "今すぐ試す", href: "/try-now" }
    ]
  };

  const socialLinks = [
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Github, href: "#", label: "GitHub" },
    { icon: Linkedin, href: "#", label: "LinkedIn" },
    { icon: Mail, href: "mailto:contact@cheata-labs.com", label: "Email" }
  ];

  return (
    <footer className="bg-card border-t border-border mt-24">
      <div className="container mx-auto px-6 py-12">
        {/* メインフッターコンテンツ */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-8">
          {/* ブランドセクション */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="relative w-8 h-8 flex items-center justify-center">
                <img 
                  src="/images/777.png" 
                  alt="CheatA Logo" 
                  className="w-8 h-8 object-contain drop-shadow-md z-10"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                    if (fallback) fallback.style.display = 'flex';
                  }}
                />
                <div 
                  className="absolute inset-0 w-auto h-8 flex items-center justify-center text-sm font-bold tracking-tight"
                  style={{ 
                    display: 'none',
                    background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text'
                  }}
                >
                  CheatA
                </div>
              </div>
              <div className="font-brand text-lg font-bold text-primary">
                CheatA Labs
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Web3の未来を創造する革新的なテクノロジー企業
            </p>
            <div className="flex gap-3">
              {socialLinks.map((social, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  size="sm"
                  className="w-8 h-8 p-0"
                  onClick={() => {
                    if (social.href.startsWith('mailto:')) {
                      window.location.href = social.href;
                    } else if (social.href !== '#') {
                      window.open(social.href, '_blank');
                    }
                  }}
                >
                  <social.icon className="w-4 h-4" />
                </Button>
              ))}
            </div>
          </div>

          {/* プロダクト */}
          <div>
            <h3 className="font-semibold mb-4">プロダクト</h3>
            <ul className="space-y-2">
              {footerLinks.product.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => navigate(link.href)}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* テンプレート */}
          <div>
            <h3 className="font-semibold mb-4">テンプレート</h3>
            <ul className="space-y-2">
              {footerLinks.templates.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => navigate(link.href)}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* 会社情報 */}
          <div>
            <h3 className="font-semibold mb-4">会社情報</h3>
            <ul className="space-y-2">
              {footerLinks.company.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => navigate(link.href)}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* リソース */}
          <div>
            <h3 className="font-semibold mb-4">リソース</h3>
            <ul className="space-y-2">
              {footerLinks.resources.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => navigate(link.href)}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* ボトムセクション */}
        <div className="border-t border-border pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>© 2026 CheatA Labs株式会社. All rights reserved.</span>
            </div>
            
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <span>Made with</span>
              <Heart className="w-4 h-4 text-red-500 fill-current" />
              <span>using Klein Blue</span>
            </div>
          </div>
          
          <div className="mt-4 text-center">
            <p className="text-xs text-muted-foreground">
              本サイトは革新的なWeb3技術のデモンストレーションです。
              実際の金融取引や投資判断の際は、十分にご注意ください。
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}