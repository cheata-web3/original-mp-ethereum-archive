import { motion } from "framer-motion";
import { IMAGES } from "@/assets/images";
import { Button } from "@/components/ui/button";
import { ArrowRight, ShieldCheck, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import { useNavigate } from "react-router-dom";

interface HeroSectionProps {
  className?: string;
}

export function HeroSection({ className }: HeroSectionProps) {
  const navigate = useNavigate();

  return (
    <section
      id="hero"
      className={cn(
        "relative min-h-[600px] flex items-center justify-center overflow-hidden py-20",
        className
      )}
    >
      {/* Clean Professional Background */}
      <div className="absolute inset-0 z-0">
        <div className="w-full h-full bg-gradient-to-br from-primary via-primary/90 to-primary" />
        <div className="absolute inset-0 bg-gradient-to-t from-primary/95 via-primary/80 to-primary/90" />
      </div>

      <div className="container relative z-10 mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="max-w-4xl mx-auto"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-8 rounded-full bg-white/10 border border-white/20 backdrop-blur-sm">
            <Zap className="w-4 h-4 text-white/80" />
            <span className="text-base font-medium text-white/80 tracking-wide uppercase">
              Next Generation Web3 Browser
            </span>
          </div>

          <div className="flex items-center justify-center gap-6 mb-6">
            {/* Digital Pioneerブランドロゴ */}
            <div className="relative w-16 h-16 md:w-20 md:h-20 flex items-center justify-center rounded-xl p-3 backdrop-blur-sm border border-purple-500/30">
              <img 
                  src="/images/IMG_1443.png"
                alt="Digital Pioneer" 
                className="w-full h-full object-contain"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  const fallback = target.nextElementSibling as HTMLElement;
                  if (fallback) fallback.style.display = 'flex';
                }}
              />
              <div 
                className="w-full h-full hidden items-center justify-center text-lg md:text-xl font-bold"
                style={{
                  background: 'linear-gradient(135deg, #8B5CF6 0%, #A855F7 50%, #C084FC 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text'
                }}
              >
                DP
              </div>
            </div>
            <div className="relative w-20 h-20 md:w-24 md:h-24 flex items-center justify-center">
              <img 
                src="/images/777.png" 
                alt="CheatA Logo" 
                className="w-20 h-20 md:w-24 md:h-24 object-contain drop-shadow-2xl z-10"
                onLoad={() => console.log('Hero logo loaded successfully')}
                onError={(e) => {
                  console.log('Hero logo failed to load, showing text-based logo');
                  e.currentTarget.style.display = 'none';
                  const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                  if (fallback) fallback.style.display = 'flex';
                }}
              />
              {/* 高品質テキストベースロゴ（フォールバック） */}
              <div 
                className="absolute inset-0 w-auto h-20 md:h-24 flex items-center justify-center text-4xl md:text-5xl font-bold tracking-wide text-white"
                style={{ 
                  display: 'none',
                  fontFamily: '"Inter", "Helvetica Neue", "Arial", sans-serif',
                  fontWeight: '700',
                  letterSpacing: '0.02em',
                  transform: 'skew(-2deg)',
                  textShadow: '0 4px 8px rgba(0, 0, 0, 0.5), 0 0 20px rgba(255, 255, 255, 0.3)'
                }}
              >
                CheatA
              </div>
            </div>
            <h1 className="text-6xl md:text-8xl font-bold tracking-wide text-white drop-shadow-lg" style={{
              fontFamily: '"Inter", "Helvetica Neue", "Arial", sans-serif',
              fontWeight: '700',
              letterSpacing: '0.02em',
              transform: 'skew(-2deg)',
              textShadow: '0 4px 8px rgba(0, 0, 0, 0.5), 0 0 20px rgba(255, 255, 255, 0.3)'
            }}>
              CheatA
            </h1>
          </div>

          <p className="text-xl md:text-2xl text-white/80 mb-4 font-medium">
            へようこそ
          </p>

          <p className="text-2xl md:text-3xl text-white/90 leading-relaxed mb-10 max-w-2xl mx-auto">
            分散型インターネットの真の力を、あなたの手に。<br />
            DeFi、NFT、DAO、DApp——Web3のすべてをシンプルに。
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button 
              size="lg" 
              className="h-16 px-10 text-xl font-semibold group bg-white text-primary hover:bg-white/90"
              onClick={() => {
                // デモページに遷移
                navigate('/demo');
              }}
            >
              今すぐ試す
              <ArrowRight className="ml-2 w-5 h-5 transition-transform group-hover:translate-x-1" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="h-16 px-10 text-xl font-semibold border-white/30 text-white hover:bg-white/10"
              onClick={() => {
                // Web3コンセプトセクションへスクロール
                const web3Section = document.getElementById('web3-concept');
                if (web3Section) {
                  web3Section.scrollIntoView({ behavior: 'smooth' });
                }
              }}
            >
              <ShieldCheck className="mr-2 w-5 h-5" />
              詳細を見る
            </Button>
          </div>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 pt-8 border-t border-white/20"
          >
            {[ 
              { label: "Decentralized", value: "100%" },
              { label: "Security", value: "Bank Grade" },
              { label: "Privacy", value: "Zero Logs" },
              { label: "Web3 Ready", value: "Native" }
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <p className="text-2xl font-bold text-white">{stat.value}</p>
                <p className="text-xs uppercase tracking-widest text-white/60">{stat.label}</p>
              </div>
            ))}
          </motion.div>
        </motion.div>
      </div>

      {/* Decorative elements */}
      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-border to-transparent" />
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
    </section>
  );
}