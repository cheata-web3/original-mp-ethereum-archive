import React, { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  ArrowLeft, ArrowRight, RotateCw, Home as HomeIcon, ShieldCheck,
  MoreVertical, Plus, X, Wallet, Lock, Bot, Search, Star, History,
  Settings, ExternalLink, AlertTriangle, Menu
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/index';
import { WalletModal } from './WalletModal';
import { Footer } from './Footer';
import { Button } from '@/components/ui/button';
import './logo-styles.css';

interface LayoutProps { children: React.ReactNode; }
interface Tab { id: string; title: string; url: string; path: string; }

const HOME_URL = 'https://app.cheata.win/home';
const initialTab: Tab = { id: 'home', title: 'Cheata Home', url: HOME_URL, path: '/home' };

export function Layout({ children }: LayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [tabs, setTabs] = useState<Tab[]>([initialTab]);
  const [activeTab, setActiveTab] = useState('home');
  const [address, setAddress] = useState(HOME_URL);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSecurityOn, setIsSecurityOn] = useState(true);
  const [isEditingAddress, setIsEditingAddress] = useState(false);

  useEffect(() => {
    const current = tabs.find(t => t.id === activeTab);
    if (current && !isEditingAddress) setAddress(current.url);
  }, [activeTab, tabs, isEditingAddress]);

  useEffect(() => {
    const current = tabs.find(t => t.id === activeTab);
    if (!current) return;
    if (location.pathname !== current.path) {
      setTabs(prev => prev.map(t => t.id === activeTab ? { ...t, path: location.pathname, url: `${window.location.origin}${location.pathname}`, title: getTitle(location.pathname) } : t));
    }
  }, [location.pathname]);

  const currentTitle = useMemo(() => getTitle(location.pathname), [location.pathname]);

  const navigateBack = () => window.history.back();
  const navigateForward = () => window.history.forward();
  const reload = () => window.location.reload();
  const goHome = () => navigate('/home');

  const submitAddress = (event: React.FormEvent) => {
    event.preventDefault();
    const value = address.trim();
    if (!value) return;
    setIsEditingAddress(false);
    try {
      const url = new URL(value.includes('://') ? value : `https://${value}`);
      if (url.origin === window.location.origin) {
        navigate(url.pathname || '/home');
      } else {
        window.open(url.toString(), '_blank', 'noopener,noreferrer');
      }
    } catch {
      navigate(`/home?search=${encodeURIComponent(value)}`);
    }
  };

  const addTab = () => {
    const id = `tab-${Date.now()}`;
    setTabs(prev => [...prev, { id, title: 'New Tab', url: HOME_URL, path: '/home' }]);
    setActiveTab(id);
    navigate('/home');
  };

  const closeTab = (id: string) => {
    if (tabs.length === 1) return;
    const index = tabs.findIndex(t => t.id === id);
    const next = tabs.filter(t => t.id !== id);
    setTabs(next);
    if (id === activeTab) {
      const fallback = next[Math.max(0, index - 1)];
      setActiveTab(fallback.id);
      navigate(fallback.path);
    }
  };

  const openInternal = (path: string) => {
    navigate(path);
    setIsMenuOpen(false);
  };

  return (
    <div className="flex flex-col h-screen min-h-0 bg-background text-foreground selection:bg-primary/20">
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur">
        <div className="flex items-center gap-2 px-3 py-2">
          <button aria-label="Cheata home" onClick={goHome} className="flex shrink-0 items-center gap-2 rounded-xl px-2 py-1 hover:bg-muted transition-colors">
            <div className="w-9 h-9 rounded-lg bg-[#002FA7] text-white grid place-items-center font-black text-sm">C</div>
            <span className="hidden sm:block text-xl font-bold tracking-tight">Cheata</span>
          </button>

          <div className="flex items-center gap-0.5">
            <ToolbarButton ariaLabel="戻る" icon={<ArrowLeft size={17} />} onClick={navigateBack} />
            <ToolbarButton ariaLabel="進む" icon={<ArrowRight size={17} />} onClick={navigateForward} />
            <ToolbarButton ariaLabel="更新" icon={<RotateCw size={17} />} onClick={reload} />
            <ToolbarButton ariaLabel="ホーム" icon={<HomeIcon size={17} />} onClick={goHome} />
          </div>

          <form onSubmit={submitAddress} className="flex-1 min-w-0">
            <div className="group flex items-center gap-2 rounded-xl border border-border bg-muted/50 px-3 py-2 focus-within:bg-background focus-within:ring-2 focus-within:ring-primary/20 transition-all">
              {isSecurityOn ? <Lock size={14} className="text-emerald-500 shrink-0" /> : <Search size={15} className="text-muted-foreground shrink-0" />}
              <input
                aria-label="アドレスバー"
                value={address}
                onFocus={() => setIsEditingAddress(true)}
                onChange={e => setAddress(e.target.value)}
                onBlur={() => setIsEditingAddress(false)}
                className="w-full min-w-0 bg-transparent outline-none text-sm"
                placeholder="Search or enter URL"
              />
              {isSecurityOn && <span className="hidden md:inline text-[10px] font-semibold text-emerald-600">SECURE</span>}
            </div>
          </form>

          <Button variant="outline" size="sm" onClick={() => setIsWalletModalOpen(true)} className="shrink-0 gap-2 rounded-xl">
            <Wallet size={16} /><span className="hidden md:inline">Wallet</span>
          </Button>
          <button aria-label="セキュリティ" onClick={() => setIsSecurityOn(v => !v)} className={cn('shrink-0 rounded-xl p-2 transition-colors', isSecurityOn ? 'bg-emerald-500/10 text-emerald-600' : 'bg-muted text-muted-foreground')}>
            <ShieldCheck size={19} />
          </button>
          <button aria-label="メニュー" onClick={() => setIsMenuOpen(v => !v)} className="shrink-0 rounded-xl p-2 hover:bg-muted"><MoreVertical size={19} /></button>
        </div>

        <div className="flex items-center gap-1 overflow-x-auto px-3 pt-1 no-scrollbar bg-muted/20">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => { setActiveTab(tab.id); navigate(tab.path); }} className={cn('group flex min-w-[150px] max-w-[230px] items-center gap-2 rounded-t-xl border border-b-0 px-3 py-2 text-xs transition-colors', tab.id === activeTab ? 'bg-background text-foreground' : 'border-transparent text-muted-foreground hover:bg-background/60')}>
              <span className="h-2 w-2 rounded-full bg-primary shrink-0" />
              <span className="truncate flex-1 text-left">{tab.id === activeTab ? currentTitle : tab.title}</span>
              {tabs.length > 1 && <X size={13} className="opacity-60 hover:opacity-100" onClick={e => { e.stopPropagation(); closeTab(tab.id); }} />}
            </button>
          ))}
          <button aria-label="新しいタブ" onClick={addTab} className="mb-1 rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-primary"><Plus size={18} /></button>
        </div>
      </header>

      <AnimatePresence>
        {isMenuOpen && (
          <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="absolute right-3 top-[102px] z-[60] w-64 rounded-2xl border border-border bg-background p-2 shadow-2xl">
            <MenuItem icon={<Wallet size={16} />} label="Wallet" onClick={() => { setIsWalletModalOpen(true); setIsMenuOpen(false); }} />
            <MenuItem icon={<Star size={16} />} label="Bookmarks" onClick={() => openInternal('/about')} />
            <MenuItem icon={<History size={16} />} label="History" onClick={() => openInternal('/mp-analytics')} />
            <MenuItem icon={<ShieldCheck size={16} />} label="Security" onClick={() => openInternal('/best-practices')} />
            <MenuItem icon={<Settings size={16} />} label="Settings" onClick={() => openInternal('/about')} />
          </motion.div>
        )}
      </AnimatePresence>

      <main className="flex-1 min-h-0 overflow-y-auto bg-background">
        {children}
        <Footer />
      </main>

      <AnimatePresence>
        {isAiOpen && (
          <motion.aside initial={{ x: 360, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: 360, opacity: 0 }} className="fixed right-4 bottom-24 z-[100] w-[min(390px,calc(100vw-2rem))] rounded-2xl border border-border bg-background shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between border-b p-4"><div className="flex items-center gap-2 font-semibold"><Bot size={18} className="text-primary" /> Cheata AI</div><button onClick={() => setIsAiOpen(false)} className="rounded-lg p-1 hover:bg-muted"><X size={16} /></button></div>
            <div className="space-y-3 p-4 text-sm"><p className="text-muted-foreground">ページ、DApp、コントラクト、トランザクションを確認できます。</p><div className="rounded-xl bg-muted/50 p-3"><div className="flex gap-2"><AlertTriangle size={16} className="text-amber-500" /><span>実際の送金や署名を行う前に、対象と権限を必ず確認してください。</span></div></div><div className="grid grid-cols-2 gap-2"><button className="rounded-xl border p-3 hover:bg-muted">ページを要約</button><button className="rounded-xl border p-3 hover:bg-muted">リスク確認</button></div></div>
          </motion.aside>
        )}
      </AnimatePresence>
      <button aria-label="Cheata AI" onClick={() => setIsAiOpen(v => !v)} className="fixed bottom-7 right-7 z-[90] grid h-14 w-14 place-items-center rounded-full bg-primary text-primary-foreground shadow-xl shadow-primary/30 hover:scale-105 transition-transform">
        <Bot size={27} /><span className="absolute -right-0.5 -top-0.5 h-3.5 w-3.5 rounded-full border-2 border-background bg-emerald-500" />
      </button>

      <WalletModal isOpen={isWalletModalOpen} onClose={() => setIsWalletModalOpen(false)} />
    </div>
  );
}

function ToolbarButton({ icon, onClick, ariaLabel }: { icon: React.ReactNode; onClick: () => void; ariaLabel: string }) {
  return <button aria-label={ariaLabel} onClick={onClick} className="rounded-lg p-2 text-muted-foreground hover:bg-primary/10 hover:text-primary active:scale-90 transition-all">{icon}</button>;
}

function MenuItem({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return <button onClick={onClick} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm hover:bg-muted text-left">{icon}<span>{label}</span><ExternalLink size={13} className="ml-auto opacity-40" /></button>;
}

function getTitle(path: string) {
  const titles: Record<string, string> = {
    '/home': 'Cheata Home', '/mp-wallet': 'Wallet', '/mp-staking': 'Staking', '/mp-defi-dashboard': 'DeFi',
    '/mp-analytics': 'Analytics', '/mp-community': 'Community', '/dapps-builder': 'DApps Builder',
    '/mp-coin-swap': 'Swap', '/polygon-wallet': 'Polygon Wallet', '/best-practices': 'Security'
  };
  return titles[path] || path.split('/').filter(Boolean).pop()?.replaceAll('-', ' ') || 'Cheata';
}
