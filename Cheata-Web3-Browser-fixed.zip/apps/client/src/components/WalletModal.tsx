import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Wallet, CheckCircle, AlertCircle, ExternalLink, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface WalletOption {
  id: string;
  name: string;
  icon: string;
  description: string;
  isInstalled?: boolean;
  installUrl?: string;
}

const walletOptions: WalletOption[] = [
  {
    id: "metamask",
    name: "MetaMask",
    icon: "🦊",
    description: "最も人気のあるEthereumウォレット",
    isInstalled: typeof window !== 'undefined' && !!(window as any).ethereum?.isMetaMask,
    installUrl: "https://metamask.io/download/"
  },
  {
    id: "walletconnect",
    name: "WalletConnect",
    icon: "🔗",
    description: "モバイルウォレットとの接続",
    isInstalled: false,
    installUrl: "https://walletconnect.com/"
  },
  {
    id: "coinbase",
    name: "Coinbase Wallet",
    icon: "🔵",
    description: "Coinbaseの公式ウォレット",
    isInstalled: typeof window !== 'undefined' && !!(window as any).ethereum?.isCoinbaseWallet,
    installUrl: "https://www.coinbase.com/wallet"
  },
  {
    id: "phantom",
    name: "Phantom",
    icon: "👻",
    description: "Solana対応ウォレット",
    isInstalled: typeof window !== 'undefined' && !!(window as any).solana?.isPhantom,
    installUrl: "https://phantom.app/"
  }
];

export function WalletModal({ isOpen, onClose }: WalletModalProps) {
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectedWallet, setConnectedWallet] = useState<string | null>(null);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const connectWallet = async (walletId: string) => {
    setIsConnecting(true);
    setErrorMessage(null);
    
    try {
      if (walletId === "metamask") {
        if (typeof window !== 'undefined' && (window as any).ethereum) {
          const accounts = await (window as any).ethereum.request({
            method: 'eth_requestAccounts'
          });
          
          if (accounts.length > 0) {
            setConnectedWallet("MetaMask");
            setWalletAddress(accounts[0]);
            // 接続成功後、少し待ってからモーダルを閉じる
            setTimeout(() => {
              onClose();
            }, 1500);
          }
        } else {
          window.open("https://metamask.io/download/", "_blank");
        }
      } else if (walletId === "phantom") {
        if (typeof window !== 'undefined' && (window as any).solana) {
          const response = await (window as any).solana.connect();
          setConnectedWallet("Phantom");
          setWalletAddress(response.publicKey.toString());
          setTimeout(() => {
            onClose();
          }, 1500);
        } else {
          window.open("https://phantom.app/", "_blank");
        }
      } else if (walletId === "walletconnect" || walletId === "coinbase") {
        throw new Error(`${walletOptions.find(w => w.id === walletId)?.name || "Wallet"} の実接続SDKは未設定です。デモ接続は行いません。`);
      }
    } catch (error) {
      console.error("ウォレット接続エラー:", error);
      setErrorMessage(error instanceof Error ? error.message : "ウォレット接続に失敗しました。");
    } finally {
      setIsConnecting(false);
    }
  };

  const formatAddress = (address: string) => {
    if (!address) return "";
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wallet className="w-5 h-5" />
            ウォレットを接続
          </DialogTitle>
        </DialogHeader>

        {connectedWallet && walletAddress ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-6"
          >
            <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
            <h3 className="font-semibold text-lg mb-2">接続完了！</h3>
            <p className="text-sm text-muted-foreground mb-1">{connectedWallet}</p>
            <p className="text-xs text-muted-foreground">{formatAddress(walletAddress)}</p>
          </motion.div>
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground text-center mb-4">
              お好みのウォレットを選択してください
            </p>

            {walletOptions.map((wallet) => (
              <Button
                key={wallet.id}
                variant="outline"
                className="w-full h-auto p-4 flex items-center gap-3 hover:bg-muted/50 transition-colors"
                onClick={() => connectWallet(wallet.id)}
                disabled={isConnecting}
              >
                <span className="text-2xl">{wallet.icon}</span>
                <div className="flex-1 text-left">
                  <p className="font-semibold text-sm">{wallet.name}</p>
                  <p className="text-xs text-muted-foreground">{wallet.description}</p>
                </div>
                {!wallet.isInstalled && wallet.installUrl && (
                  <ExternalLink className="w-4 h-4 text-muted-foreground" />
                )}
                {!wallet.isInstalled && (
                  <div className="flex items-center gap-1 text-xs text-orange-500">
                    <AlertCircle className="w-3 h-3" />
                  </div>
                )}
              </Button>
            ))}

            {errorMessage && (
              <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
                {errorMessage}
              </div>
            )}

            {isConnecting && (
              <div className="text-center py-4">
                <div className="inline-flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                  ウォレットに接続中...
                </div>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}