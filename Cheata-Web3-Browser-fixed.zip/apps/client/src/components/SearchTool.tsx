import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { motion } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
interface SearchToolProps {
  className?: string;
}
export function SearchTool({
  className
}: SearchToolProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // 実際の検索エンジンへリダイレクト（例：Google）
      window.location.assign(`https://www.google.com/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };
  return <motion.div initial={{
    opacity: 0,
    y: 20
  }} animate={{
    opacity: 1,
    y: 0
  }} transition={{
    duration: 0.5,
    ease: 'easeOut'
  }} className="w-full max-w-6xl mx-auto pixel-card p-8">
      <div className="text-center mb-8">
        <motion.h1 className="text-4xl md:text-5xl font-brand font-bold text-primary tracking-tight mb-2" initial={{
        opacity: 0
      }} animate={{
        opacity: 1
      }} transition={{
        delay: 0.2
      }}>
          🌐 CheatA Search
        </motion.h1>
        <p className="text-muted-foreground text-lg">
          Web3に関する情報をすばやく検索
        </p>
      </div>

      <form onSubmit={handleSearch} className="relative group">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground transition-colors group-focus-within:text-primary" />
            <Input type="text" placeholder="Web3の世界を安全に検索..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pl-12 h-16 text-xl bg-muted/30 border-2 border-border focus-visible:ring-primary rounded-md transition-all" />
          </div>
          <Button type="submit" className="pixel-button h-16 px-10 text-xl">
            検索
          </Button>
        </div>
      </form>

      <div className="mt-6 flex flex-wrap items-center justify-center gap-4 text-base text-muted-foreground">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span>🔎 Google検索を利用</span>
        </div>
        <div className="hidden sm:block w-px h-4 bg-border" />
        <span className="flex items-center gap-1.5 text-muted-foreground">
          🛡️ Wallet接続はCheata上で明示的に確認
        </span>
      </div>
    </motion.div>;
}