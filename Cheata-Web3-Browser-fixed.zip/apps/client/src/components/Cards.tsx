import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Feature, Service, RevenueModel, TokenInfo, cn } from '@/lib/index';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';

/**
 * 1. FeatureCard - 重要機能を表示するためのカード
 */
interface FeatureCardProps {
  feature: Feature;
  className?: string;
}

export function FeatureCard({ feature, className }: FeatureCardProps) {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/feature/${feature.id}`);
  };

  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
      className={cn('h-full', className)}
    >
      <Card className="h-full border-border bg-card shadow-sm hover:shadow-md transition-all cursor-pointer" onClick={handleClick}>
        <CardHeader className="pb-4">
          <div className="flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-2xl text-primary shadow-inner">
              {feature.icon}
            </div>
            <div className="space-y-1">
              <p className="text-sm font-medium text-primary uppercase tracking-wider">{feature.label}</p>
              <CardTitle className="text-xl font-bold leading-tight">{feature.title}</CardTitle>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-base text-muted-foreground leading-relaxed">
            {feature.description}
          </p>
          <div className="rounded-lg border-l-4 border-primary bg-primary/5 p-3">
            <p className="text-sm font-semibold text-primary mb-1">ユーザー価値</p>
            <p className="text-base font-medium">{feature.value}</p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

/**
 * 2. ServiceCard - 各種サービス（通信、Web3、ツール）を表示するカード
 */
interface ServiceCardProps {
  service: Service;
  className?: string;
}

export function ServiceCard({ service, className }: ServiceCardProps) {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/feature/${service.id}`);
  };

  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
      className={cn('h-full', className)}
    >
      <Card className="h-full flex flex-col items-center text-center p-6 border-border bg-card shadow-sm hover:shadow-lg transition-all cursor-pointer" onClick={handleClick}>
        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-primary to-primary/70 text-3xl text-primary-foreground shadow-lg">
          {service.icon}
        </div>
        <div className="mb-3 flex items-center justify-center gap-2">
          <h3 className="text-xl font-bold">{service.title}</h3>
          {service.badge && (
            <Badge variant="secondary" className="bg-green-500/10 text-green-600 border-green-500/20">
              {service.badge}
            </Badge>
          )}
        </div>
        <p className="mb-6 text-base text-muted-foreground leading-relaxed flex-grow">
          {service.description}
        </p>
        <Button className="w-full font-semibold group text-lg py-3" variant="default">
          {service.btnText}
          <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Button>
      </Card>
    </motion.div>
  );
}

/**
 * 3. RevenueCard - 収益モデルを表示するためのカード
 */
interface RevenueCardProps {
  model: RevenueModel;
  className?: string;
}

export function RevenueCard({ model, className }: RevenueCardProps) {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      className={cn('h-full', className)}
    >
      <Card className="h-full border-none bg-muted/50 hover:bg-muted transition-colors">
        <CardHeader>
          <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-md text-xl">
            {model.icon}
          </div>
          <CardTitle className="text-base font-bold">{model.title}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {model.description}
          </p>
        </CardContent>
      </Card>
    </motion.div>
  );
}

/**
 * 4. TokenCard - トークン残高や報酬ステータスを表示するダッシュボード用カード
 */
interface TokenCardProps {
  info: TokenInfo;
  className?: string;
}

export function TokenCard({ info, className }: TokenCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className={cn('h-full', className)}
    >
      <Card className="h-full text-center border-border bg-card overflow-hidden shadow-sm">
        <div className="p-6">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-2xl text-primary shadow-inner">
            {info.icon}
          </div>
          <h4 className="text-sm font-medium text-muted-foreground mb-1">{info.name}</h4>
          <p className="text-xl font-bold font-mono tracking-tight">{info.value}</p>
        </div>
        <CardFooter className="bg-muted/30 p-4 border-t border-border">
          <Button 
            variant={info.isPrimary ? 'default' : 'secondary'} 
            className="w-full text-xs h-9 font-bold"
          >
            {info.btnText}
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}