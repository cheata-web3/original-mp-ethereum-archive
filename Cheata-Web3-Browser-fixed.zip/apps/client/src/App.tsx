import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { ROUTE_PATHS } from "@/lib/index";
import { Layout } from "@/components/Layout";
import Home from "@/pages/Home";
import HomeIndex from "@/pages/home/Index";
import NotFoundIndex from "@/pages/not-found/Index";
import FeatureDetail from "@/pages/FeatureDetail";
import DemoPage from "@/pages/DemoPage";
import BestPracticesPage from "@/pages/BestPracticesPage";
import CommunicationPage from "@/pages/CommunicationPage";
import DownloadPage from "@/pages/DownloadPage";
import TryNowPage from "@/pages/TryNowPage";
import TokenEconomicsPage from "@/pages/TokenEconomicsPage";
import RevenueForecastPage from "@/pages/RevenueForecastPage";
import InvestorPage from "@/pages/InvestorPage";
import BusinessGuidePage from "@/pages/BusinessGuidePage";
import DAppsBuilderPage from "@/pages/DAppsBuilderPage";
import MPWalletPage from "@/pages/MPWalletPage";
import AboutPage from "@/pages/AboutPage";
import PolygonWalletPage from "@/pages/PolygonWalletPage";
import MPCoinSwapPage from "@/pages/MPCoinSwapPage";
import NFTMarketplaceTemplate from "@/pages/templates/NFTMarketplaceTemplate";
import DEXTemplate from "@/pages/templates/DEXTemplate";
import DAOTemplate from "@/pages/templates/DAOTemplate";
import GamingPlatformTemplate from "@/pages/templates/GamingPlatformTemplate";
import MPStakingPage from "@/pages/MPStakingPage";
import MPDeFiDashboard from "@/pages/MPDeFiDashboard";
import MPAnalyticsPage from "@/pages/MPAnalyticsPage";
import MPCommunityPage from "@/pages/MPCommunityPage";

// Initialize the TanStack Query client for data fetching and caching
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: 1,
    },
  },
});

/**
 * Root component of the Cheata Web3 Browser application.
 * Handles provider configuration, routing, and global layout application.
 */
const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        {/* Global UI notification providers */}
        <Toaster />
        <Sonner />

        <BrowserRouter>
          <Layout>
            <Routes>
            {/* 
              Main Hub Page wrapped in the Browser Layout 
              Layout handles the toolbar, tabs, and navigation controls.
            */}
            <Route
              path={ROUTE_PATHS.HOME}
              element={<Home />}
            />

            {/* Feature Detail Page */}
            <Route
              path="/feature/:id"
              element={<FeatureDetail />}
            />

            {/* Demo Page */}
            <Route
              path="/demo"
              element={<DemoPage />}
            />

            {/* Best Practices Page */}
            <Route
              path="/best-practices"
              element={<BestPracticesPage />}
            />

            {/* Communication Page */}
            <Route
              path="/communication"
              element={<CommunicationPage />}
            />

            {/* Download Page */}
            <Route
              path="/download"
              element={<DownloadPage />}
            />

            {/* Try Now Page */}
            <Route
              path="/try-now"
              element={<TryNowPage />}
            />

            {/* Token Economics Page */}
            <Route
              path="/token-economics"
              element={<TokenEconomicsPage />}
            />

            {/* Revenue Forecast Page */}
            <Route
              path="/revenue-forecast"
              element={<RevenueForecastPage />}
            />

            {/* Investor Page */}
            <Route
              path="/investor-deck"
              element={<InvestorPage />}
            />

            {/* Business Guide Page */}
            <Route
              path="/business-guide"
              element={<BusinessGuidePage />}
            />

            {/* DApps Builder Page */}
            <Route
              path="/dapps-builder"
              element={<DAppsBuilderPage />}
            />

            {/* MP Coin Swap Page */}
            <Route
              path="/mp-coin-swap"
              element={<MPCoinSwapPage />}
            />

            {/* MP Wallet Page */}
            <Route
              path="/mp-wallet"
              element={<MPWalletPage />}
            />

            {/* About Page */}
            <Route
              path="/about"
              element={<AboutPage />}
            />

            {/* Polygon Wallet Page */}
            <Route
              path="/polygon-wallet"
              element={<PolygonWalletPage />}
            />
            
            {/* Template Pages */}
            <Route
              path="/templates/nft-marketplace"
              element={<NFTMarketplaceTemplate />}
            />

            <Route
              path="/templates/dex"
              element={<DEXTemplate />}
            />

            <Route
              path="/templates/dao"
              element={<DAOTemplate />}
            />

            <Route
              path="/templates/gaming-platform"
              element={<GamingPlatformTemplate />}
            />

            {/* MP Enhanced Pages */}
            <Route
              path="/mp-staking"
              element={<MPStakingPage />}
            />

            <Route
              path="/mp-defi-dashboard"
              element={<MPDeFiDashboard />}
            />

            <Route
              path="/mp-analytics"
              element={<MPAnalyticsPage />}
            />

            <Route
              path="/mp-community"
              element={<MPCommunityPage />}
            />
            
            {/* Home Index template page */}
            <Route
              path="/home-index"
              element={<HomeIndex />}
            />

            {/* Not Found Index template page */}
            <Route
              path="/not-found-index"
              element={<NotFoundIndex />}
            />

            {/* Unknown routes should render a real 404 instead of silently masking broken links. */}
            <Route path="*" element={<NotFoundIndex />} />
            </Routes>
          </Layout>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;