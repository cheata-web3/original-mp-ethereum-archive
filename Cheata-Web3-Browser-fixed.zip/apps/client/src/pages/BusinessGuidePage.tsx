import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft, 
  BookOpen,
  Download,
  FileText,
  Lightbulb,
  Target,
  Users,
  Zap,
  Shield,
  Globe,
  BarChart3,
  DollarSign,
  Rocket,
  CheckCircle,
  ArrowRight,
  Play,
  Pause,
  RotateCcw,
  ExternalLink,
  Printer,
  Share2
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function BusinessGuidePage() {
  const navigate = useNavigate();
  const [activeChapter, setActiveChapter] = useState<number>(1);
  const [isReading, setIsReading] = useState(false);

  const chapters = [
    {
      id: 1,
      title: "CheatAブラウザとは",
      icon: Globe,
      sections: [
        "Web3統合ブラウザの概要",
        "主要機能とユニークバリュー",
        "ターゲットユーザー",
        "市場でのポジショニング"
      ]
    },
    {
      id: 2,
      title: "市場機会と成長性",
      icon: BarChart3,
      sections: [
        "Web3市場の現状と将来性",
        "競合分析と差別化要因",
        "TAM/SAM/SOM分析",
        "成長戦略とロードマップ"
      ]
    },
    {
      id: 3,
      title: "ビジネスモデル詳細",
      icon: DollarSign,
      sections: [
        "9つの収益源の詳細解説",
        "収益構造と安定性",
        "価格戦略とマネタイゼーション",
        "スケーラビリティ分析"
      ]
    },
    {
      id: 4,
      title: "技術アーキテクチャ",
      icon: Zap,
      sections: [
        "システム設計と技術スタック",
        "セキュリティとプライバシー",
        "スケーラビリティとパフォーマンス",
        "AI統合とイノベーション"
      ]
    },
    {
      id: 5,
      title: "財務予測と投資",
      icon: Target,
      sections: [
        "3年間収益予測モデル",
        "投資計画と資金調達",
        "ROI分析とリスク評価",
        "エグジット戦略"
      ]
    },
    {
      id: 6,
      title: "実装ガイド",
      icon: Rocket,
      sections: [
        "開発フェーズと実装計画",
        "チーム構成と採用戦略",
        "マーケティング戦略",
        "パートナーシップ戦略"
      ]
    }
  ];

  const chapterContent = {
    1: {
      title: "CheatAブラウザとは",
      content: [
        {
          subtitle: "Web3統合ブラウザの概要",
          text: "CheatAは、従来のWebブラウジングとWeb3機能を完全に統合した次世代ブラウザプラットフォームです。ユーザーは単一のアプリケーションで、Webサイトの閲覧、暗号資産の管理、DeFi取引、NFT売買、分散型コミュニケーションを行うことができます。",
          highlights: [
            "オールインワンWeb3プラットフォーム",
            "シームレスなユーザー体験",
            "エンタープライズグレードのセキュリティ",
            "AI駆動の最適化機能"
          ]
        },
        {
          subtitle: "主要機能とユニークバリュー",
          text: "CheatAの競合優位性は、分散した複数のツールを統合し、一貫したユーザー体験を提供することにあります。従来、ユーザーはMetaMask、Discord、OpenSea、Uniswapなど複数のアプリを使い分ける必要がありましたが、CheatAではすべてが統合されています。",
          highlights: [
            "統合ウォレット管理（マルチチェーン対応）",
            "内蔵DeFiプロトコル（スワップ・レンディング・ステーキング）",
            "NFTマーケットプレイス統合",
            "暗号化コミュニケーション機能",
            "AI投資アドバイザー",
            "プライバシー保護VPN"
          ]
        },
        {
          subtitle: "ターゲットユーザー",
          text: "CheatAは3つの主要ユーザーセグメントをターゲットとしています。それぞれ異なるニーズと価値提案を持ちますが、共通してWeb3エコシステムでの効率性と安全性を求めています。",
          highlights: [
            "Web3初心者：簡単で安全な入門体験を求める",
            "アクティブトレーダー：効率的な取引環境を必要とする",
            "企業・開発者：スケーラブルなWeb3インフラを求める"
          ]
        }
      ]
    },
    2: {
      title: "市場機会と成長性",
      content: [
        {
          subtitle: "Web3市場の現状と将来性",
          text: "Web3市場は急速に成長しており、2026年までに全世界で10億人のユーザーに達すると予測されています。DeFi市場は年率150%、NFT市場は年率200%の成長を続けており、この成長トレンドは今後5年間継続すると見込まれています。",
          highlights: [
            "Web3ユーザー数：4.2億人 → 10億人（2026年）",
            "DeFi市場規模：$2,400億 → $8,000億（2028年）",
            "NFT取引高：$230億 → $800億（2027年）",
            "Web3ブラウザ市場：$50億 → $300億（2029年）"
          ]
        },
        {
          subtitle: "競合分析と差別化要因",
          text: "現在の主要競合はMetaMask（ウォレット）、Brave（ブラウザ）、Discord（コミュニケーション）ですが、これらは単一機能に特化しています。CheatAの統合アプローチは、ユーザーの切り替えコストを削減し、より効率的なワークフローを提供します。",
          highlights: [
            "MetaMask：ウォレット機能のみ、UX課題あり",
            "Brave：プライバシー重視だがWeb3統合不十分",
            "Opera Crypto：基本的な統合のみ、機能限定的",
            "CheatA：完全統合、AI最適化、エンタープライズ対応"
          ]
        }
      ]
    },
    3: {
      title: "ビジネスモデル詳細",
      content: [
        {
          subtitle: "9つの収益源の詳細解説",
          text: "CheatAは多様化された収益モデルにより、市場変動に対する耐性と持続的な成長を実現します。各収益源は相互に補完し合い、ユーザーの成長と共にスケールします。",
          highlights: [
            "サブスクリプション（21.1%）：予測可能な継続収益",
            "広告収益（20.8%）：プライバシー保護型広告",
            "DAppストア（19.5%）：プラットフォーム手数料",
            "NFT取引手数料（11.5%）：高成長市場での収益",
            "B2B/エンタープライズ（8.7%）：高単価顧客",
            "その他手数料（18.4%）：取引連動収益"
          ]
        },
        {
          subtitle: "収益構造と安定性",
          text: "収益の30%が安定的なサブスクリプションとB2B収益、40%がエコシステム連動収益、30%が取引連動収益となっており、バランスの取れた構造を実現しています。",
          highlights: [
            "安定収益（30%）：サブスク + B2B",
            "エコシステム収益（40%）：DApp + 広告",
            "取引連動収益（30%）：各種手数料"
          ]
        }
      ]
    },
    4: {
      title: "技術アーキテクチャ",
      content: [
        {
          subtitle: "システム設計と技術スタック",
          text: "CheatAは最新のWeb技術とブロックチェーン技術を組み合わせ、スケーラブルで安全なアーキテクチャを構築しています。マイクロサービス設計により、各機能を独立してスケールできます。",
          highlights: [
            "フロントエンド：React + TypeScript + Electron",
            "バックエンド：Node.js + GraphQL + PostgreSQL",
            "ブロックチェーン：Ethereum + Polygon + Solana",
            "AI/ML：Python + TensorFlow + OpenAI API",
            "インフラ：AWS + Kubernetes + Docker"
          ]
        },
        {
          subtitle: "セキュリティとプライバシー",
          text: "エンタープライズグレードのセキュリティを実装し、ユーザーの資産とプライバシーを最高レベルで保護します。ゼロ知識証明技術により、プライバシーを保護しながら必要な検証を行います。",
          highlights: [
            "ハードウェアセキュリティモジュール（HSM）",
            "マルチシグネチャウォレット",
            "ゼロ知識証明（zk-SNARKs）",
            "エンドツーエンド暗号化",
            "定期的なセキュリティ監査"
          ]
        }
      ]
    },
    5: {
      title: "財務予測と投資",
      content: [
        {
          subtitle: "3年間収益予測モデル",
          text: "現実的な成長シナリオに基づき、3年間で累計$24.6M（約37億円）の収益を予測しています。Year 1は基盤構築、Year 2はスケール、Year 3は収益最大化のフェーズです。",
          highlights: [
            "Year 1：$991K（基盤構築期）",
            "Year 2：$5.6M（スケール期）",
            "Year 3：$18.0M（収益最大化期）",
            "3年間累計：$24.6M"
          ]
        },
        {
          subtitle: "投資計画と資金調達",
          text: "段階的な資金調達により、リスクを最小化しながら成長を加速します。各ラウンドで明確なマイルストーンを設定し、投資家に対する透明性を確保します。",
          highlights: [
            "シードラウンド：$5M（現在）",
            "シリーズA：$15M（2027年予定）",
            "シリーズB：$50M（2028年予定）",
            "IPO/M&A：2029-2030年"
          ]
        }
      ]
    },
    6: {
      title: "実装ガイド",
      content: [
        {
          subtitle: "開発フェーズと実装計画",
          text: "アジャイル開発手法を採用し、3ヶ月スプリントで機能を段階的にリリースします。ユーザーフィードバックを継続的に収集し、プロダクトを改善していきます。",
          highlights: [
            "Phase 1：コアブラウザ機能（3ヶ月）",
            "Phase 2：ウォレット統合（3ヶ月）",
            "Phase 3：DeFi機能（6ヶ月）",
            "Phase 4：AI機能（6ヶ月）",
            "Phase 5：エンタープライズ機能（6ヶ月）"
          ]
        },
        {
          subtitle: "チーム構成と採用戦略",
          text: "世界クラスの人材を採用し、分散型チームで開発を進めます。各分野のエキスパートを配置し、効率的な開発体制を構築します。",
          highlights: [
            "開発チーム：15名（フルスタック、ブロックチェーン、AI）",
            "プロダクトチーム：5名（PM、デザイナー、UX）",
            "ビジネスチーム：8名（マーケティング、セールス、BD）",
            "運営チーム：7名（財務、法務、HR、運営）"
          ]
        }
      ]
    }
  };

  const downloadPDF = () => {
    // 実際の実装では、PDFを生成してダウンロード
    alert('CheatAブラウザ ビジネスガイド（PDF版）をダウンロードしました！');
  };

  const printGuide = () => {
    window.print();
  };

  const shareGuide = () => {
    if (navigator.share) {
      navigator.share({
        title: 'CheatAブラウザ ビジネスガイド',
        text: 'Web3の未来を切り開く次世代ブラウザプラットフォーム',
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('URLをクリップボードにコピーしました！');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6 print:hidden">
        <div className="container mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => navigate("/")}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                ホームに戻る
              </Button>
              <div className="font-brand text-2xl font-bold text-primary">
                📖 CheatAブラウザ ビジネスガイド
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={printGuide}>
                <Printer className="w-4 h-4 mr-2" />
                印刷
              </Button>
              <Button variant="outline" size="sm" onClick={shareGuide}>
                <Share2 className="w-4 h-4 mr-2" />
                共有
              </Button>
              <Button size="sm" onClick={downloadPDF}>
                <Download className="w-4 h-4 mr-2" />
                PDF版
              </Button>
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl mt-2">
            Web3の未来を切り開く次世代ブラウザプラットフォームの完全ガイド
          </p>
        </div>
      </header>

      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* サイドバー目次 */}
          <div className="lg:col-span-1 print:hidden">
            <div className="sticky top-6">
              <div className="bg-card rounded-xl p-6 border">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-primary" />
                  目次
                </h3>
                <div className="space-y-2">
                  {chapters.map((chapter) => (
                    <button
                      key={chapter.id}
                      onClick={() => setActiveChapter(chapter.id)}
                      className={cn(
                        "w-full text-left p-3 rounded-lg transition-all flex items-center gap-3",
                        activeChapter === chapter.id
                          ? "bg-primary text-primary-foreground"
                          : "hover:bg-muted"
                      )}
                    >
                      <chapter.icon className="w-4 h-4" />
                      <div>
                        <div className="font-medium text-sm">{chapter.title}</div>
                        <div className="text-xs opacity-70">
                          {chapter.sections.length}セクション
                        </div>
                      </div>
                    </button>
                  ))}
                </div>

                <div className="mt-6 pt-6 border-t">
                  <h4 className="font-semibold mb-3">クイックアクション</h4>
                  <div className="space-y-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full justify-start"
                      onClick={() => navigate('/revenue-forecast')}
                    >
                      <BarChart3 className="w-4 h-4 mr-2" />
                      収益予測
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full justify-start"
                      onClick={() => navigate('/investor-deck')}
                    >
                      <Target className="w-4 h-4 mr-2" />
                      投資家資料
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full justify-start"
                      onClick={() => navigate('/demo')}
                    >
                      <Play className="w-4 h-4 mr-2" />
                      デモ体験
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* メインコンテンツ */}
          <div className="lg:col-span-3">
            <motion.div
              key={activeChapter}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              {/* チャプターヘッダー */}
              <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-8 border border-primary/20">
                <div className="flex items-center gap-4 mb-4">
                  {chapters.find(c => c.id === activeChapter)?.icon && (
                    <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                      {React.createElement(chapters.find(c => c.id === activeChapter)!.icon, {
                        className: "w-6 h-6 text-primary"
                      })}
                    </div>
                  )}
                  <div>
                    <div className="text-sm text-primary font-semibold">
                      Chapter {activeChapter}
                    </div>
                    <h1 className="text-3xl font-bold">
                      {chapterContent[activeChapter as keyof typeof chapterContent]?.title}
                    </h1>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {chapters.find(c => c.id === activeChapter)?.sections.map((section, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span>{section}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* チャプターコンテンツ */}
              <div className="space-y-12">
                {chapterContent[activeChapter as keyof typeof chapterContent]?.content.map((section, index) => (
                  <motion.section
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-card rounded-xl p-8 border"
                  >
                    <h2 className="text-2xl font-bold mb-4 text-primary">
                      {section.subtitle}
                    </h2>
                    <p className="text-muted-foreground mb-6 leading-relaxed">
                      {section.text}
                    </p>
                    
                    <div className="bg-muted/50 rounded-xl p-6">
                      <h3 className="font-semibold mb-4 flex items-center gap-2">
                        <Lightbulb className="w-5 h-5 text-yellow-500" />
                        重要ポイント
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {section.highlights.map((highlight, idx) => (
                          <div key={idx} className="flex items-start gap-2">
                            <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span className="text-sm">{highlight}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.section>
                ))}
              </div>

              {/* ナビゲーション */}
              <div className="flex justify-between items-center pt-8 border-t print:hidden">
                <Button
                  variant="outline"
                  onClick={() => setActiveChapter(Math.max(1, activeChapter - 1))}
                  disabled={activeChapter === 1}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  前のチャプター
                </Button>
                
                <div className="text-sm text-muted-foreground">
                  {activeChapter} / {chapters.length}
                </div>
                
                <Button
                  variant="outline"
                  onClick={() => setActiveChapter(Math.min(chapters.length, activeChapter + 1))}
                  disabled={activeChapter === chapters.length}
                >
                  次のチャプター
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </motion.div>
          </div>
        </div>

        {/* 最終CTA */}
        <section className="mt-16 text-center print:hidden">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-primary to-accent rounded-2xl p-8 text-white"
          >
            <BookOpen className="w-16 h-16 mx-auto mb-6" />
            <h2 className="text-3xl font-bold mb-4">CheatAの詳細を体験しませんか？</h2>
            <p className="mb-6 opacity-90 max-w-2xl mx-auto">
              このガイドで概要を理解したら、実際のプロダクトを体験し、
              投資機会について詳しく相談しましょう
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-white text-primary hover:bg-white/90 h-14 px-8"
                onClick={() => navigate('/demo')}
              >
                <Play className="mr-2 w-5 h-5" />
                デモを体験
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white/30 text-white hover:bg-white/10 h-14 px-8"
                onClick={() => navigate('/investor-deck')}
              >
                <ExternalLink className="mr-2 w-5 h-5" />
                投資家資料
              </Button>
            </div>
          </motion.div>
        </section>
      </div>
    </div>
  );
}