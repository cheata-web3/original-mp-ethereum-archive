import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  Download, 
  Monitor, 
  Smartphone, 
  Apple, 
  Chrome,
  CheckCircle,
  Shield,
  Zap,
  Globe,
  Star,
  Users,
  TrendingUp,
  ExternalLink,
  Copy,
  Check,
  Mail,
  Bell
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function DownloadPage() {
  const navigate = useNavigate();
  const [selectedPlatform, setSelectedPlatform] = useState<'windows' | 'mac' | 'linux' | 'chrome' | 'mobile'>('windows');
  const [email, setEmail] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [downloadStarted, setDownloadStarted] = useState(false);
  const [copied, setCopied] = useState(false);

  const platforms = [
    {
      id: 'windows' as const,
      name: 'Windows',
      icon: Monitor,
      version: 'v1.2.0',
      size: '85 MB',
      requirements: 'Windows 10/11 (64-bit)',
      downloadUrl: '#',
      popular: true
    },
    {
      id: 'mac' as const,
      name: 'macOS',
      icon: Apple,
      version: 'v1.2.0',
      size: '92 MB',
      requirements: 'macOS 11.0 以降',
      downloadUrl: '#',
      popular: false
    },
    {
      id: 'linux' as const,
      name: 'Linux',
      icon: Monitor,
      version: 'v1.2.0',
      size: '78 MB',
      requirements: 'Ubuntu 20.04+ / Fedora 35+',
      downloadUrl: '#',
      popular: false
    },
    {
      id: 'chrome' as const,
      name: 'Chrome拡張',
      icon: Chrome,
      version: 'v1.1.5',
      size: '12 MB',
      requirements: 'Chrome 90+ / Edge 90+',
      downloadUrl: '#',
      popular: true
    },
    {
      id: 'mobile' as const,
      name: 'モバイル',
      icon: Smartphone,
      version: 'v1.0.8',
      size: '45 MB',
      requirements: 'iOS 14+ / Android 8+',
      downloadUrl: '#',
      popular: false
    }
  ];

  const features = [
    {
      icon: Shield,
      title: "エンドツーエンド暗号化",
      description: "すべてのデータが完全に保護されます"
    },
    {
      icon: Zap,
      title: "高速パフォーマンス",
      description: "従来のブラウザより3倍高速"
    },
    {
      icon: Globe,
      title: "Web3ネイティブ",
      description: "DeFi、NFT、DAOを標準サポート"
    }
  ];

  const stats = [
    { label: "アクティブユーザー", value: "2.5M+", icon: Users },
    { label: "平均評価", value: "4.8/5", icon: Star },
    { label: "成長率", value: "+150%", icon: TrendingUp }
  ];

  const handleDownload = () => {
    setDownloadStarted(true);
    
    const selectedPlatformData = platforms.find(p => p.id === selectedPlatform);
    if (!selectedPlatformData) return;

    // 実際のダウンロードファイルを作成
    const createDownloadFile = () => {
      let fileContent = '';
      let fileName = '';
      let mimeType = '';

      switch (selectedPlatform) {
        case 'windows':
          // Windows用のバッチファイル
          fileContent = `@echo off
echo CheatA Browser Installer for Windows
echo Version: ${selectedPlatformData.version}
echo.
echo このファイルはCheatAブラウザのデモインストーラーです。
echo 実際のインストールには公式サイトから最新版をダウンロードしてください。
echo.
echo 公式サイト: https://cheata.app
echo.
pause
start https://cheata.app
`;
          fileName = 'CheatA-Browser-Windows-Setup.bat';
          mimeType = 'application/x-msdos-program';
          break;

        case 'mac':
          // macOS用のシェルスクリプト
          fileContent = `#!/bin/bash
echo "CheatA Browser Installer for macOS"
echo "Version: ${selectedPlatformData.version}"
echo ""
echo "このファイルはCheatAブラウザのデモインストーラーです。"
echo "実際のインストールには公式サイトから最新版をダウンロードしてください。"
echo ""
echo "公式サイト: https://cheata.app"
echo ""
read -p "Enterキーを押して公式サイトを開く..."
open https://cheata.app
`;
          fileName = 'CheatA-Browser-macOS-Setup.sh';
          mimeType = 'application/x-sh';
          break;

        case 'linux':
          // Linux用のシェルスクリプト
          fileContent = `#!/bin/bash
echo "CheatA Browser Installer for Linux"
echo "Version: ${selectedPlatformData.version}"
echo ""
echo "このファイルはCheatAブラウザのデモインストーラーです。"
echo "実際のインストールには以下のコマンドを使用してください："
echo ""
echo "curl -fsSL https://get.cheata.app | sh"
echo ""
echo "または公式サイトから最新版をダウンロードしてください。"
echo "公式サイト: https://cheata.app"
echo ""
read -p "Enterキーを押して公式サイトを開く..."
xdg-open https://cheata.app 2>/dev/null || open https://cheata.app 2>/dev/null || echo "ブラウザで https://cheata.app を開いてください"
`;
          fileName = 'CheatA-Browser-Linux-Setup.sh';
          mimeType = 'application/x-sh';
          break;

        case 'chrome':
          // Chrome拡張機能用のマニフェストファイル
          fileContent = JSON.stringify({
            "manifest_version": 3,
            "name": "CheatA Browser Extension",
            "version": selectedPlatformData.version.replace('v', ''),
            "description": "Web3ネイティブブラウザ拡張機能 - DeFi、NFT、DAOを統合管理",
            "permissions": ["storage", "activeTab", "scripting"],
            "host_permissions": ["<all_urls>"],
            "action": {
              "default_popup": "popup.html",
              "default_title": "CheatA Browser"
            },
            "background": {
              "service_worker": "background.js"
            },
            "content_scripts": [{
              "matches": ["<all_urls>"],
              "js": ["content.js"]
            }],
            "web_accessible_resources": [{
              "resources": ["assets/*"],
              "matches": ["<all_urls>"]
            }],
            "icons": {
              "16": "icons/icon16.png",
              "48": "icons/icon48.png",
              "128": "icons/icon128.png"
            }
          }, null, 2);
          fileName = 'CheatA-Extension-manifest.json';
          mimeType = 'application/json';
          break;

        case 'mobile':
          // モバイル用のAPKダウンロード情報
          fileContent = `CheatA Browser Mobile App
Version: ${selectedPlatformData.version}

このファイルはCheatAブラウザモバイル版のダウンロード情報です。

Android版:
- Google Play Store: https://play.google.com/store/apps/details?id=app.cheata.browser
- 直接ダウンロード: https://releases.cheata.app/android/cheata-browser.apk

iOS版:
- App Store: https://apps.apple.com/app/cheata-browser/id123456789
- TestFlight (ベータ版): https://testflight.apple.com/join/CheatA

システム要件:
- Android: 8.0以上
- iOS: 14.0以上

公式サイト: https://cheata.app
サポート: support@cheata.app
`;
          fileName = 'CheatA-Browser-Mobile-Info.txt';
          mimeType = 'text/plain';
          break;

        default:
          return;
      }

      // ファイルをダウンロード
      const blob = new Blob([fileContent], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    };

    // ダウンロード実行
    setTimeout(() => {
      createDownloadFile();
      setDownloadStarted(false);
      alert(`${selectedPlatformData.name}版のCheatAブラウザファイルをダウンロードしました！`);
    }, 1500);
  };

  const handleSubscribe = () => {
    if (email) {
      setIsSubscribed(true);
      setTimeout(() => {
        setIsSubscribed(false);
      }, 3000);
    }
  };

  const copyInstallCommand = () => {
    const command = selectedPlatform === 'linux' 
      ? 'curl -fsSL https://get.cheata.app | sh'
      : 'npm install -g @cheata/browser';
    navigator.clipboard.writeText(command);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const selectedPlatformData = platforms.find(p => p.id === selectedPlatform);

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="font-brand text-2xl font-bold text-primary">
              CheatA Browser ダウンロード
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            次世代Web3ブラウザをダウンロードして、分散型インターネットの世界を体験しましょう
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-12">
        {/* ヒーローセクション */}
        <section className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Web3の未来を
              <span className="text-primary block">今すぐ体験</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              CheatAブラウザで、DeFi、NFT、DAOの世界に安全かつ簡単にアクセスできます
            </p>
            
            {/* 統計情報 */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-card rounded-xl p-6 border"
                >
                  <stat.icon className="w-8 h-8 text-primary mx-auto mb-3" />
                  <div className="text-2xl font-bold mb-1">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>

        {/* プラットフォーム選択 */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">プラットフォームを選択</h2>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
            {platforms.map((platform) => (
              <motion.button
                key={platform.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSelectedPlatform(platform.id)}
                className={cn(
                  "relative p-6 rounded-xl border-2 transition-all text-left",
                  selectedPlatform === platform.id
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-primary/50"
                )}
              >
                {platform.popular && (
                  <div className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full">
                    人気
                  </div>
                )}
                <platform.icon className="w-8 h-8 text-primary mb-3" />
                <h3 className="font-semibold mb-1">{platform.name}</h3>
                <p className="text-sm text-muted-foreground">{platform.version}</p>
              </motion.button>
            ))}
          </div>

          {/* 選択されたプラットフォームの詳細 */}
          {selectedPlatformData && (
            <motion.div
              key={selectedPlatform}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card rounded-2xl p-8 border"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <div className="flex items-center gap-4 mb-6">
                    <selectedPlatformData.icon className="w-12 h-12 text-primary" />
                    <div>
                      <h3 className="text-2xl font-bold">{selectedPlatformData.name}</h3>
                      <p className="text-muted-foreground">バージョン {selectedPlatformData.version}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-4 mb-6">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">ファイルサイズ:</span>
                      <span className="font-semibold">{selectedPlatformData.size}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">システム要件:</span>
                      <span className="font-semibold">{selectedPlatformData.requirements}</span>
                    </div>
                  </div>

                  <Button
                    size="lg"
                    onClick={handleDownload}
                    disabled={downloadStarted}
                    className="w-full mb-4"
                  >
                    {downloadStarted ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                        ダウンロード中...
                      </>
                    ) : (
                      <>
                        <Download className="w-5 h-5 mr-2" />
                        {selectedPlatformData.name} 版をダウンロード
                      </>
                    )}
                  </Button>

                  {(selectedPlatform === 'linux' || selectedPlatform === 'chrome') && (
                    <div className="bg-muted/50 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-semibold">コマンドラインインストール:</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={copyInstallCommand}
                        >
                          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        </Button>
                      </div>
                      <code className="text-sm bg-background px-3 py-2 rounded block">
                        {selectedPlatform === 'linux' 
                          ? 'curl -fsSL https://get.cheata.app | sh'
                          : 'npm install -g @cheata/browser'
                        }
                      </code>
                    </div>
                  )}
                </div>

                <div>
                  <h4 className="font-semibold mb-4">主な機能</h4>
                  <div className="space-y-4">
                    {features.map((feature, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <feature.icon className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <h5 className="font-semibold">{feature.title}</h5>
                          <p className="text-sm text-muted-foreground">{feature.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="font-semibold text-green-800">安全性保証</span>
                    </div>
                    <p className="text-sm text-green-700">
                      デジタル署名済み・マルウェアスキャン済み・オープンソース
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </section>

        {/* アップデート通知 */}
        <section className="mb-16">
          <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-8 border border-primary/20">
            <div className="text-center mb-6">
              <Bell className="w-12 h-12 text-primary mx-auto mb-4" />
              <h2 className="text-2xl font-bold mb-2">最新情報をお届け</h2>
              <p className="text-muted-foreground">
                新機能やアップデート情報をいち早くお知らせします
              </p>
            </div>
            
            <div className="max-w-md mx-auto">
              <div className="flex gap-2">
                <Input
                  type="email"
                  placeholder="メールアドレスを入力"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1"
                />
                <Button onClick={handleSubscribe} disabled={isSubscribed}>
                  {isSubscribed ? (
                    <>
                      <Check className="w-4 h-4 mr-2" />
                      登録完了
                    </>
                  ) : (
                    <>
                      <Mail className="w-4 h-4 mr-2" />
                      登録
                    </>
                  )}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-2 text-center">
                プライバシーポリシーに同意の上、登録してください
              </p>
            </div>
          </div>
        </section>

        {/* その他のリンク */}
        <section className="text-center">
          <h2 className="text-2xl font-bold mb-8">その他のオプション</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Button
              variant="outline"
              size="lg"
              onClick={() => navigate('/demo')}
              className="h-auto p-6 flex-col gap-3"
            >
              <ExternalLink className="w-8 h-8" />
              <div>
                <div className="font-semibold">オンラインで試す</div>
                <div className="text-sm text-muted-foreground">ダウンロード不要</div>
              </div>
            </Button>
            
            <Button
              variant="outline"
              size="lg"
              onClick={() => window.open('https://github.com/cheata-browser', '_blank')}
              className="h-auto p-6 flex-col gap-3"
            >
              <Globe className="w-8 h-8" />
              <div>
                <div className="font-semibold">ソースコード</div>
                <div className="text-sm text-muted-foreground">GitHub で確認</div>
              </div>
            </Button>
            
            <Button
              variant="outline"
              size="lg"
              onClick={() => navigate('/communication')}
              className="h-auto p-6 flex-col gap-3"
            >
              <Users className="w-8 h-8" />
              <div>
                <div className="font-semibold">コミュニティ</div>
                <div className="text-sm text-muted-foreground">サポート・議論</div>
              </div>
            </Button>
          </div>
        </section>
      </main>
    </div>
  );
}