import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ExternalLink, Shield, Zap, Globe, Database } from "lucide-react";
import { features, services } from "@/data/index";

export default function FeatureDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  // 機能またはサービスを検索
  const feature = features.find(f => f.id === id);
  const service = services.find(s => s.id === id);
  const item = feature || service;

  if (!item) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">機能が見つかりません</h1>
          <Button onClick={() => navigate("/")}>
            <ArrowLeft className="mr-2 w-4 h-4" />
            ホームに戻る
          </Button>
        </div>
      </div>
    );
  }

  const getFeatureDetails = (itemId: string) => {
    const details = {
      "feature-1": {
        overview: "複数のブロックチェーンネットワークに対応した統合ウォレット機能です。Ethereum、Polygon、BSC、Arbitrum、Optimismなど主要なEVM互換チェーンをサポートし、一つのインターフェースで全ての資産を管理できます。",
        benefits: [
          "複数チェーンの資産を一元管理",
          "チェーン間のブリッジ機能内蔵",
          "ガス料金の自動最適化",
          "NFTコレクションの統合表示"
        ],
        techSpecs: [
          "対応チェーン: Ethereum, Polygon, BSC, Arbitrum, Optimism",
          "セキュリティ: ハードウェアウォレット対応",
          "API: Web3.js, Ethers.js完全互換",
          "ストレージ: 暗号化されたローカルストレージ"
        ]
      },
      "feature-2": {
        overview: "AI技術を活用してDeFiプロトコルを自動分析し、最適なイールドファーミング戦略を提案します。リスク評価、APY予測、流動性分析を自動で行い、初心者でもプロレベルの運用が可能です。",
        benefits: [
          "AIによる自動リスク評価",
          "リアルタイムAPY最適化",
          "インパーマネントロス予測",
          "ポートフォリオ自動リバランス"
        ],
        techSpecs: [
          "AI エンジン: 機械学習ベースの予測モデル",
          "データソース: 50+のDeFiプロトコル",
          "更新頻度: リアルタイム（1分間隔）",
          "精度: 過去90日間で85%の予測精度"
        ]
      },
      "feature-3": {
        overview: "zk-SNARKs技術を使用した完全プライベートブラウジング機能です。取引履歴、ウォレットアドレス、閲覧履歴を暗号化し、第三者による追跡を完全に防ぎます。",
        benefits: [
          "完全匿名での取引実行",
          "メタデータの暗号化保護",
          "IPアドレスの自動マスキング",
          "ゼロ知識証明による認証"
        ],
        techSpecs: [
          "暗号化: zk-SNARKs + AES-256",
          "ネットワーク: Tor統合サポート",
          "証明生成時間: 平均2.3秒",
          "プライバシーレベル: 軍事グレード"
        ]
      },
      "feature-4": {
        overview: "分散型自律組織（DAO）のガバナンス機能を統合し、コミュニティによる民主的な意思決定を実現します。提案作成、投票、実行まで全てをブラウザ内で完結できます。",
        benefits: [
          "提案の作成と投票が簡単",
          "投票権の自動計算",
          "実行の自動化（Snapshot連携）",
          "ガバナンストークンの管理"
        ],
        techSpecs: [
          "投票システム: Snapshot + Aragon統合",
          "提案タイプ: テキスト、コード実行、資金移動",
          "クォーラム: カスタマイズ可能",
          "実行遅延: セキュリティのため24-72時間"
        ]
      }
    };

    // サービス詳細も追加
    const serviceDetails = {
      "comm-1": {
        overview: "エンドツーエンド暗号化されたビデオ通話機能です。Web3プロジェクトの機密な議論も安全に行えます。P2P接続により、中央サーバーを経由せずに直接通信が可能です。",
        benefits: [
          "完全暗号化された通話",
          "P2P直接接続", 
          "画面共有機能",
          "録画・録音機能"
        ],
        techSpecs: [
          "暗号化: AES-256 + ECDH鍵交換",
          "プロトコル: WebRTC + STUN/TURN",
          "品質: 最大4K解像度対応",
          "遅延: 平均50ms以下"
        ]
      },
      "comm-2": {
        overview: "分散型メッセージングシステムです。中央サーバーに依存しない、検閲耐性のあるコミュニケーションを実現します。IPFS技術を活用してメッセージを分散保存します。",
        benefits: [
          "検閲耐性のあるメッセージング",
          "分散型ストレージ",
          "オフライン同期",
          "グループチャット対応"
        ],
        techSpecs: [
          "ストレージ: IPFS分散ネットワーク",
          "同期: CRDTベースの競合解決",
          "暗号化: Signal Protocolベース",
          "可用性: 99.9%アップタイム"
        ]
      },
      "comm-3": {
        overview: "DeFi、NFT、DAOの複雑な操作をAIがサポートします。自然言語での質問に対して、最適な戦略や操作手順を提案し、初心者でも安心してWeb3を利用できます。",
        benefits: [
          "自然言語での操作支援",
          "リスク評価と警告",
          "最適戦略の提案",
          "24時間対応"
        ],
        techSpecs: [
          "AI モデル: GPT-4ベースのファインチューニング",
          "知識ベース: 1000+のDeFiプロトコル",
          "応答時間: 平均2秒",
          "精度: 95%以上の正確性"
        ]
      },
      "web3-1": {
        overview: "接続前にスマートコントラクトを自動監査し、ラグプルやハニーポットから資産を保護します。静的解析と動的解析を組み合わせた包括的なセキュリティチェックを実行します。",
        benefits: [
          "自動脆弱性検出",
          "ラグプル防止",
          "ハニーポット検出",
          "リアルタイム監視"
        ],
        techSpecs: [
          "解析エンジン: Slither + Mythril統合",
          "検出率: 99.2%の脅威検出",
          "処理時間: 平均15秒",
          "対応チェーン: 20+のEVMチェーン"
        ]
      },
      "web3-2": {
        overview: "複数のDeFiプロトコルを横断して最適なイールドファーミング戦略を自動実行します。リスク調整後リターンを最大化し、ガス効率も考慮した最適化を行います。",
        benefits: [
          "自動戦略実行",
          "リスク分散投資",
          "ガス効率最適化",
          "リアルタイム再配分"
        ],
        techSpecs: [
          "対応プロトコル: 50+のDeFiプラットフォーム",
          "最適化頻度: 1時間ごと",
          "最小投資額: 100 USDC",
          "手数料: 成功報酬の2%"
        ]
      },
      "web3-3": {
        overview: "厳選されたDAppを安全性とユーザビリティでランキングし、新しいプロトコルを安心して発見できます。コミュニティレビューと専門家評価を組み合わせた信頼性の高い情報を提供します。",
        benefits: [
          "安全性評価済みDApp",
          "ユーザビリティランキング",
          "コミュニティレビュー",
          "新着DApp通知"
        ],
        techSpecs: [
          "登録DApp数: 5000+",
          "評価基準: 50項目の多角的評価",
          "更新頻度: 毎日更新",
          "レビュー数: 100,000+のユーザーレビュー"
        ]
      },
      "creative-1": {
        overview: "IPFS対応の分散型Webサイトを簡単作成できます。ENSドメインとの連携で完全分散型サイトを構築し、検閲耐性のあるWebプレゼンスを実現します。",
        benefits: [
          "完全分散型ホスティング",
          "ENSドメイン統合",
          "検閲耐性",
          "ドラッグ&ドロップエディタ"
        ],
        techSpecs: [
          "ストレージ: IPFS + Filecoin",
          "ドメイン: ENS完全対応",
          "テンプレート: 100+のデザイン",
          "カスタムコード: HTML/CSS/JS対応"
        ]
      },
      "creative-2": {
        overview: "ERC-20トークンの発行からリクイディティ提供まで、コミュニティトークンを簡単にローンチできます。法的コンプライアンスチェックも含む包括的なトークン作成プラットフォームです。",
        benefits: [
          "ワンクリックトークン発行",
          "自動リクイディティ提供",
          "コンプライアンスチェック",
          "マーケティング支援"
        ],
        techSpecs: [
          "対応規格: ERC-20, ERC-721, ERC-1155",
          "発行コスト: 0.1 ETH + ガス代",
          "監査: 自動セキュリティ監査付き",
          "サポート: 24時間技術サポート"
        ]
      }
    };

    return details[itemId as keyof typeof details] || serviceDetails[itemId as keyof typeof serviceDetails] || {
      overview: "この機能の詳細情報を準備中です。",
      benefits: ["高度なWeb3機能", "セキュアな実装", "ユーザーフレンドリー"],
      techSpecs: ["最新技術スタック", "高いセキュリティ", "スケーラブル設計"]
    };
  };

  const details = getFeatureDetails(item.id);

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="font-brand text-xl font-bold text-primary">
              CheatA
            </div>
          </div>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          {/* ヒーローセクション */}
          <div className="text-center mb-12">
            <div className="text-6xl mb-4">{item.icon}</div>
            <h1 className="font-brand text-4xl md:text-5xl font-bold mb-4">
              {item.title}
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              {item.description}
            </p>
          </div>

          {/* 概要セクション */}
          <section className="mb-12">
            <div className="bg-card border border-border rounded-2xl p-8">
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Globe className="w-6 h-6 text-primary" />
                機能概要
              </h2>
              <p className="text-lg leading-relaxed text-muted-foreground">
                {details.overview}
              </p>
            </div>
          </section>

          {/* 主な利点 */}
          <section className="mb-12">
            <div className="bg-card border border-border rounded-2xl p-8">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <Zap className="w-6 h-6 text-primary" />
                主な利点
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {details.benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                    <div className="w-2 h-2 bg-primary rounded-full" />
                    <span className="font-medium">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* 技術仕様 */}
          <section className="mb-12">
            <div className="bg-card border border-border rounded-2xl p-8">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <Database className="w-6 h-6 text-primary" />
                技術仕様
              </h2>
              <div className="space-y-3">
                {details.techSpecs.map((spec, index) => (
                  <div key={index} className="flex items-start gap-3 p-4 bg-muted/30 rounded-lg">
                    <Shield className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                    <span className="text-sm font-mono">{spec}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* アクションボタン */}
          <section className="text-center">
            <div className="bg-primary/5 border border-primary/20 rounded-2xl p-8">
              <h3 className="text-xl font-bold mb-4">この機能を試してみませんか？</h3>
              <p className="text-muted-foreground mb-6">
                CheatAブラウザをダウンロードして、最新のWeb3機能を体験してください。
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="h-12 px-8" onClick={() => navigate("/download")}>
                  <ExternalLink className="mr-2 w-5 h-5" />
                  今すぐ試す
                </Button>
                <Button size="lg" variant="outline" onClick={() => navigate("/")}>
                  他の機能を見る
                </Button>
              </div>
            </div>
          </section>
        </motion.div>
      </main>
    </div>
  );
}