import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  TrendingUp,
  DollarSign,
  Users,
  BarChart3,
  PieChart,
  LineChart,
  Calculator,
  Target,
  Zap,
  Shield,
  Globe,
  Coins,
  Store,
  CreditCard,
  Smartphone,
  Building,
  AlertTriangle,
  CheckCircle,
  ArrowRight,
  Download,
  ExternalLink,
  Play,
  Pause,
  RotateCcw
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function RevenueForecastPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'overview' | 'detailed' | 'calculator' | 'risks'>('overview');
  const [animationPlaying, setAnimationPlaying] = useState(false);
  const [selectedYear, setSelectedYear] = useState<1 | 2 | 3>(3);
  const [calculatorInputs, setCalculatorInputs] = useState({
    mau: 500000,
    proConversion: 3.5,
    avgTransactionVolume: 500,
    dappCount: 200
  });

  // 収益データ
  const revenueData = {
    year1: {
      mau: 50000,
      dau: 15000,
      proUsers: 750,
      revenues: {
        subscription: 149910,
        defiTradingFees: 36000,
        nftTradingFees: 90000,
        onrampFees: 60000,
        dappStore: 288000,
        advertising: 240000,
        tokenCreation: 52050,
        domainSales: 75000,
        b2b: 0,
        total: 990960
      }
    },
    year2: {
      mau: 200000,
      dau: 60000,
      proUsers: 5000,
      revenues: {
        subscription: 1079400,
        defiTradingFees: 216000,
        nftTradingFees: 600000,
        onrampFees: 360000,
        dappStore: 1200000,
        advertising: 1200000,
        tokenCreation: 267000,
        domainSales: 300000,
        b2b: 420000,
        total: 5642400
      }
    },
    year3: {
      mau: 500000,
      dau: 150000,
      proUsers: 17500,
      revenues: {
        subscription: 3897900,
        defiTradingFees: 675000,
        nftTradingFees: 2100000,
        onrampFees: 1200000,
        dappStore: 3240000,
        advertising: 3600000,
        tokenCreation: 814500,
        domainSales: 750000,
        b2b: 1680000,
        total: 17957400
      }
    }
  };

  const revenueCategories = [
    {
      id: 'subscription',
      name: 'サブスクリプション',
      icon: CreditCard,
      color: 'bg-blue-500',
      description: 'Plus ($9.99/月) & Pro ($29.99/月) プラン',
      percentage: 21.1
    },
    {
      id: 'advertising',
      name: '広告収益',
      icon: Target,
      color: 'bg-green-500',
      description: 'ユーザー同意型プライバシー広告',
      percentage: 20.8
    },
    {
      id: 'dappStore',
      name: 'DAppストア',
      icon: Store,
      color: 'bg-purple-500',
      description: '掲載料・手数料・プロモーション',
      percentage: 19.5
    },
    {
      id: 'nftTradingFees',
      name: 'NFT取引手数料',
      icon: Coins,
      color: 'bg-orange-500',
      description: '2.5% 取引手数料',
      percentage: 11.5
    },
    {
      id: 'b2b',
      name: 'B2B/エンタープライズ',
      icon: Building,
      color: 'bg-indigo-500',
      description: 'API・監査・カスタム統合',
      percentage: 8.7
    },
    {
      id: 'onrampFees',
      name: 'オンランプ手数料',
      icon: Smartphone,
      color: 'bg-cyan-500',
      description: '1.0% 法定通貨変換手数料',
      percentage: 6.7
    },
    {
      id: 'tokenCreation',
      name: 'トークン作成',
      icon: Zap,
      color: 'bg-yellow-500',
      description: '$50/トークン 作成手数料',
      percentage: 4.7
    },
    {
      id: 'domainSales',
      name: 'ドメイン販売',
      icon: Globe,
      color: 'bg-pink-500',
      description: '.win ドメイン $10/年',
      percentage: 4.6
    },
    {
      id: 'defiTradingFees',
      name: 'DeFi取引手数料',
      icon: TrendingUp,
      color: 'bg-red-500',
      description: '0.15% スワップ・ブリッジ手数料',
      percentage: 3.8
    }
  ];

  const riskFactors = [
    {
      category: '競合リスク',
      level: 'Medium',
      description: 'MetaMask、Brave等との差別化が必要',
      mitigation: 'Web3統合とAI機能での差別化',
      color: 'text-yellow-500'
    },
    {
      category: '規制リスク',
      level: 'High',
      description: '各国の暗号資産規制の変化',
      mitigation: 'コンプライアンス体制の強化',
      color: 'text-red-500'
    },
    {
      category: 'チャーン率',
      level: 'Medium',
      description: 'サブスク解約率が5%超えると危険',
      mitigation: 'ユーザー体験の継続的改善',
      color: 'text-yellow-500'
    },
    {
      category: '運営コスト',
      level: 'Low',
      description: 'AI/VPN/インフラコストの管理',
      mitigation: '効率的なインフラ設計',
      color: 'text-green-500'
    }
  ];

  const calculateCustomRevenue = () => {
    const { mau, proConversion, avgTransactionVolume, dappCount } = calculatorInputs;
    
    // サブスクリプション収益
    const proUsers = Math.floor(mau * (proConversion / 100));
    const plusUsers = Math.floor(proUsers * 0.6); // Pro:Plus = 4:6
    const proOnlyUsers = proUsers - plusUsers;
    const subscriptionRevenue = (plusUsers * 9.99 + proOnlyUsers * 29.99) * 12;
    
    // DeFi取引手数料
    const traders = Math.floor(mau * 0.15);
    const defiRevenue = traders * avgTransactionVolume * 0.0015 * 12;
    
    // DAppストア収益
    const dappRevenue = dappCount * 500 * 12 + dappCount * 1000 * 12;
    
    // 広告収益
    const adUsers = Math.floor(mau * 0.3);
    const adRevenue = adUsers * 2 * 12;
    
    const totalRevenue = subscriptionRevenue + defiRevenue + dappRevenue + adRevenue;
    
    return {
      subscription: subscriptionRevenue,
      defi: defiRevenue,
      dapp: dappRevenue,
      advertising: adRevenue,
      total: totalRevenue,
      proUsers,
      traders,
      adUsers
    };
  };

  const customResults = calculateCustomRevenue();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ja-JP', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('ja-JP').format(num);
  };

  const startAnimation = () => {
    setAnimationPlaying(true);
    setTimeout(() => setAnimationPlaying(false), 3000);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="font-brand text-2xl font-bold text-primary">
              📈 収益予測ダッシュボード
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            CheatAブラウザの3年間収益予測モデル - 現実的な成長シナリオに基づく詳細分析
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-12">
        {/* タブナビゲーション */}
        <div className="flex justify-center mb-12">
          <div className="inline-flex p-1 bg-muted rounded-xl">
            <button
              onClick={() => setActiveTab('overview')}
              className={cn(
                "px-6 py-3 rounded-lg text-sm font-semibold transition-all flex items-center gap-2",
                activeTab === 'overview' 
                  ? "bg-primary text-primary-foreground shadow-lg" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <BarChart3 className="w-4 h-4" />
              概要
            </button>
            <button
              onClick={() => setActiveTab('detailed')}
              className={cn(
                "px-6 py-3 rounded-lg text-sm font-semibold transition-all flex items-center gap-2",
                activeTab === 'detailed' 
                  ? "bg-primary text-primary-foreground shadow-lg" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <PieChart className="w-4 h-4" />
              詳細分析
            </button>
            <button
              onClick={() => setActiveTab('calculator')}
              className={cn(
                "px-6 py-3 rounded-lg text-sm font-semibold transition-all flex items-center gap-2",
                activeTab === 'calculator' 
                  ? "bg-primary text-primary-foreground shadow-lg" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Calculator className="w-4 h-4" />
              ROI計算機
            </button>
            <button
              onClick={() => setActiveTab('risks')}
              className={cn(
                "px-6 py-3 rounded-lg text-sm font-semibold transition-all flex items-center gap-2",
                activeTab === 'risks' 
                  ? "bg-primary text-primary-foreground shadow-lg" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <AlertTriangle className="w-4 h-4" />
              リスク分析
            </button>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {/* 概要タブ */}
          {activeTab === 'overview' && (
            <motion.div
              key="overview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              {/* 3年間サマリー */}
              <section>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold">3年間収益サマリー</h2>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={startAnimation}
                      disabled={animationPlaying}
                    >
                      {animationPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      {animationPlaying ? '再生中' : 'アニメーション'}
                    </Button>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  {[
                    { year: 1, data: revenueData.year1, label: 'Year 1', color: 'from-blue-500 to-cyan-500' },
                    { year: 2, data: revenueData.year2, label: 'Year 2', color: 'from-purple-500 to-pink-500' },
                    { year: 3, data: revenueData.year3, label: 'Year 3', color: 'from-green-500 to-emerald-500' }
                  ].map((item, index) => (
                    <motion.div
                      key={item.year}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ 
                        opacity: 1, 
                        scale: animationPlaying ? [0.9, 1.05, 1] : 1,
                        y: animationPlaying ? [0, -10, 0] : 0
                      }}
                      transition={{ 
                        delay: animationPlaying ? index * 0.3 : 0,
                        duration: animationPlaying ? 0.8 : 0.3
                      }}
                      className={cn(
                        "relative overflow-hidden rounded-2xl p-6 text-white bg-gradient-to-br",
                        item.color
                      )}
                    >
                      <div className="relative z-10">
                        <h3 className="text-lg font-semibold mb-2">{item.label}</h3>
                        <div className="text-3xl font-bold mb-4">
                          {formatCurrency(item.data.revenues.total)}
                        </div>
                        <div className="space-y-2 text-sm opacity-90">
                          <div className="flex justify-between">
                            <span>MAU:</span>
                            <span>{formatNumber(item.data.mau)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Proユーザー:</span>
                            <span>{formatNumber(item.data.proUsers)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>成長率:</span>
                            <span>
                              {index === 0 ? '-' : 
                               index === 1 ? '+469%' : '+218%'}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
                    </motion.div>
                  ))}
                </div>

                {/* 累計収益 */}
                <div className="bg-gradient-to-r from-primary to-accent rounded-2xl p-8 text-white text-center">
                  <h3 className="text-2xl font-bold mb-2">3年間累計収益</h3>
                  <div className="text-5xl font-bold mb-4">$24,590,760</div>
                  <p className="text-lg opacity-90">約37億円の収益ポテンシャル</p>
                </div>
              </section>

              {/* 収益源別構成 */}
              <section>
                <h2 className="text-2xl font-bold mb-6">収益源別構成（3年間累計）</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {revenueCategories.map((category, index) => (
                    <motion.div
                      key={category.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-card rounded-xl p-4 border hover:shadow-lg transition-all"
                    >
                      <div className="flex items-center gap-3 mb-3">
                        <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", category.color)}>
                          <category.icon className="w-5 h-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-sm">{category.name}</h3>
                          <p className="text-2xl font-bold text-primary">{category.percentage}%</p>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">{category.description}</p>
                    </motion.div>
                  ))}
                </div>
              </section>

              {/* ユーザー成長予測 */}
              <section>
                <h2 className="text-2xl font-bold mb-6">ユーザー成長予測</h2>
                <div className="bg-card rounded-xl p-6 border">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-blue-500 mb-2">50K</div>
                      <div className="text-sm text-muted-foreground">Year 1 MAU</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-purple-500 mb-2">200K</div>
                      <div className="text-sm text-muted-foreground">Year 2 MAU</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-500 mb-2">500K</div>
                      <div className="text-sm text-muted-foreground">Year 3 MAU</div>
                    </div>
                  </div>
                  <div className="mt-6 h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-blue-500 via-purple-500 to-green-500 rounded-full"></div>
                  </div>
                  <p className="text-center text-sm text-muted-foreground mt-2">
                    10倍成長（3年間で50K → 500K MAU）
                  </p>
                </div>
              </section>
            </motion.div>
          )}

          {/* 詳細分析タブ */}
          {activeTab === 'detailed' && (
            <motion.div
              key="detailed"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              {/* 年度選択 */}
              <section>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold">詳細収益分析</h2>
                  <div className="flex gap-2">
                    {[1, 2, 3].map((year) => (
                      <button
                        key={year}
                        onClick={() => setSelectedYear(year as 1 | 2 | 3)}
                        className={cn(
                          "px-4 py-2 rounded-lg text-sm font-semibold transition-all",
                          selectedYear === year
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground hover:text-foreground"
                        )}
                      >
                        Year {year}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 選択された年度の詳細 */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* 収益内訳 */}
                  <div className="bg-card rounded-xl p-6 border">
                    <h3 className="font-semibold mb-4">Year {selectedYear} 収益内訳</h3>
                    <div className="space-y-3">
                      {revenueCategories.map((category) => {
                        const yearData = selectedYear === 1 ? revenueData.year1 : 
                                        selectedYear === 2 ? revenueData.year2 : revenueData.year3;
                        const amount = yearData.revenues[category.id as keyof typeof yearData.revenues] || 0;
                        const percentage = (amount / yearData.revenues.total) * 100;
                        
                        return (
                          <div key={category.id} className="flex items-center gap-3">
                            <div className={cn("w-3 h-3 rounded-full", category.color)}></div>
                            <div className="flex-1 flex justify-between items-center">
                              <span className="text-sm font-medium">{category.name}</span>
                              <div className="text-right">
                                <div className="font-semibold">{formatCurrency(amount)}</div>
                                <div className="text-xs text-muted-foreground">{percentage.toFixed(1)}%</div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* KPI指標 */}
                  <div className="bg-card rounded-xl p-6 border">
                    <h3 className="font-semibold mb-4">Year {selectedYear} KPI指標</h3>
                    <div className="space-y-4">
                      {(() => {
                        const yearData = selectedYear === 1 ? revenueData.year1 : 
                                        selectedYear === 2 ? revenueData.year2 : revenueData.year3;
                        const arpu = yearData.revenues.total / yearData.mau / 12;
                        const proArpu = yearData.revenues.subscription / yearData.proUsers / 12;
                        
                        return [
                          { label: 'MAU', value: formatNumber(yearData.mau), icon: Users },
                          { label: 'DAU', value: formatNumber(yearData.dau), icon: Users },
                          { label: 'Proユーザー', value: formatNumber(yearData.proUsers), icon: CreditCard },
                          { label: 'Pro転換率', value: `${((yearData.proUsers / yearData.mau) * 100).toFixed(1)}%`, icon: Target },
                          { label: 'ARPU/月', value: formatCurrency(arpu), icon: DollarSign },
                          { label: 'Pro ARPU/月', value: formatCurrency(proArpu), icon: TrendingUp }
                        ].map((kpi, index) => (
                          <div key={index} className="flex items-center gap-3">
                            <kpi.icon className="w-5 h-5 text-primary" />
                            <div className="flex-1 flex justify-between">
                              <span className="text-sm">{kpi.label}</span>
                              <span className="font-semibold">{kpi.value}</span>
                            </div>
                          </div>
                        ));
                      })()}
                    </div>
                  </div>
                </div>
              </section>

              {/* 成長ドライバー */}
              <section>
                <h2 className="text-2xl font-bold mb-6">成長ドライバー分析</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-card rounded-xl p-6 border">
                    <h3 className="font-semibold mb-4 flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-green-500" />
                      主要成長要因
                    </h3>
                    <div className="space-y-3">
                      <div className="flex items-start gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                        <div>
                          <h4 className="font-medium">ユーザー獲得</h4>
                          <p className="text-sm text-muted-foreground">MAU成長が全収益に直結</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                        <div>
                          <h4 className="font-medium">Pro転換率向上</h4>
                          <p className="text-sm text-muted-foreground">1%改善で年間収益が大幅UP</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                        <div>
                          <h4 className="font-medium">DApp品質向上</h4>
                          <p className="text-sm text-muted-foreground">優良DAppが増えるほど手数料増</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                        <div>
                          <h4 className="font-medium">B2B展開</h4>
                          <p className="text-sm text-muted-foreground">Year 3で収益の9%を占める重要柱</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-card rounded-xl p-6 border">
                    <h3 className="font-semibold mb-4 flex items-center gap-2">
                      <BarChart3 className="w-5 h-5 text-blue-500" />
                      収益構造の変化
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium text-blue-500">Year 1: 基盤構築期</h4>
                        <p className="text-sm text-muted-foreground">サブスクとDAppストアが中心</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-purple-500">Year 2: エコシステム拡大期</h4>
                        <p className="text-sm text-muted-foreground">広告とNFT手数料が急成長</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-green-500">Year 3: 成熟期</h4>
                        <p className="text-sm text-muted-foreground">全収益源が成熟、B2Bが新たな柱</p>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </motion.div>
          )}

          {/* ROI計算機タブ */}
          {activeTab === 'calculator' && (
            <motion.div
              key="calculator"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <section>
                <h2 className="text-2xl font-bold mb-6">カスタム収益シミュレーター</h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* 入力パラメータ */}
                  <div className="bg-card rounded-xl p-6 border">
                    <h3 className="font-semibold mb-6">パラメータ設定</h3>
                    <div className="space-y-6">
                      <div>
                        <label className="block text-sm font-medium mb-2">月間アクティブユーザー (MAU)</label>
                        <Input
                          type="number"
                          value={calculatorInputs.mau}
                          onChange={(e) => setCalculatorInputs(prev => ({
                            ...prev,
                            mau: parseInt(e.target.value) || 0
                          }))}
                          className="text-lg"
                        />
                        <p className="text-xs text-muted-foreground mt-1">現在: {formatNumber(calculatorInputs.mau)}人</p>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Pro転換率 (%)</label>
                        <Input
                          type="number"
                          step="0.1"
                          value={calculatorInputs.proConversion}
                          onChange={(e) => setCalculatorInputs(prev => ({
                            ...prev,
                            proConversion: parseFloat(e.target.value) || 0
                          }))}
                          className="text-lg"
                        />
                        <p className="text-xs text-muted-foreground mt-1">現在: {calculatorInputs.proConversion}%</p>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">平均取引額/月 ($)</label>
                        <Input
                          type="number"
                          value={calculatorInputs.avgTransactionVolume}
                          onChange={(e) => setCalculatorInputs(prev => ({
                            ...prev,
                            avgTransactionVolume: parseInt(e.target.value) || 0
                          }))}
                          className="text-lg"
                        />
                        <p className="text-xs text-muted-foreground mt-1">現在: ${formatNumber(calculatorInputs.avgTransactionVolume)}</p>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">DApp掲載数</label>
                        <Input
                          type="number"
                          value={calculatorInputs.dappCount}
                          onChange={(e) => setCalculatorInputs(prev => ({
                            ...prev,
                            dappCount: parseInt(e.target.value) || 0
                          }))}
                          className="text-lg"
                        />
                        <p className="text-xs text-muted-foreground mt-1">現在: {formatNumber(calculatorInputs.dappCount)}個</p>
                      </div>

                      <Button 
                        className="w-full"
                        onClick={() => {
                          // 計算結果を更新（リアクティブなので自動更新）
                        }}
                      >
                        <Calculator className="w-4 h-4 mr-2" />
                        計算結果を更新
                      </Button>
                    </div>
                  </div>

                  {/* 計算結果 */}
                  <div className="space-y-6">
                    <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-xl p-6 border border-primary/20">
                      <h3 className="font-semibold mb-4">年間収益予測</h3>
                      <div className="text-4xl font-bold text-primary mb-4">
                        {formatCurrency(customResults.total)}
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">Proユーザー:</span>
                          <div className="font-semibold">{formatNumber(customResults.proUsers)}人</div>
                        </div>
                        <div>
                          <span className="text-muted-foreground">トレーダー:</span>
                          <div className="font-semibold">{formatNumber(customResults.traders)}人</div>
                        </div>
                        <div>
                          <span className="text-muted-foreground">広告ユーザー:</span>
                          <div className="font-semibold">{formatNumber(customResults.adUsers)}人</div>
                        </div>
                        <div>
                          <span className="text-muted-foreground">ARPU/月:</span>
                          <div className="font-semibold">{formatCurrency(customResults.total / calculatorInputs.mau / 12)}</div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-card rounded-xl p-6 border">
                      <h3 className="font-semibold mb-4">収益内訳</h3>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">サブスクリプション</span>
                          <span className="font-semibold">{formatCurrency(customResults.subscription)}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">DeFi取引手数料</span>
                          <span className="font-semibold">{formatCurrency(customResults.defi)}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">DAppストア</span>
                          <span className="font-semibold">{formatCurrency(customResults.dapp)}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">広告収益</span>
                          <span className="font-semibold">{formatCurrency(customResults.advertising)}</span>
                        </div>
                        <div className="border-t pt-3 flex justify-between items-center font-bold">
                          <span>合計</span>
                          <span className="text-primary">{formatCurrency(customResults.total)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-card rounded-xl p-6 border">
                      <h3 className="font-semibold mb-4">投資収益率 (ROI)</h3>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">初期投資額 (仮定)</span>
                          <span className="font-semibold">$2,000,000</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">年間ROI</span>
                          <span className="font-semibold text-green-500">
                            {((customResults.total / 2000000) * 100).toFixed(1)}%
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">投資回収期間</span>
                          <span className="font-semibold">
                            {(2000000 / customResults.total).toFixed(1)}年
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </motion.div>
          )}

          {/* リスク分析タブ */}
          {activeTab === 'risks' && (
            <motion.div
              key="risks"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <section>
                <h2 className="text-2xl font-bold mb-6">リスク要因分析</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {riskFactors.map((risk, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-card rounded-xl p-6 border"
                    >
                      <div className="flex items-start gap-4">
                        <AlertTriangle className={cn("w-6 h-6 mt-1", risk.color)} />
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold">{risk.category}</h3>
                            <span className={cn(
                              "px-2 py-1 rounded-full text-xs font-semibold",
                              risk.level === 'High' ? 'bg-red-100 text-red-800' :
                              risk.level === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-green-100 text-green-800'
                            )}>
                              {risk.level}
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground mb-3">{risk.description}</p>
                          <div className="bg-muted/50 rounded-lg p-3">
                            <h4 className="text-xs font-semibold text-primary mb-1">対策:</h4>
                            <p className="text-xs">{risk.mitigation}</p>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </section>

              {/* 収益安定性分析 */}
              <section>
                <h2 className="text-2xl font-bold mb-6">収益安定性分析</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-card rounded-xl p-6 border">
                    <h3 className="font-semibold mb-4 flex items-center gap-2">
                      <Shield className="w-5 h-5 text-green-500" />
                      安定収益
                    </h3>
                    <div className="text-3xl font-bold text-green-500 mb-2">30%</div>
                    <p className="text-sm text-muted-foreground mb-4">サブスク + B2B</p>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span>サブスクリプション:</span>
                        <span>21.1%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>B2B/エンタープライズ:</span>
                        <span>8.7%</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-card rounded-xl p-6 border">
                    <h3 className="font-semibold mb-4 flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-blue-500" />
                      取引連動収益
                    </h3>
                    <div className="text-3xl font-bold text-blue-500 mb-2">22%</div>
                    <p className="text-sm text-muted-foreground mb-4">各種手数料</p>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span>NFT取引手数料:</span>
                        <span>11.5%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>オンランプ手数料:</span>
                        <span>6.7%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>DeFi手数料:</span>
                        <span>3.8%</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-card rounded-xl p-6 border">
                    <h3 className="font-semibold mb-4 flex items-center gap-2">
                      <Globe className="w-5 h-5 text-purple-500" />
                      エコシステム収益
                    </h3>
                    <div className="text-3xl font-bold text-purple-500 mb-2">40%</div>
                    <p className="text-sm text-muted-foreground mb-4">DApp + 広告</p>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span>広告収益:</span>
                        <span>20.8%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>DAppストア:</span>
                        <span>19.5%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              {/* シナリオ分析 */}
              <section>
                <h2 className="text-2xl font-bold mb-6">シナリオ分析</h2>
                <div className="space-y-4">
                  <div className="bg-green-50 border border-green-200 rounded-xl p-6">
                    <h3 className="font-semibold text-green-800 mb-2 flex items-center gap-2">
                      <CheckCircle className="w-5 h-5" />
                      楽観シナリオ (+30%)
                    </h3>
                    <p className="text-sm text-green-700 mb-3">
                      競合優位性確立、規制環境好転、Pro転換率5%達成
                    </p>
                    <div className="text-2xl font-bold text-green-800">
                      3年間累計: {formatCurrency(24590760 * 1.3)}
                    </div>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                    <h3 className="font-semibold text-blue-800 mb-2 flex items-center gap-2">
                      <Target className="w-5 h-5" />
                      基本シナリオ (現在の予測)
                    </h3>
                    <p className="text-sm text-blue-700 mb-3">
                      現実的な成長率、適度な競争環境、計画通りの機能実装
                    </p>
                    <div className="text-2xl font-bold text-blue-800">
                      3年間累計: {formatCurrency(24590760)}
                    </div>
                  </div>

                  <div className="bg-orange-50 border border-orange-200 rounded-xl p-6">
                    <h3 className="font-semibold text-orange-800 mb-2 flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5" />
                      悲観シナリオ (-40%)
                    </h3>
                    <p className="text-sm text-orange-700 mb-3">
                      激しい競争、規制強化、ユーザー獲得困難
                    </p>
                    <div className="text-2xl font-bold text-orange-800">
                      3年間累計: {formatCurrency(24590760 * 0.6)}
                    </div>
                  </div>
                </div>
              </section>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 最終CTA */}
        <section className="mt-16 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-primary to-accent rounded-2xl p-8 text-white"
          >
            <BarChart3 className="w-16 h-16 mx-auto mb-6" />
            <h2 className="text-3xl font-bold mb-4">CheatAの成長に参加しませんか？</h2>
            <p className="mb-6 opacity-90 max-w-2xl mx-auto">
              37億円の収益ポテンシャルを持つWeb3ブラウザエコシステムの一員になりましょう
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-white text-primary hover:bg-white/90 h-14 px-8"
                onClick={() => navigate('/demo')}
              >
                <Play className="mr-2 w-5 h-5" />
                デモを体験
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white/30 text-white hover:bg-white/10 h-14 px-8"
                onClick={() => navigate('/investor-deck')}
              >
                <Download className="mr-2 w-5 h-5" />
                投資家資料
              </Button>
            </div>
          </motion.div>
        </section>
      </main>
    </div>
  );
}