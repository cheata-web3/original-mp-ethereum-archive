import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { features, services, revenueModels, tokenInfo } from '@/data';
import { IMAGES } from '@/assets/images';
import { FeatureCard, ServiceCard, RevenueCard, TokenCard } from '@/components/Cards';
import { Button } from '@/components/ui/button';
import { SearchTool } from '@/components/SearchTool';
import { HeroSection } from '@/components/HeroSection';
import { cn } from '@/lib';
import { ShieldCheck, Lightbulb, Scale, Rocket, Cpu, Fingerprint, Network, Vote, Coins, Lock, Zap, Globe, BarChart3, Target, BookOpen, ArrowRight, CheckCircle, Play, Wallet } from 'lucide-react';
export default function Home() {
  const navigate = useNavigate();
  const [activeRevenueTab, setActiveRevenueTab] = useState<'browser' | 'user'>('browser');
  const filteredRevenueModels = revenueModels.filter(model => model.type === activeRevenueTab);
  const communicationServices = services.filter(s => s.category === 'communication');
  const web3Services = services.filter(s => s.category === 'web3');
  const creativeServices = services.filter(s => s.category === 'creative');
  return <div className="flex flex-col gap-10 sm:gap-12 lg:gap-16 pt-0 pb-0 mt-0 mb-0 px-4 sm:px-6 lg:px-10 xl:px-16">
      {/* シンプルブランドセクション */}
      <section className="pt-16 pb-8">
        <div className="container mx-auto px-4 text-center">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} className="mb-8">
            <div className="text-4xl md:text-5xl font-bold tracking-wide mb-4" style={{
            fontFamily: '"Inter", "Helvetica Neue", "Arial", sans-serif',
            fontWeight: '700',
            letterSpacing: '0.02em',
            background: 'linear-gradient(135deg, #002FA7 0%, #0033CC 50%, #0066FF 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            filter: 'drop-shadow(0 1px 3px rgba(0, 51, 204, 0.3))',
            textShadow: '0 0 10px rgba(0, 102, 255, 0.2)',
            transform: 'skew(-1deg)'
          }}>
              CheatA
            </div>
            <div className="text-2xl md:text-3xl text-muted-foreground font-medium mb-6">
              Web3の真の力を、あなたの手に
            </div>
            <div className="flex flex-wrap justify-center gap-4 text-base text-muted-foreground">
              <span className="px-3 py-1 bg-primary/10 rounded-full">🔷 Polygon対応</span>
              <span className="px-3 py-1 bg-accent/10 rounded-full">💎 2018年コイン統合</span>
              <span className="px-3 py-1 bg-green-500/10 rounded-full">⚡ 超低コスト</span>
              <span className="px-3 py-1 bg-purple-500/10 rounded-full">🚀 高速処理</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 検索ツール */}
      <section id="search" className="pt-16 pb-16 px-8 md:px-16 lg:px-24">
        <SearchTool />
      </section>

      {/* ヒーローセクション */}
      <section id="hero">
        <HeroSection />
      </section>

      {/* 重要機能グリッド */}
      <section id="features" className="container mx-auto px-4 scroll-mt-24">
        <div className="text-center mb-12">
          <h2 className="font-brand text-4xl md:text-5xl text-primary mb-4 flex items-center justify-center gap-3">
            <Rocket className="w-8 h-8" />
            🌐 Web3コア機能
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            分散型インターネットの力を最大限に引き出す、4つの革新的機能。
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {features.map(feature => <FeatureCard key={feature.id} feature={feature} />)}
        </div>
      </section>

      {/* DApps作成ツール 新機能 */}
      <section className="container mx-auto px-4 scroll-mt-24 mb-12">
        <div className="bg-gradient-to-br from-purple-500/10 via-blue-500/10 to-cyan-500/10 rounded-3xl border border-purple-200/50 p-8 md:p-12 cursor-pointer hover:shadow-2xl hover:border-purple-300/50 transition-all group" onClick={() => navigate('/dapps-builder')}>
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 bg-purple-500 text-white px-4 py-2 rounded-full text-sm font-semibold mb-4">
              <Zap className="w-4 h-4" />
              新機能
            </div>
            <h2 className="font-brand text-3xl md:text-4xl text-primary mb-4 group-hover:scale-105 transition-transform">
              🧩 DApps作成ツール
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto group-hover:text-foreground transition-colors">
              プログラミング知識がなくても、ドラッグ＆ドロップで簡単に分散型アプリケーション（DApps）を作成できます。
              Web3の可能性を最大限に引き出し、あなたのアイデアを形にしましょう。
            </p>
            <div className="mt-4 text-sm text-primary/70 group-hover:text-primary">
              クリックして詳細を見る →
            </div>
          </div>

          <div className="daily-grid">
            {/* ノーコードビルダー */}
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.1
          }} className="pixel-card p-6">
              <div className="text-4xl mb-3">🧩</div>
              <h3 className="font-semibold text-xl mb-2">ノーコードビルダー</h3>
              <p className="text-base text-muted-foreground">
                コーディング不要のドラッグ＆ドロップインターフェースで、誰でも簡単にDAppsを作成できます。複雑なスマートコントラクトも視覚的に構築可能です。
              </p>
            </motion.div>

            {/* ウォレット連携 */}
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.2
          }} className="pixel-card p-6">
              <div className="text-4xl mb-3">🔌</div>
              <h3 className="font-semibold text-xl mb-2">ウォレット連携</h3>
              <p className="text-base text-muted-foreground">
                MetaMask、WalletConnect、Cheataウォレットなど、主要なWeb3ウォレットとの連携機能を簡単に実装できます。
              </p>
            </motion.div>

            {/* レスポンシブデザイン */}
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.3
          }} className="pixel-card p-6">
              <div className="text-4xl mb-3">📱</div>
              <h3 className="font-semibold text-xl mb-2">レスポンシブデザイン</h3>
              <p className="text-base text-muted-foreground">
                自動的にモバイル対応のUIを生成。スマートフォン、タブレット、デスクトップなど、あらゆるデバイスで最適な表示を実現します。
              </p>
            </motion.div>

            {/* マルチチェーン対応 */}
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.4
          }} className="pixel-card p-6">
              <div className="text-4xl mb-3">🔄</div>
              <h3 className="font-semibold text-xl mb-2">マルチチェーン対応</h3>
              <p className="text-base text-muted-foreground">
                Ethereum、Polygon、Solana、BSCなど、複数のブロックチェーンに対応。ワンクリックで異なるネットワークにデプロイできます。
              </p>
            </motion.div>

            {/* テンプレートライブラリ */}
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.5
          }} className="pixel-card p-6">
              <div className="text-4xl mb-3">🛠️</div>
              <h3 className="font-semibold text-xl mb-2">テンプレートライブラリ</h3>
              <p className="text-base text-muted-foreground">
                NFTマーケットプレイス、DEX、DAOなど、様々なDAppsテンプレートを用意。カスタマイズして素早くローンチできます。
              </p>
            </motion.div>

            {/* セキュリティ監査 */}
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.6
          }} className="pixel-card p-6">
              <div className="text-4xl mb-3">🔒</div>
              <h3 className="font-semibold text-xl mb-2">セキュリティ監査</h3>
              <p className="text-base text-muted-foreground">
                自動セキュリティチェック機能で、スマートコントラクトの脆弱性を事前に検出。安全なDAppsの構築をサポートします。
              </p>
            </motion.div>
          </div>

          {/* DApps作成の流れ */}
          <div className="mt-12">
            <h3 className="text-3xl font-bold text-center mb-8">DApps作成の流れ</h3>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {[{
              step: 1,
              title: "テンプレート選択",
              desc: "目的に合ったテンプレートを選択するか、白紙の状態から作成を開始します。NFTマーケットプレイス、トークン交換、DAO、ソーシャルメディアなど、様々なテンプレートが用意されています。"
            }, {
              step: 2,
              title: "UIデザイン",
              desc: "ドラッグ＆ドロップでUIを構築。ボタン、フォーム、カード、リストなど、Web3に最適化された豊富なコンポーネントを自由に配置できます。カスタムCSSやテーマ設定も可能です。"
            }, {
              step: 3,
              title: "スマートコントラクト設定",
              desc: "ビジュアルフローエディタでスマートコントラクトのロジックを設計。事前に監査済みのコントラクトモジュールを組み合わせるか、既存のコントラクトをインポートすることも可能です。"
            }, {
              step: 4,
              title: "テスト",
              desc: "内蔵のテストネット環境で、実際のブロックチェーンにデプロイする前にDAppsの動作を確認。トランザクションのシミュレーションやエラーチェックを行えます。"
            }, {
              step: 5,
              title: "デプロイ",
              desc: "ワンクリックで選択したブロックチェーンにデプロイ。Cheataの分散型ホスティングサービスを利用するか、IPFSやArweaveなどの分散型ストレージにフロントエンドをデプロイできます。"
            }].map((item, index) => <div key={index} className="text-center">
                  <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg mx-auto mb-3">
                    {item.step}
                  </div>
                  <h4 className="font-semibold mb-2">{item.title}</h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
                </div>)}
            </div>
          </div>

          {/* 人気のDAppsテンプレート */}
          <div className="mt-12">
            <h3 className="text-2xl font-bold text-center mb-8">人気のDAppsテンプレート</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {[{
              icon: "🎨",
              title: "NFTマーケットプレイス",
              category: "アート・コレクティブル"
            }, {
              icon: "💱",
              title: "トークン交換（DEX）",
              category: "DeFi"
            }, {
              icon: "🏛️",
              title: "DAO運営ツール",
              category: "ガバナンス"
            }, {
              icon: "💬",
              title: "分散型ソーシャル",
              category: "コミュニケーション"
            }].map((template, index) => <div key={index} className="bg-white/50 backdrop-blur-sm rounded-xl p-4 border border-white/20 text-center">
                  <div className="text-3xl mb-2">{template.icon}</div>
                  <h4 className="font-semibold mb-1">{template.title}</h4>
                  <p className="text-xs text-primary">{template.category}</p>
                  <Button size="sm" className="mt-3 w-full" variant="outline">
                    テンプレートを使用
                  </Button>
                </div>)}
            </div>
          </div>

          {/* 料金プラン */}
          <div className="mt-12">
            <h3 className="text-2xl font-bold text-center mb-8">料金プラン</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[{
              name: "スタンダード",
              price: "無料",
              features: ["基本テンプレート", "1つのDAppsを作成可能", "テストネットデプロイ", "コミュニティサポート"],
              button: "今すぐ始める"
            }, {
              name: "プロフェッショナル",
              price: "50 CHEATA/月",
              features: ["すべてのテンプレート", "無制限のDApps作成", "メインネットデプロイ", "自動セキュリティ監査", "カスタムドメイン", "優先サポート"],
              button: "アップグレード",
              popular: true
            }, {
              name: "エンタープライズ",
              price: "要問合せ",
              features: ["カスタムテンプレート開発", "ホワイトラベル対応", "専用サポートマネージャー", "手動セキュリティ監査", "API統合", "SLA保証"],
              button: "お問い合わせ"
            }].map((plan, index) => <div key={index} className={cn("bg-white/50 backdrop-blur-sm rounded-xl p-6 border border-white/20 relative", plan.popular && "ring-2 ring-primary")}>
                  {plan.popular && <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <span className="bg-primary text-primary-foreground text-xs px-3 py-1 rounded-full font-semibold">
                        おすすめ
                      </span>
                    </div>}
                  <div className="text-center mb-4">
                    <h4 className="font-bold text-lg">{plan.name}</h4>
                    <div className="text-2xl font-bold text-primary">{plan.price}</div>
                  </div>
                  <div className="space-y-2 mb-6">
                    {plan.features.map((feature, idx) => <div key={idx} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span>{feature}</span>
                      </div>)}
                  </div>
                  <Button className="w-full" size="sm" variant={plan.popular ? "default" : "outline"}>
                    {plan.button}
                  </Button>
                </div>)}
            </div>
          </div>

          {/* 最終CTA */}
          <div className="text-center mt-12">
            <div className="bg-gradient-to-r from-primary/20 to-accent/20 rounded-2xl p-6 border border-primary/30">
              <h3 className="text-2xl font-bold mb-4">DApps作成を始める</h3>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                あなたのアイデアをWeb3アプリケーションに変えましょう。
                ノーコードで簡単に、プロフェッショナルなDAppsを作成できます。
              </p>
              <Button size="lg" className="h-12 px-8">
                <Play className="mr-2 w-5 h-5" />
                無料で始める ▶
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* MP機能拡張セクション */}
      <section className="container mx-auto px-4 scroll-mt-24 mb-12">
        <div className="bg-gradient-to-br from-blue-500/10 via-purple-500/10 to-cyan-500/10 rounded-3xl border border-blue-200/50 p-8 md:p-12">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 bg-blue-500 text-white px-4 py-2 rounded-full text-sm font-semibold mb-4">
              <Zap className="w-4 h-4" />
              機能拡張
            </div>
            <h2 className="font-brand text-3xl md:text-4xl text-primary mb-4">
              🚀 Magic Point エコシステム
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Magic Pointの可能性を最大限に引き出す、4つの高度な機能。
              DeFi、ステーキング、分析、コミュニティが一体となった包括的なエコシステムです。
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {/* MPステーキング */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="pixel-card p-6 cursor-pointer hover:shadow-lg transition-all group"
              onClick={() => navigate('/mp-staking')}
            >
              <div className="text-4xl mb-3">🔒</div>
              <h3 className="font-semibold text-xl mb-2 group-hover:text-primary transition-colors">MPステーキング</h3>
              <p className="text-base text-muted-foreground mb-4">
                複数のプールから選択して最適な利回りを実現。フレキシブルから固定期間まで対応。
              </p>
              <div className="text-sm text-primary font-medium">最大18.5% APY →</div>
            </motion.div>

            {/* DeFiダッシュボード */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="pixel-card p-6 cursor-pointer hover:shadow-lg transition-all group"
              onClick={() => navigate('/mp-defi-dashboard')}
            >
              <div className="text-4xl mb-3">📊</div>
              <h3 className="font-semibold text-xl mb-2 group-hover:text-primary transition-colors">DeFiダッシュボード</h3>
              <p className="text-base text-muted-foreground mb-4">
                流動性提供、イールドファーミング、レンディングを一元管理。収益を最大化。
              </p>
              <div className="text-sm text-primary font-medium">ポートフォリオ管理 →</div>
            </motion.div>

            {/* MP統計・分析 */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="pixel-card p-6 cursor-pointer hover:shadow-lg transition-all group"
              onClick={() => navigate('/mp-analytics')}
            >
              <div className="text-4xl mb-3">📈</div>
              <h3 className="font-semibold text-xl mb-2 group-hover:text-primary transition-colors">MP統計・分析</h3>
              <p className="text-base text-muted-foreground mb-4">
                価格動向、取引量、ホルダー分析など包括的な市場データを提供。
              </p>
              <div className="text-sm text-primary font-medium">市場分析 →</div>
            </motion.div>

            {/* MPコミュニティ */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="pixel-card p-6 cursor-pointer hover:shadow-lg transition-all group"
              onClick={() => navigate('/mp-community')}
            >
              <div className="text-4xl mb-3">👥</div>
              <h3 className="font-semibold text-xl mb-2 group-hover:text-primary transition-colors">MPコミュニティ</h3>
              <p className="text-base text-muted-foreground mb-4">
                ガバナンス参加、イベント情報、コミュニティフィードで繋がりを深める。
              </p>
              <div className="text-sm text-primary font-medium">コミュニティ参加 →</div>
            </motion.div>
          </div>

          {/* 統計情報 */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary mb-1">$125M+</div>
              <div className="text-sm text-muted-foreground">総ロック価値</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary mb-1">12,847</div>
              <div className="text-sm text-muted-foreground">アクティブユーザー</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary mb-1">15.2%</div>
              <div className="text-sm text-muted-foreground">平均APY</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary mb-1">24/7</div>
              <div className="text-sm text-muted-foreground">サポート</div>
            </div>
          </div>

          {/* CTA */}
          <div className="text-center">
            <div className="bg-gradient-to-r from-primary/20 to-accent/20 rounded-2xl p-6 border border-primary/30">
              <h3 className="text-2xl font-bold mb-4">Magic Pointエコシステムを体験</h3>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                ステーキング、DeFi、分析、コミュニティの全機能を活用して、
                Magic Pointの真の価値を実感してください。
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <Button size="lg" onClick={() => navigate('/mp-wallet')} className="h-12 px-8">
                  <Wallet className="mr-2 w-5 h-5" />
                  MPウォレットを開く
                </Button>
                <Button size="lg" variant="outline" onClick={() => navigate('/mp-staking')} className="h-12 px-8">
                  <Zap className="mr-2 w-5 h-5" />
                  ステーキング開始
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 収益化モデル */}
      <section id="revenue" className="container mx-auto px-4 scroll-mt-24">
        <div className="bg-card rounded-3xl border border-border p-8 md:p-12 shadow-xl cursor-pointer hover:shadow-2xl hover:border-primary/20 transition-all group" onClick={() => navigate('/token-economics')}>
          <div className="text-center mb-12">
            <h2 className="font-brand text-3xl md:text-4xl text-primary mb-4 flex items-center justify-center gap-3 group-hover:scale-105 transition-transform">
              <Coins className="w-8 h-8 group-hover:rotate-12 transition-transform" />
              💰 トークンエコノミクス
            </h2>
            <p className="text-muted-foreground group-hover:text-foreground transition-colors">
              持続可能なトークン経済で、ユーザーとプラットフォームが共に成長するエコシステム。
              <span className="block text-sm mt-2 text-primary/70 group-hover:text-primary">
                クリックして詳細を見る →
              </span>
            </p>
          </div>

          <div className="flex justify-center mb-10">
            <div className="inline-flex p-1 bg-muted rounded-xl">
              <button onClick={() => setActiveRevenueTab('browser')} className={cn("px-6 py-2.5 rounded-lg text-sm font-semibold transition-all", activeRevenueTab === 'browser' ? "bg-primary text-primary-foreground shadow-lg" : "text-muted-foreground hover:text-foreground")}>
                プラットフォーム収益
              </button>
              <button onClick={() => setActiveRevenueTab('user')} className={cn("px-6 py-2.5 rounded-lg text-sm font-semibold transition-all", activeRevenueTab === 'user' ? "bg-primary text-primary-foreground shadow-lg" : "text-muted-foreground hover:text-foreground")}>
                ユーザーリワード
              </button>
            </div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div key={activeRevenueTab} initial={{
            opacity: 0,
            y: 10
          }} animate={{
            opacity: 1,
            y: 0
          }} exit={{
            opacity: 0,
            y: -10
          }} transition={{
            duration: 0.2
          }} className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {filteredRevenueModels.map(model => <RevenueCard key={model.id} model={model} />)}
            </motion.div>
          </AnimatePresence>

          {/* トークンエコノミクス詳細 */}
          <div className="mt-12 space-y-8">
            {/* CHEATAトークンの詳細 */}
            <div className="bg-gradient-to-r from-primary/5 to-accent/5 rounded-2xl p-8 border border-primary/10">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold mb-4 flex items-center justify-center gap-2">
                  🪙 CHEATAトークンについて
                </h3>
                <p className="text-muted-foreground max-w-2xl mx-auto">
                  CHEATAトークンは、プラットフォームのガバナンスと報酬システムの中核を担うユーティリティトークンです。
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center p-6 bg-card rounded-xl border">
                  <div className="text-3xl font-bold text-primary mb-2">1,000,000,000</div>
                  <div className="text-sm text-muted-foreground mb-2">総供給量</div>
                  <div className="text-xs text-muted-foreground">固定供給、追加発行なし</div>
                </div>
                
                <div className="text-center p-6 bg-card rounded-xl border">
                  <div className="text-3xl font-bold text-green-500 mb-2">5%</div>
                  <div className="text-sm text-muted-foreground mb-2">年間ステーキング報酬</div>
                  <div className="text-xs text-muted-foreground">長期保有者への報酬</div>
                </div>
                
                <div className="text-center p-6 bg-card rounded-xl border">
                  <div className="text-3xl font-bold text-blue-500 mb-2">24時間</div>
                  <div className="text-sm text-muted-foreground mb-2">ガバナンス投票期間</div>
                  <div className="text-xs text-muted-foreground">迅速な意思決定</div>
                </div>
              </div>
            </div>

            {/* トークン配分 */}
            <div className="bg-card rounded-2xl p-8 border">
              <h3 className="text-2xl font-bold mb-6 text-center">📊 トークン配分</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
                      <span className="font-medium">コミュニティ報酬</span>
                    </div>
                    <span className="font-bold">40%</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                      <span className="font-medium">開発チーム</span>
                    </div>
                    <span className="font-bold">20%</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-4 h-4 bg-purple-500 rounded-full"></div>
                      <span className="font-medium">エコシステム基金</span>
                    </div>
                    <span className="font-bold">25%</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-4 h-4 bg-orange-500 rounded-full"></div>
                      <span className="font-medium">パートナー・アドバイザー</span>
                    </div>
                    <span className="font-bold">15%</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-center">
                  <div className="relative w-48 h-48">
                    {/* 簡易的な円グラフ表現 */}
                    <div className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-500 via-green-500 via-purple-500 to-orange-500 opacity-20"></div>
                    <div className="absolute inset-4 rounded-full bg-card flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-2xl font-bold">CHEATA</div>
                        <div className="text-sm text-muted-foreground">Token</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* ロードマップ */}
            <div className="bg-card rounded-2xl p-8 border">
              <h3 className="text-2xl font-bold mb-6 text-center">🗺️ トークンエコノミクス ロードマップ</h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    ✓
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">フェーズ 1: トークン発行 (完了)</h4>
                    <p className="text-sm text-muted-foreground">CHEATAトークンの発行とコミュニティ配布開始</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">フェーズ 2: ガバナンス開始 (進行中)</h4>
                    <p className="text-sm text-muted-foreground">DAOガバナンス機能の実装とコミュニティ投票開始</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">フェーズ 3: DeFi統合 (2026年Q2)</h4>
                    <p className="text-sm text-muted-foreground">ステーキング、流動性マイニング、イールドファーミング機能</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    4
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">フェーズ 4: エコシステム拡張 (2026年Q3)</h4>
                    <p className="text-sm text-muted-foreground">パートナーシップ拡大とクロスチェーン対応</p>
                  </div>
                </div>
              </div>
            </div>

            {/* 参加方法 */}
            <div className="bg-gradient-to-r from-primary to-accent rounded-2xl p-8 text-white text-center">
              <h3 className="text-2xl font-bold mb-4">🚀 CHEATAエコシステムに参加しよう</h3>
              <p className="mb-6 opacity-90">
                今すぐCHEATAトークンを獲得して、Web3の未来を一緒に築きましょう
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-white text-primary hover:bg-white/90">
                  トークンを獲得
                </Button>
                <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10">
                  ガバナンスに参加
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MPコインスワップ */}
      <section className="container mx-auto px-4">
        <div className="pixel-card p-8 md:p-12">
          <div className="text-center mb-8">
            <h2 className="font-brand text-2xl md:text-3xl mb-4 flex items-center justify-center gap-3">
              🔷 Magic Point on Polygon
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              PolygonネットワークでMagic Point（MP）コインを高速・低コストで利用。
              従来のEthereumと比べて99%のコスト削減を実現します。
            </p>
          </div>

          <div className="daily-grid mb-8">
            <div className="text-center p-6 pixel-card">
              <div className="text-3xl mb-3">🔷</div>
              <h3 className="font-semibold mb-2">Magic Point (Polygon)</h3>
              <div className="text-2xl font-bold text-primary mb-1">$0.0245</div>
              <div className="text-sm text-green-500">+12.5% (24h)</div>
            </div>
            
            <div className="text-center p-6 pixel-card">
              <div className="text-3xl mb-3">⚡</div>
              <h3 className="font-semibold mb-2">Polygon高速処理</h3>
              <div className="text-2xl font-bold text-blue-500 mb-1">2秒</div>
              <div className="text-sm text-muted-foreground">Polygonネットワーク</div>
            </div>
            
            <div className="text-center p-6 pixel-card">
              <div className="text-3xl mb-3">🛡️</div>
              <h3 className="font-semibold mb-2">低コスト</h3>
              <div className="text-2xl font-bold text-green-500 mb-1">$0.01</div>
              <div className="text-sm text-muted-foreground">ガス代未満</div>
            </div>
          </div>

          <div className="text-center space-y-4">
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="pixel-button" onClick={() => navigate('/mp-coin-swap')}>
                <Coins className="w-5 h-5 mr-2" />
                PolygonでMagic Pointを使う
              </Button>
              <Button size="lg" className="pixel-button bg-secondary text-secondary-foreground" onClick={() => navigate('/mp-wallet')}>
                <Wallet className="w-5 h-5 mr-2" />
                Magic Point Polygonウォレット
              </Button>
              <Button size="lg" className="pixel-button bg-accent text-accent-foreground" onClick={() => navigate('/polygon-wallet')}>
                🔷 Polygonウォレット
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* 2018年コイン Polygonブリッジ */}
      <section className="container mx-auto px-4">
        <div className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 rounded-3xl p-8 md:p-12 border border-purple-500/20">
          <div className="text-center mb-8">
            <h2 className="font-brand text-2xl md:text-3xl mb-4 flex items-center justify-center gap-3">
              🔷 2018年コイン → Polygon移行ガイド
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              2018年に作成されたコインをPolygonネットワークで活用する方法。
              低コスト・高速取引でより使いやすく進化させましょう。
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="text-center p-6 bg-card rounded-xl border">
              <div className="text-3xl mb-3">⚡</div>
              <h3 className="font-semibold mb-2">超低コスト</h3>
              <div className="text-sm text-muted-foreground">ガス代 $0.01未満</div>
            </div>
            
            <div className="text-center p-6 pixel-card">
              <div className="text-3xl mb-3">🚀</div>
              <h3 className="font-semibold mb-2">高速処理</h3>
              <div className="text-sm text-muted-foreground">2-3秒で確認完了</div>
            </div>
            
            <div className="text-center p-6 pixel-card">
              <div className="text-3xl mb-3">🔗</div>
              <h3 className="font-semibold mb-2">Ethereum互換</h3>
              <div className="text-sm text-muted-foreground">既存ツールがそのまま使用可能</div>
            </div>
          </div>

          <div className="pixel-card p-6 mb-8">
            <h3 className="font-semibold text-lg mb-4 text-center">🛠️ 移行の3ステップ</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-primary font-bold">1</span>
                </div>
                <h4 className="font-semibold mb-2">ブリッジ準備</h4>
                <p className="text-sm text-muted-foreground">
                  既存のEthereumウォレットにコインを準備
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-primary font-bold">2</span>
                </div>
                <h4 className="font-semibold mb-2">Polygonブリッジ</h4>
                <p className="text-sm text-muted-foreground">
                  公式ブリッジでPolygonネットワークに移行
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-primary font-bold">3</span>
                </div>
                <h4 className="font-semibold mb-2">活用開始</h4>
                <p className="text-sm text-muted-foreground">
                  低コストで高速な取引を開始
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="text-center p-4 bg-card/50 rounded-lg">
              <div className="text-2xl font-bold text-purple-500 mb-1">2018</div>
              <div className="text-xs text-muted-foreground">オリジナル作成年</div>
            </div>
            <div className="text-center p-4 bg-card/50 rounded-lg">
              <div className="text-2xl font-bold text-green-500 mb-1">99%</div>
              <div className="text-xs text-muted-foreground">コスト削減</div>
            </div>
            <div className="text-center p-4 bg-card/50 rounded-lg">
              <div className="text-2xl font-bold text-blue-500 mb-1">100x</div>
              <div className="text-xs text-muted-foreground">処理速度向上</div>
            </div>
            <div className="text-center p-4 bg-card/50 rounded-lg">
              <div className="text-2xl font-bold text-orange-500 mb-1">∞</div>
              <div className="text-xs text-muted-foreground">可能性</div>
            </div>
          </div>

          <div className="text-center">
            <Button size="lg" className="bg-purple-600 hover:bg-purple-700 text-white" onClick={() => navigate('/polygon-wallet')}>
              🔷 Polygonウォレットを開く
            </Button>
          </div>
        </div>
      </section>

      {/* MPウォレット */}
      <section className="container mx-auto px-4">
        <div className="bg-gradient-to-br from-accent/10 to-primary/10 rounded-3xl p-8 md:p-12 border border-accent/20">
          <div className="text-center mb-8">
            <h2 className="font-brand text-2xl md:text-3xl mb-4 flex items-center justify-center gap-3">
              💼 MPウォレット
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              MetaMaskのようなシンプルで使いやすいWeb3ウォレット。
              暗号資産の管理、送受信、スワップが一つの場所で完結します。
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="text-center p-6 bg-card rounded-xl border">
              <div className="text-3xl mb-3">🔐</div>
              <h3 className="font-semibold mb-2">セキュア</h3>
              <div className="text-sm text-muted-foreground">プライベートキーは暗号化してローカル保存</div>
            </div>
            
            <div className="text-center p-6 bg-card rounded-xl border">
              <div className="text-3xl mb-3">⚡</div>
              <h3 className="font-semibold mb-2">高速</h3>
              <div className="text-sm text-muted-foreground">瞬時の取引確認と履歴表示</div>
            </div>
            
            <div className="text-center p-6 bg-card rounded-xl border">
              <div className="text-3xl mb-3">🎨</div>
              <h3 className="font-semibold mb-2">NFT対応</h3>
              <div className="text-sm text-muted-foreground">NFTコレクションの表示と管理</div>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="text-center p-4 bg-card/50 rounded-lg">
              <div className="text-2xl font-bold text-primary mb-1">5+</div>
              <div className="text-xs text-muted-foreground">対応トークン</div>
            </div>
            <div className="text-center p-4 bg-card/50 rounded-lg">
              <div className="text-2xl font-bold text-green-500 mb-1">100%</div>
              <div className="text-xs text-muted-foreground">セキュリティ</div>
            </div>
            <div className="text-center p-4 bg-card/50 rounded-lg">
              <div className="text-2xl font-bold text-blue-500 mb-1">24/7</div>
              <div className="text-xs text-muted-foreground">利用可能</div>
            </div>
            <div className="text-center p-4 bg-card/50 rounded-lg">
              <div className="text-2xl font-bold text-purple-500 mb-1">Free</div>
              <div className="text-xs text-muted-foreground">利用料金</div>
            </div>
          </div>

          <div className="text-center">
            <Button size="lg" className="bg-accent hover:bg-accent/90" onClick={() => navigate('/mp-wallet')}>
              <Wallet className="w-5 h-5 mr-2" />
              MPウォレットを開く
            </Button>
          </div>
        </div>
      </section>

      {/* シンプル統計セクション */}
      <section className="container mx-auto px-4">
        <div className="pixel-card p-12">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4" style={{
            fontFamily: '"Inter", "Helvetica Neue", "Arial", sans-serif',
            background: 'linear-gradient(135deg, #002FA7 0%, #0033CC 50%, #0066FF 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text'
          }}>
              数字で見るCheatA
            </h2>
            <p className="text-muted-foreground">
              シンプルな数値が物語る、Web3の新しい可能性
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.1
          }} className="text-center">
              <div className="text-4xl font-bold mb-2" style={{
              background: 'linear-gradient(135deg, #002FA7 0%, #0033CC 50%, #0066FF 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text'
            }}>
                99%
              </div>
              <div className="text-sm text-muted-foreground">コスト削減</div>
            </motion.div>

            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.2
          }} className="text-center">
              <div className="text-4xl font-bold mb-2" style={{
              background: 'linear-gradient(135deg, #002FA7 0%, #0033CC 50%, #0066FF 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text'
            }}>
                2s
              </div>
              <div className="text-sm text-muted-foreground">処理時間</div>
            </motion.div>

            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.3
          }} className="text-center">
              <div className="text-4xl font-bold mb-2" style={{
              background: 'linear-gradient(135deg, #002FA7 0%, #0033CC 50%, #0066FF 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text'
            }}>
                2018
              </div>
              <div className="text-sm text-muted-foreground">オリジナル年</div>
            </motion.div>

            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.4
          }} className="text-center">
              <div className="text-4xl font-bold mb-2" style={{
              background: 'linear-gradient(135deg, #002FA7 0%, #0033CC 50%, #0066FF 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text'
            }}>
                ∞
              </div>
              <div className="text-sm text-muted-foreground">可能性</div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 開発アドバイス */}
      <section className="container mx-auto px-4">
        <div className="bg-primary/5 rounded-3xl p-8 md:p-12 border border-primary/10 cursor-pointer hover:bg-primary/10 transition-colors group" onClick={() => navigate('/best-practices')}>
          <h2 className="font-brand text-2xl md:text-3xl text-center mb-10 flex items-center justify-center gap-3 group-hover:text-primary transition-colors">
            <Lightbulb className="text-primary group-hover:scale-110 transition-transform" />
            💡 Web3ベストプラクティス
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                <Zap className="w-6 h-6" />
              </div>
              <h3 className="font-bold">⚡ セキュリティファースト</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Web3ではセキュリティが最優先。スマートコントラクトの監査、プライベートキーの管理を徹底しましょう。
              </p>
            </div>
            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                <Globe className="w-6 h-6" />
              </div>
              <h3 className="font-bold">🧠 コミュニティ中心</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Web3はコミュニティが中心。DAO、フォーラム、Discordで積極的に情報交換しましょう。
              </p>
            </div>
            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                <Scale className="w-6 h-6" />
              </div>
              <h3 className="font-bold">💰 持続可能性</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                短期的な利益よりも、長期的な価値創造を重視。サステナブルなWeb3プロジェクトを目指しましょう。
              </p>
            </div>
          </div>
          <div className="mt-10 p-6 bg-primary text-primary-foreground rounded-2xl text-center font-medium group-hover:bg-primary/90 transition-colors">
            🌐 分散型インターネットの未来を、一緒に構築しましょう。
            <div className="text-sm opacity-80 mt-2">クリックして詳細なガイドを見る →</div>
          </div>
        </div>
      </section>

      {/* Web3コンセプト */}
      <section id="web3-concept" className="container mx-auto px-4 scroll-mt-24">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="font-brand text-3xl md:text-4xl text-primary">🌐 Web3とは何か</h2>
          <div className="bg-card border border-border rounded-3xl p-8 md:p-12 shadow-sm">
            <p className="text-lg leading-relaxed text-foreground/80">
              Web3は、インターネットの次世代進化形であり、中央集権的な管理から解放された分散型ネットワークを基盤としています。ブロックチェーン技術を活用し、ユーザーが自分のデータ、アイデンティティ、資産を自ら管理することを可能にします。
            </p>
            <div className="mt-8 p-6 bg-accent rounded-2xl text-accent-foreground font-semibold text-lg">
              「これからの未来はもっと自由で、個人が力を取り戻す時代へ。」
            </div>
          </div>
        </div>
      </section>

      {/* Web3必要事項 */}
      <section id="requirements" className="container mx-auto px-4 scroll-mt-24">
        <h2 className="font-brand text-2xl md:text-3xl text-center mb-10">🌐 Web3を始めるために</h2>
        <div className="flex flex-wrap justify-center gap-4">
          {[{
          icon: <Network className="w-4 h-4" />,
          text: "🔗 分散型インフラ"
        }, {
          icon: <Fingerprint className="w-4 h-4" />,
          text: "🔐 自己主権型ID"
        }, {
          icon: <Cpu className="w-4 h-4" />,
          text: "📜 スマートコントラクト"
        }, {
          icon: <Vote className="w-4 h-4" />,
          text: "🗳️ 分散型ガバナンス"
        }, {
          icon: <Coins className="w-4 h-4" />,
          text: "💰 トークンエコノミクス"
        }, {
          icon: <ShieldCheck className="w-4 h-4" />,
          text: "🔒 プライバシー保護"
        }, {
          icon: <Zap className="w-4 h-4" />,
          text: "⚡ スケーラビリティ"
        }, {
          icon: <Globe className="w-4 h-4" />,
          text: "🌐 相互運用性"
        }].map((req, idx) => <div key={idx} className="flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-full font-medium shadow-md hover:scale-105 transition-transform cursor-default">
              {req.icon}
              {req.text}
            </div>)}
        </div>
      </section>

      {/* サービスセクション */}
      <section id="services" className="container mx-auto px-4 scroll-mt-24">
        <div className="space-y-16">
          {/* 通信サービス */}
          <div className="cursor-pointer hover:bg-muted/50 rounded-2xl p-6 -m-6 transition-colors group" onClick={() => navigate('/communication')}>
            <h2 className="font-brand text-2xl md:text-3xl mb-8 border-l-4 border-primary pl-4 group-hover:text-primary transition-colors">
              📞 コミュニケーション
              <span className="text-sm font-normal text-muted-foreground ml-4 group-hover:text-primary/70">
                クリックして詳細を見る →
              </span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {communicationServices.map(service => <ServiceCard key={service.id} service={service} />)}
            </div>
          </div>

          {/* Web3サービス */}
          <div>
            <h2 className="font-brand text-2xl md:text-3xl mb-8 border-l-4 border-primary pl-4">🔒 Web3セキュリティ</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {web3Services.map(service => <ServiceCard key={service.id} service={service} />)}
            </div>
          </div>

          {/* クリエイティブツール */}
          <div>
            <h2 className="font-brand text-2xl md:text-3xl mb-8 border-l-4 border-primary pl-4">🛠️ クリエイターツール</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {creativeServices.map(service => <ServiceCard key={service.id} service={service} />)}
            </div>
          </div>
        </div>
      </section>

      {/* パートナー企業ロゴ */}
      <section className="container mx-auto px-4 scroll-mt-24 mb-12">
        <div className="text-center">
          {/* 上部: スクリーンショット */}
          <div className="flex justify-center items-center mb-8">
            <img src="/images/screenshot_2026_02_15_18_28_56.png" alt="スクリーンショット" className="h-24 w-auto opacity-80 hover:opacity-100 transition-opacity" />
          </div>
          
          {/* 下部: 6つのロゴ */}
          <div className="flex justify-center items-center gap-8 py-4 flex-wrap">
            <img src="/images/download-2.png" alt="download-2" className="h-20 w-auto opacity-80 hover:opacity-100 transition-opacity" />
            <img src="/images/kraken.jpg" alt="kraken" className="h-20 w-auto opacity-80 hover:opacity-100 transition-opacity" />
            <img src="/images/Bybit_Logotype_250x250_Darkmode-Duo.jpg" alt="Bybit" className="h-20 w-auto opacity-80 hover:opacity-100 transition-opacity" />
            <img src="/images/image.webp" alt="image" className="h-20 w-auto opacity-80 hover:opacity-100 transition-opacity" />
            <img src="/images/IMG_1444.jpg" alt="IMG_1444" className="h-20 w-auto opacity-80 hover:opacity-100 transition-opacity" />
            <img src="/images/IMG_1443.png" alt="IMG_1443" className="h-20 w-auto opacity-80 hover:opacity-100 transition-opacity" />
          </div>
        </div>
      </section>

      {/* トークンダッシュボード */}
      <section id="token-dashboard" className="container mx-auto px-4 scroll-mt-24 mb-12">
        <div className="bg-gradient-to-br from-primary via-primary/90 to-primary rounded-[2rem] p-8 md:p-12 text-white relative overflow-hidden">
          {/* Professional Background */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/20 rounded-full translate-y-1/2 -translate-x-1/2 blur-3xl" />
          
          <div className="relative z-10">
            <div className="text-center mb-12">
              <h2 className="font-brand text-3xl md:text-4xl mb-4">📊 トークンダッシュボード</h2>
              <p className="text-white/70">あなたのWeb3資産とガバナンス参加状況を一目で確認。</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {tokenInfo.map(info => <TokenCard key={info.id} info={info} />)}
            </div>
          </div>
        </div>
      </section>

      {/* 投資家・ビジネス向けセクション */}
      <section className="container mx-auto px-4 scroll-mt-24 mb-12">
        <div className="text-center mb-12">
          <h2 className="font-brand text-3xl md:text-4xl text-primary mb-4">
            📈 投資家・ビジネス向け資料
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            CheatAの詳細なビジネスモデル、収益予測、投資機会について詳しく知りたい方向けの専門資料
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* 収益予測ダッシュボード */}
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.1
        }} className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-2xl p-6 border border-blue-200/50 hover:shadow-xl transition-all cursor-pointer group" onClick={() => navigate('/revenue-forecast')}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-blue-500 flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">収益予測ダッシュボード</h3>
                <p className="text-sm text-muted-foreground">3年間の詳細分析</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              37億円の収益ポテンシャルを持つ9つの収益源の詳細分析とインタラクティブなROI計算機
            </p>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-blue-600">$24.6M</div>
              <ArrowRight className="w-5 h-5 text-blue-500 group-hover:translate-x-1 transition-transform" />
            </div>
          </motion.div>

          {/* 投資家向け資料 */}
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.2
        }} className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 rounded-2xl p-6 border border-green-200/50 hover:shadow-xl transition-all cursor-pointer group" onClick={() => navigate('/investor-deck')}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-green-500 flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">投資家向け資料</h3>
                <p className="text-sm text-muted-foreground">ピッチデック & 財務</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              市場機会、競合優位性、チーム紹介、資金調達計画など投資判断に必要な全情報
            </p>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-green-600">$5M</div>
              <ArrowRight className="w-5 h-5 text-green-500 group-hover:translate-x-1 transition-transform" />
            </div>
          </motion.div>

          {/* ビジネスガイド */}
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.3
        }} className="bg-gradient-to-br from-purple-500/10 to-violet-500/10 rounded-2xl p-6 border border-purple-200/50 hover:shadow-xl transition-all cursor-pointer group" onClick={() => navigate('/business-guide')}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-purple-500 flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">ビジネスガイド</h3>
                <p className="text-sm text-muted-foreground">完全実装マニュアル</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              技術アーキテクチャ、実装計画、チーム構成まで、事業化に必要な全ての詳細情報
            </p>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-purple-600">6章</div>
              <ArrowRight className="w-5 h-5 text-purple-500 group-hover:translate-x-1 transition-transform" />
            </div>
          </motion.div>
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-8 border border-primary/20">
            <h3 className="text-2xl font-bold mb-4">Web3の未来に投資しませんか？</h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              CheatAは次世代Web3プラットフォームとして、37億円の収益ポテンシャルを持つ革新的なエコシステムです。
              詳細な事業計画と投資機会について、ぜひご相談ください。
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" onClick={() => navigate('/investor-deck')} className="h-12 px-8">
                <Target className="mr-2 w-5 h-5" />
                投資相談を開始
              </Button>
              <Button size="lg" variant="outline" onClick={() => navigate('/business-guide')} className="h-12 px-8">
                <BookOpen className="mr-2 w-5 h-5" />
                詳細資料を確認
              </Button>
            </div>
          </div>
        </div>
      </section>
      {/* シンプルCTA */}
      <section className="container mx-auto px-4">
        <div className="text-center py-20">
          <motion.div initial={{
          opacity: 0,
          scale: 0.9
        }} whileInView={{
          opacity: 1,
          scale: 1
        }} transition={{
          duration: 0.6
        }}>
            <div className="text-4xl md:text-5xl font-bold mb-8" style={{
            fontFamily: '"Inter", "Helvetica Neue", "Arial", sans-serif',
            fontWeight: '700',
            letterSpacing: '0.02em',
            background: 'linear-gradient(135deg, #002FA7 0%, #0033CC 50%, #0066FF 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            filter: 'drop-shadow(0 1px 3px rgba(0, 51, 204, 0.3))',
            transform: 'skew(-1deg)'
          }}>
              始めよう
            </div>
            <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
              Web3の未来は、今ここから始まります。<br />
              あなたのアイデアを現実に変える時です。
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-lg px-8 py-4" onClick={() => navigate('/polygon-wallet')}>
                🔷 Polygonウォレットを開く
              </Button>
              <Button size="lg" variant="outline" className="border-primary/30 text-primary hover:bg-primary/10 text-lg px-8 py-4" onClick={() => navigate('/dapps-builder')}>
                🧩 DAppsを作成する
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* AI Assistant Floating Button (Visual Only) */}
      <button className="fixed bottom-8 right-8 w-16 h-16 bg-primary text-primary-foreground rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-transform z-50 animate-bounce">
        <Cpu className="w-8 h-8" />
      </button>
    </div>;
}
