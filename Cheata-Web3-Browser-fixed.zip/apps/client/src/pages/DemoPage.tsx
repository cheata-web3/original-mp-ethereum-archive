import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  ArrowRight, 
  RotateCw, 
  Home, 
  Shield, 
  Lock, 
  Wallet, 
  Settings,
  Search,
  Star,
  Download,
  Share,
  Bookmark,
  Globe,
  Zap,
  Database
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function DemoPage() {
  const navigate = useNavigate();
  const [currentUrl, setCurrentUrl] = useState("https://app.cheata.win/demo");
  const [isLoading, setIsLoading] = useState(false);
  const [connectedWallet, setConnectedWallet] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState("home");

  // デモ用のページコンテンツ
  const demoPages = {
    home: {
      title: "CheatA Dashboard",
      content: (
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-primary to-primary/80 rounded-2xl p-6 text-white">
            <h2 className="text-2xl font-bold mb-2">Welcome to CheatA</h2>
            <p className="opacity-90">Your Web3 journey starts here</p>
            <div className="mt-4 grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold">1,250.50</div>
                <div className="text-sm opacity-80">CHEATA Balance</div>
              </div>
              <div>
                <div className="text-2xl font-bold">+45.75</div>
                <div className="text-sm opacity-80">Daily Rewards</div>
              </div>
              <div>
                <div className="text-2xl font-bold">Tier 3</div>
                <div className="text-sm opacity-80">Governance</div>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-card border rounded-xl p-4">
              <h3 className="font-semibold mb-2 flex items-center gap-2">
                <Wallet className="w-5 h-5 text-primary" />
                Multi-Chain Wallet
              </h3>
              <p className="text-sm text-muted-foreground">Manage assets across multiple blockchains</p>
              <Button size="sm" className="mt-3" onClick={() => setCurrentPage("wallet")}>
                Open Wallet
              </Button>
            </div>
            
            <div className="bg-card border rounded-xl p-4">
              <h3 className="font-semibold mb-2 flex items-center gap-2">
                <Database className="w-5 h-5 text-primary" />
                DeFi Optimizer
              </h3>
              <p className="text-sm text-muted-foreground">AI-powered yield farming strategies</p>
              <Button size="sm" className="mt-3" onClick={() => setCurrentPage("defi")}>
                Optimize Yields
              </Button>
            </div>
          </div>
        </div>
      )
    },
    wallet: {
      title: "Multi-Chain Wallet",
      content: (
        <div className="space-y-6">
          <div className="bg-card border rounded-xl p-6">
            <h2 className="text-xl font-bold mb-4">Your Assets</h2>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    ETH
                  </div>
                  <div>
                    <div className="font-semibold">Ethereum</div>
                    <div className="text-sm text-muted-foreground">2.45 ETH</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">$4,890.00</div>
                  <div className="text-sm text-green-500">+2.3%</div>
                </div>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    SOL
                  </div>
                  <div>
                    <div className="font-semibold">Solana</div>
                    <div className="text-sm text-muted-foreground">15.2 SOL</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">$1,824.00</div>
                  <div className="text-sm text-red-500">-1.2%</div>
                </div>
              </div>
            </div>
            
            <div className="mt-6 flex gap-3">
              <Button className="flex-1">Send</Button>
              <Button variant="outline" className="flex-1">Receive</Button>
              <Button variant="outline" className="flex-1">Swap</Button>
            </div>
          </div>
        </div>
      )
    },
    defi: {
      title: "DeFi Optimizer",
      content: (
        <div className="space-y-6">
          <div className="bg-card border rounded-xl p-6">
            <h2 className="text-xl font-bold mb-4">AI Recommendations</h2>
            <div className="space-y-4">
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-green-800">Uniswap V3 USDC/ETH</h3>
                  <span className="text-green-600 font-bold">12.4% APY</span>
                </div>
                <p className="text-sm text-green-700 mb-3">Low risk, high liquidity pool with stable returns</p>
                <Button size="sm" className="bg-green-600 hover:bg-green-700">
                  Invest Now
                </Button>
              </div>
              
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-blue-800">Compound USDT</h3>
                  <span className="text-blue-600 font-bold">8.7% APY</span>
                </div>
                <p className="text-sm text-blue-700 mb-3">Stable lending with automatic compounding</p>
                <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                  Invest Now
                </Button>
              </div>
            </div>
          </div>
        </div>
      )
    }
  };

  const handleUrlChange = (url: string) => {
    setIsLoading(true);
    setCurrentUrl(url);
    
    // URLに基づいてページを変更
    if (url.includes("wallet")) {
      setCurrentPage("wallet");
    } else if (url.includes("defi")) {
      setCurrentPage("defi");
    } else {
      setCurrentPage("home");
    }
    
    setTimeout(() => setIsLoading(false), 800);
  };

  const connectWallet = () => {
    setConnectedWallet("MetaMask（接続済み）");
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* ブラウザヘッダー */}
      <header className="bg-card border-b border-border p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="font-brand text-xl font-bold text-primary">
              CheatA Browser Demo
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {!connectedWallet ? (
              <Button size="sm" onClick={connectWallet} className="flex items-center gap-2">
                <Wallet className="w-4 h-4" />
                ウォレット接続
              </Button>
            ) : (
              <div className="text-sm bg-green-100 text-green-800 px-3 py-1 rounded-full">
                {connectedWallet}
              </div>
            )}
          </div>
        </div>

        {/* ブラウザツールバー */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <ArrowRight className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <RotateCw className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => handleUrlChange("https://app.cheata.win/demo")}>
              <Home className="w-4 h-4" />
            </Button>
          </div>

          <div className="flex-1 flex items-center gap-2 bg-muted/50 border border-border rounded-xl px-4 py-2">
            <Lock className="w-4 h-4 text-green-500" />
            <Input
              value={currentUrl}
              onChange={(e) => setCurrentUrl(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleUrlChange(currentUrl)}
              className="border-none bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0"
            />
          </div>

          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm">
              <Shield className="w-4 h-4 text-green-500" />
            </Button>
            <Button variant="ghost" size="sm">
              <Settings className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* クイックアクセスボタン */}
        <div className="flex items-center gap-2 mt-4">
          <Button 
            size="sm" 
            variant={currentPage === "home" ? "default" : "outline"}
            onClick={() => handleUrlChange("https://app.cheata.win/demo")}
          >
            <Home className="w-4 h-4 mr-2" />
            Dashboard
          </Button>
          <Button 
            size="sm" 
            variant={currentPage === "wallet" ? "default" : "outline"}
            onClick={() => handleUrlChange("https://app.cheata.win/wallet")}
          >
            <Wallet className="w-4 h-4 mr-2" />
            Wallet
          </Button>
          <Button 
            size="sm" 
            variant={currentPage === "defi" ? "default" : "outline"}
            onClick={() => handleUrlChange("https://app.cheata.win/defi")}
          >
            <Database className="w-4 h-4 mr-2" />
            DeFi
          </Button>
        </div>
      </header>

      {/* メインコンテンツエリア */}
      <main className="flex-1 p-6">
        <AnimatePresence mode="wait">
          {isLoading ? (
            <motion.div
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center justify-center h-64"
            >
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                <span className="text-muted-foreground">Loading...</span>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key={currentPage}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="max-w-4xl mx-auto"
            >
              <h1 className="text-3xl font-bold mb-6">{demoPages[currentPage as keyof typeof demoPages].title}</h1>
              {demoPages[currentPage as keyof typeof demoPages].content}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* フッター */}
      <footer className="bg-card border-t border-border p-4 text-center">
        <p className="text-sm text-muted-foreground">
          これはCheatAブラウザのデモ版です。実際の機能は開発中です。
        </p>
      </footer>
    </div>
  );
}