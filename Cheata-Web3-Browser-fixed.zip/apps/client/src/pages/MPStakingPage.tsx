import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  TrendingUp,
  Lock,
  Unlock,
  Clock,
  Coins,
  BarChart3,
  Target,
  Zap,
  Shield,
  Gift,
  Calendar,
  ArrowUpRight,
  ArrowDownLeft,
  RefreshCw,
  Info,
  CheckCircle,
  AlertTriangle,
  Star,
  Crown,
  Flame
} from "lucide-react";
import { cn } from "@/lib/utils";
import { IMAGES } from "@/assets/images";

export default function MPStakingPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'stake' | 'pools' | 'rewards' | 'history'>('stake');
  const [stakeAmount, setStakeAmount] = useState<string>('');
  const [selectedPool, setSelectedPool] = useState<string>('flexible');
  const [isStaking, setIsStaking] = useState<boolean>(false);
  const [totalStaked, setTotalStaked] = useState<string>('25,000.00');
  const [totalRewards, setTotalRewards] = useState<string>('1,247.83');

  // ステーキングプール
  const stakingPools = [
    {
      id: 'flexible',
      name: 'フレキシブル',
      apy: '8.5%',
      minStake: '100',
      lockPeriod: 'なし',
      totalStaked: '2,450,000',
      description: 'いつでも引き出し可能',
      risk: 'low',
      popular: true,
      icon: '🔄'
    },
    {
      id: '30days',
      name: '30日固定',
      apy: '12.0%',
      minStake: '500',
      lockPeriod: '30日',
      totalStaked: '1,850,000',
      description: '30日間ロックで高利回り',
      risk: 'medium',
      popular: false,
      icon: '📅'
    },
    {
      id: '90days',
      name: '90日固定',
      apy: '18.5%',
      minStake: '1,000',
      lockPeriod: '90日',
      totalStaked: '980,000',
      description: '90日間ロックで最高利回り',
      risk: 'medium',
      popular: false,
      icon: '🏆'
    },
    {
      id: 'defi',
      name: 'DeFiプール',
      apy: '25.0%',
      minStake: '2,000',
      lockPeriod: '変動',
      totalStaked: '650,000',
      description: 'DeFiプロトコル参加で超高利回り',
      risk: 'high',
      popular: false,
      icon: '⚡'
    }
  ];

  // 報酬履歴
  const rewardHistory = [
    {
      date: '2026-03-07',
      amount: '+45.67',
      type: 'staking',
      pool: 'フレキシブル',
      status: 'confirmed'
    },
    {
      date: '2026-03-06',
      amount: '+52.34',
      type: 'staking',
      pool: '30日固定',
      status: 'confirmed'
    },
    {
      date: '2026-03-05',
      amount: '+38.91',
      type: 'defi',
      pool: 'DeFiプール',
      status: 'confirmed'
    },
    {
      date: '2026-03-04',
      amount: '+41.23',
      type: 'staking',
      pool: 'フレキシブル',
      status: 'confirmed'
    }
  ];

  // ステーキング統計
  const stakingStats = [
    {
      label: 'ステーキング中',
      value: totalStaked + ' MP',
      change: '+12.5%',
      positive: true,
      icon: Lock
    },
    {
      label: '累計報酬',
      value: totalRewards + ' MP',
      change: '+8.7%',
      positive: true,
      icon: Gift
    },
    {
      label: '年間利回り',
      value: '15.2%',
      change: '+2.1%',
      positive: true,
      icon: TrendingUp
    },
    {
      label: 'ランク',
      value: 'ゴールド',
      change: 'アップ',
      positive: true,
      icon: Crown
    }
  ];

  const handleStake = async () => {
    setIsStaking(true);
    // シミュレートされたステーキング処理
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsStaking(false);
    setStakeAmount('');
    // Toast notification would go here
  };

  const getPoolRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-500 bg-green-500/10';
      case 'medium': return 'text-yellow-500 bg-yellow-500/10';
      case 'high': return 'text-red-500 bg-red-500/10';
      default: return 'text-muted-foreground bg-muted/10';
    }
  };

  const getPoolRiskText = (risk: string) => {
    switch (risk) {
      case 'low': return '低リスク';
      case 'medium': return '中リスク';
      case 'high': return '高リスク';
      default: return '不明';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 flex items-center justify-center">
                <img 
                  src="/images/777.png" 
                  alt="MP Staking Logo" 
                  className="w-10 h-10 object-contain drop-shadow-md z-10"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                    if (fallback) fallback.style.display = 'flex';
                  }}
                />
                <div 
                  className="absolute inset-0 w-auto h-10 flex items-center justify-center text-lg font-bold tracking-tight"
                  style={{ 
                    display: 'none',
                    background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text'
                  }}
                >
                  CheatA
                </div>
              </div>
              <div className="font-brand text-2xl font-bold tracking-tight" style={{
                background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}>
                🔒 MP ステーキング
              </div>
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            Magic Pointをステーキングして報酬を獲得。
            複数のプールから選択して、最適な利回りを実現しましょう。
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-12 max-w-6xl">
        {/* 統計カード */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {stakingStats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-card rounded-2xl border p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center justify-between mb-4">
                <stat.icon className="w-8 h-8 text-primary" />
                <div className={cn(
                  "text-sm px-2 py-1 rounded-full",
                  stat.positive ? "text-green-500 bg-green-500/10" : "text-red-500 bg-red-500/10"
                )}>
                  {stat.change}
                </div>
              </div>
              <div className="text-2xl font-bold mb-1">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        {/* タブナビゲーション */}
        <div className="flex space-x-1 bg-muted p-1 rounded-xl mb-8">
          {[
            { id: 'stake', label: 'ステーキング', icon: Lock },
            { id: 'pools', label: 'プール一覧', icon: BarChart3 },
            { id: 'rewards', label: '報酬', icon: Gift },
            { id: 'history', label: '履歴', icon: Clock }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg text-sm font-medium transition-all",
                activeTab === tab.id
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* タブコンテンツ */}
        <AnimatePresence mode="wait">
          {activeTab === 'stake' && (
            <motion.div
              key="stake"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* ステーキングフォーム */}
                <div className="bg-card rounded-2xl border p-6">
                  <h3 className="text-xl font-bold mb-6">MPをステーキング</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">ステーキング量</label>
                      <div className="relative">
                        <Input
                          type="number"
                          placeholder="0.00"
                          value={stakeAmount}
                          onChange={(e) => setStakeAmount(e.target.value)}
                          className="pr-16 text-lg"
                        />
                        <div className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                          MP
                        </div>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        利用可能: 50,000.00 MP
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">プール選択</label>
                      <select
                        value={selectedPool}
                        onChange={(e) => setSelectedPool(e.target.value)}
                        className="w-full p-3 border border-border rounded-lg bg-background"
                      >
                        {stakingPools.map((pool) => (
                          <option key={pool.id} value={pool.id}>
                            {pool.name} - {pool.apy} APY
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="bg-muted/50 rounded-lg p-4">
                      <div className="flex justify-between text-sm mb-2">
                        <span>予想年間報酬</span>
                        <span className="font-medium">
                          {stakeAmount ? (parseFloat(stakeAmount) * 0.15).toFixed(2) : '0.00'} MP
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>月間報酬</span>
                        <span className="font-medium">
                          {stakeAmount ? (parseFloat(stakeAmount) * 0.15 / 12).toFixed(2) : '0.00'} MP
                        </span>
                      </div>
                    </div>

                    <Button
                      onClick={handleStake}
                      disabled={!stakeAmount || isStaking}
                      className="w-full h-12 text-lg"
                    >
                      {isStaking ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          ステーキング中...
                        </>
                      ) : (
                        <>
                          <Lock className="w-4 h-4 mr-2" />
                          ステーキング開始
                        </>
                      )}
                    </Button>
                  </div>
                </div>

                {/* 選択されたプール詳細 */}
                <div className="bg-card rounded-2xl border p-6">
                  {(() => {
                    const pool = stakingPools.find(p => p.id === selectedPool);
                    if (!pool) return null;
                    
                    return (
                      <>
                        <div className="flex items-center gap-3 mb-6">
                          <div className="text-2xl">{pool.icon}</div>
                          <div>
                            <h3 className="text-xl font-bold">{pool.name}</h3>
                            <div className="flex items-center gap-2">
                              <span className="text-2xl font-bold text-primary">{pool.apy}</span>
                              <span className="text-sm text-muted-foreground">年間利回り</span>
                              {pool.popular && (
                                <span className="bg-orange-500/10 text-orange-500 text-xs px-2 py-1 rounded-full">
                                  人気
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">最小ステーキング</span>
                            <span className="font-medium">{pool.minStake} MP</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">ロック期間</span>
                            <span className="font-medium">{pool.lockPeriod}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">総ステーキング量</span>
                            <span className="font-medium">{pool.totalStaked} MP</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">リスクレベル</span>
                            <span className={cn("px-2 py-1 rounded-full text-xs", getPoolRiskColor(pool.risk))}>
                              {getPoolRiskText(pool.risk)}
                            </span>
                          </div>
                        </div>

                        <div className="mt-6 p-4 bg-muted/50 rounded-lg">
                          <p className="text-sm text-muted-foreground">{pool.description}</p>
                        </div>
                      </>
                    );
                  })()}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'pools' && (
            <motion.div
              key="pools"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-6"
            >
              {stakingPools.map((pool) => (
                <div key={pool.id} className="bg-card rounded-2xl border p-6 hover:shadow-lg transition-shadow">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">{pool.icon}</div>
                      <div>
                        <h3 className="text-lg font-bold">{pool.name}</h3>
                        <div className="flex items-center gap-2">
                          <span className={cn("px-2 py-1 rounded-full text-xs", getPoolRiskColor(pool.risk))}>
                            {getPoolRiskText(pool.risk)}
                          </span>
                          {pool.popular && (
                            <span className="bg-orange-500/10 text-orange-500 text-xs px-2 py-1 rounded-full">
                              人気
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary">{pool.apy}</div>
                      <div className="text-xs text-muted-foreground">APY</div>
                    </div>
                  </div>

                  <div className="space-y-3 mb-6">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">最小ステーキング</span>
                      <span>{pool.minStake} MP</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">ロック期間</span>
                      <span>{pool.lockPeriod}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">総ステーキング量</span>
                      <span>{pool.totalStaked} MP</span>
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground mb-4">{pool.description}</p>

                  <Button
                    onClick={() => {
                      setSelectedPool(pool.id);
                      setActiveTab('stake');
                    }}
                    className="w-full"
                    variant={pool.popular ? "default" : "outline"}
                  >
                    このプールを選択
                  </Button>
                </div>
              ))}
            </motion.div>
          )}

          {activeTab === 'rewards' && (
            <motion.div
              key="rewards"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="bg-card rounded-2xl border p-6">
                <h3 className="text-xl font-bold mb-6">報酬サマリー</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary mb-2">{totalRewards} MP</div>
                    <div className="text-sm text-muted-foreground">累計報酬</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-500 mb-2">+156.78 MP</div>
                    <div className="text-sm text-muted-foreground">今月の報酬</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-500 mb-2">+45.67 MP</div>
                    <div className="text-sm text-muted-foreground">今日の報酬</div>
                  </div>
                </div>
              </div>

              <div className="bg-card rounded-2xl border p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold">報酬履歴</h3>
                  <Button variant="outline" size="sm">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    更新
                  </Button>
                </div>

                <div className="space-y-4">
                  {rewardHistory.map((reward, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-green-500/10 rounded-full flex items-center justify-center">
                          <Gift className="w-5 h-5 text-green-500" />
                        </div>
                        <div>
                          <div className="font-medium">{reward.pool}</div>
                          <div className="text-sm text-muted-foreground">{reward.date}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-green-500">{reward.amount} MP</div>
                        <div className="text-xs text-muted-foreground capitalize">{reward.type}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'history' && (
            <motion.div
              key="history"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-card rounded-2xl border p-6"
            >
              <h3 className="text-xl font-bold mb-6">ステーキング履歴</h3>
              <div className="text-center py-12">
                <Clock className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">ステーキング履歴がここに表示されます</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}