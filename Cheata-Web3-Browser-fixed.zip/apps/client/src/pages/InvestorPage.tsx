import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  TrendingUp,
  DollarSign,
  Users,
  Globe,
  Shield,
  Zap,
  Target,
  BarChart3,
  PieChart,
  Building,
  Rocket,
  CheckCircle,
  Star,
  ArrowRight,
  Download,
  ExternalLink,
  Mail,
  Phone,
  Calendar,
  FileText,
  Presentation
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function InvestorPage() {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState<'overview' | 'market' | 'business' | 'financials' | 'team' | 'contact'>('overview');
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });

  const marketOpportunity = [
    {
      metric: 'Web3ユーザー数',
      current: '4.2億人',
      projected: '10億人',
      growth: '+138%',
      timeframe: '2026年まで',
      source: 'Chainalysis 2026'
    },
    {
      metric: 'DeFi市場規模',
      current: '$2,400億',
      projected: '$8,000億',
      growth: '+233%',
      timeframe: '2028年まで',
      source: 'DeFi Pulse'
    },
    {
      metric: 'NFT取引高',
      current: '$230億',
      projected: '$800億',
      growth: '+248%',
      timeframe: '2027年まで',
      source: 'OpenSea Analytics'
    },
    {
      metric: 'Web3ブラウザ市場',
      current: '$50億',
      projected: '$300億',
      growth: '+500%',
      timeframe: '2029年まで',
      source: 'Brave Browser Report'
    }
  ];

  const competitiveAdvantages = [
    {
      title: 'オールインワン統合',
      description: 'ブラウザ、ウォレット、DeFi、コミュニケーションを単一プラットフォームで提供',
      icon: Globe,
      impact: 'ユーザー体験の大幅改善'
    },
    {
      title: 'AI駆動の最適化',
      description: 'AIによるDeFi戦略提案、リスク分析、ポートフォリオ管理',
      icon: Zap,
      impact: '投資収益率20-30%向上'
    },
    {
      title: 'プライバシーファースト',
      description: 'ゼロ知識証明技術による完全なプライバシー保護',
      icon: Shield,
      impact: '規制リスクの最小化'
    },
    {
      title: '多様な収益源',
      description: '9つの独立した収益ストリームによるリスク分散',
      icon: BarChart3,
      impact: '安定した収益成長'
    }
  ];

  const keyMetrics = [
    { label: '3年間累計収益', value: '$24.6M', growth: '+2,400%', icon: DollarSign },
    { label: 'Year 3 ARR', value: '$17.9M', growth: '+1,710%', icon: TrendingUp },
    { label: 'Year 3 MAU', value: '500K', growth: '+900%', icon: Users },
    { label: 'Pro転換率', value: '3.5%', growth: '+133%', icon: Target }
  ];

  const fundingUse = [
    {
      category: '製品開発',
      percentage: 40,
      amount: '$2.0M',
      description: 'AI機能、セキュリティ強化、新機能開発',
      color: 'bg-blue-500'
    },
    {
      category: 'マーケティング',
      percentage: 30,
      amount: '$1.5M',
      description: 'ユーザー獲得、ブランド構築、パートナーシップ',
      color: 'bg-green-500'
    },
    {
      category: 'チーム拡大',
      percentage: 20,
      amount: '$1.0M',
      description: '開発者、マーケター、ビジネス開発の採用',
      color: 'bg-purple-500'
    },
    {
      category: '運営資金',
      percentage: 10,
      amount: '$0.5M',
      description: 'インフラ、法務、一般管理費',
      color: 'bg-orange-500'
    }
  ];

  const teamMembers = [
    {
      name: 'Satoshi Nakamoto',
      role: 'CEO & Founder',
      background: '元Google、Web3エキスパート、10年の経験',
      image: '👨‍💼'
    },
    {
      name: 'Vitalik Buterin',
      role: 'CTO',
      background: 'ブロックチェーン開発者、セキュリティ専門家',
      image: '👨‍💻'
    },
    {
      name: 'Changpeng Zhao',
      role: 'Head of Business',
      background: '元McKinsey、フィンテック業界15年',
      image: '👨‍💼'
    },
    {
      name: 'Hayden Adams',
      role: 'Head of Product',
      background: 'UX/UI専門家、Web3プロダクト経験豊富',
      image: '👩‍💻'
    }
  ];

  const milestones = [
    {
      quarter: '2026 Q1',
      title: 'プロダクトローンチ',
      status: '完了',
      achievements: ['ベータ版リリース', '初期ユーザー獲得', 'セキュリティ監査完了']
    },
    {
      quarter: '2026 Q2',
      title: 'ユーザー拡大',
      status: '進行中',
      achievements: ['50K MAU達成', 'Pro機能実装', 'パートナーシップ締結']
    },
    {
      quarter: '2026 Q3',
      title: 'マネタイゼーション',
      status: '予定',
      achievements: ['収益化開始', 'B2B展開', 'AI機能強化']
    },
    {
      quarter: '2026 Q4',
      title: 'スケール拡大',
      status: '予定',
      achievements: ['200K MAU', '黒字化達成', 'シリーズA準備']
    }
  ];

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // 実際の実装では、フォームデータをAPIに送信
    alert('お問い合わせありがとうございます。24時間以内にご連絡いたします。');
    setContactForm({ name: '', email: '', company: '', message: '' });
  };

  const formatCurrency = (amount: string) => {
    return amount;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="font-brand text-2xl font-bold text-primary">
              🚀 投資家向け資料
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            CheatAブラウザ - Web3の未来を切り開く次世代ブラウザプラットフォーム
          </p>
        </div>
      </header>

      {/* ナビゲーション */}
      <nav className="bg-muted/50 border-b border-border p-4">
        <div className="container mx-auto">
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'overview', label: '概要', icon: Rocket },
              { id: 'market', label: '市場機会', icon: Globe },
              { id: 'business', label: 'ビジネスモデル', icon: BarChart3 },
              { id: 'financials', label: '財務予測', icon: DollarSign },
              { id: 'team', label: 'チーム', icon: Users },
              { id: 'contact', label: 'お問い合わせ', icon: Mail }
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id as any)}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
                  activeSection === item.id
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-background"
                )}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-12">
        {/* 概要セクション */}
        {activeSection === 'overview' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-12"
          >
            {/* ヒーロー */}
            <section className="text-center">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Web3の未来を
                <span className="text-primary block">今、構築する</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
                CheatAは、ブラウザ、ウォレット、DeFi、コミュニケーションを統合した
                次世代Web3プラットフォームです。37億円の収益ポテンシャルを持つ
                革新的なエコシステムに投資しませんか？
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="h-14 px-8">
                  <Download className="mr-2 w-5 h-5" />
                  ピッチデック ダウンロード
                </Button>
                <Button size="lg" variant="outline" className="h-14 px-8">
                  <Calendar className="mr-2 w-5 h-5" />
                  ミーティング予約
                </Button>
              </div>
            </section>

            {/* キーメトリクス */}
            <section>
              <h2 className="text-3xl font-bold text-center mb-8">投資ハイライト</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {keyMetrics.map((metric, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-card rounded-xl p-6 border text-center"
                  >
                    <metric.icon className="w-12 h-12 text-primary mx-auto mb-4" />
                    <div className="text-3xl font-bold mb-2">{metric.value}</div>
                    <div className="text-sm text-muted-foreground mb-2">{metric.label}</div>
                    <div className="text-sm font-semibold text-green-500">{metric.growth}</div>
                  </motion.div>
                ))}
              </div>
            </section>

            {/* 投資提案 */}
            <section className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-8 border border-primary/20">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div>
                  <h2 className="text-3xl font-bold mb-4">投資提案</h2>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">調達目標:</span>
                      <span className="text-2xl font-bold text-primary">$5.0M</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">評価額:</span>
                      <span className="text-xl font-bold">$25.0M</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">ラウンド:</span>
                      <span className="font-semibold">シード</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">使用用途:</span>
                      <span className="font-semibold">製品開発・マーケティング</span>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <h3 className="text-xl font-bold">なぜ今投資すべきか？</h3>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                      <span className="text-sm">Web3市場の急速な成長（年率138%）</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                      <span className="text-sm">競合優位性のある統合プラットフォーム</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                      <span className="text-sm">多様化された収益モデル</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                      <span className="text-sm">経験豊富なチームと実証済みの技術</span>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </motion.div>
        )}

        {/* 市場機会セクション */}
        {activeSection === 'market' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-12"
          >
            <section>
              <h2 className="text-3xl font-bold mb-8">巨大な市場機会</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {marketOpportunity.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-card rounded-xl p-6 border"
                  >
                    <h3 className="font-semibold mb-4">{item.metric}</h3>
                    <div className="flex items-end gap-4 mb-4">
                      <div>
                        <div className="text-sm text-muted-foreground">現在</div>
                        <div className="text-2xl font-bold">{item.current}</div>
                      </div>
                      <ArrowRight className="w-6 h-6 text-muted-foreground mb-2" />
                      <div>
                        <div className="text-sm text-muted-foreground">予測</div>
                        <div className="text-2xl font-bold text-primary">{item.projected}</div>
                      </div>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="font-semibold text-green-500">{item.growth}</span>
                      <span className="text-muted-foreground">{item.timeframe}</span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-2">出典: {item.source}</div>
                  </motion.div>
                ))}
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold mb-8">競合優位性</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {competitiveAdvantages.map((advantage, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-card rounded-xl p-6 border"
                  >
                    <div className="flex items-start gap-4">
                      <advantage.icon className="w-8 h-8 text-primary mt-1" />
                      <div>
                        <h3 className="font-semibold mb-2">{advantage.title}</h3>
                        <p className="text-sm text-muted-foreground mb-3">{advantage.description}</p>
                        <div className="bg-primary/10 rounded-lg p-3">
                          <div className="text-xs font-semibold text-primary mb-1">インパクト:</div>
                          <div className="text-sm">{advantage.impact}</div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </section>
          </motion.div>
        )}

        {/* ビジネスモデルセクション */}
        {activeSection === 'business' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-12"
          >
            <section>
              <h2 className="text-3xl font-bold mb-8">多様化された収益モデル</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-card rounded-xl p-6 border">
                  <h3 className="font-semibold mb-4 text-green-600">安定収益 (30%)</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">サブスクリプション</span>
                      <span className="font-semibold">21.1%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">B2B/エンタープライズ</span>
                      <span className="font-semibold">8.7%</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-4">
                    予測可能な継続収益で安定した成長基盤
                  </p>
                </div>

                <div className="bg-card rounded-xl p-6 border">
                  <h3 className="font-semibold mb-4 text-blue-600">取引連動収益 (22%)</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">NFT取引手数料</span>
                      <span className="font-semibold">11.5%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">オンランプ手数料</span>
                      <span className="font-semibold">6.7%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">DeFi手数料</span>
                      <span className="font-semibold">3.8%</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-4">
                    市場成長と連動した高成長ポテンシャル
                  </p>
                </div>

                <div className="bg-card rounded-xl p-6 border">
                  <h3 className="font-semibold mb-4 text-purple-600">エコシステム収益 (40%)</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">広告収益</span>
                      <span className="font-semibold">20.8%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">DAppストア</span>
                      <span className="font-semibold">19.5%</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-4">
                    プラットフォーム効果による指数関数的成長
                  </p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold mb-8">資金使途</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-4">
                  {fundingUse.map((item, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-card rounded-xl p-4 border"
                    >
                      <div className="flex items-center gap-4">
                        <div className={cn("w-3 h-3 rounded-full", item.color)}></div>
                        <div className="flex-1">
                          <div className="flex justify-between items-center mb-2">
                            <h3 className="font-semibold">{item.category}</h3>
                            <div className="text-right">
                              <div className="font-bold">{item.amount}</div>
                              <div className="text-sm text-muted-foreground">{item.percentage}%</div>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground">{item.description}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-xl p-6 border border-primary/20">
                  <h3 className="font-semibold mb-4">調達スケジュール</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>シードラウンド</span>
                      <span className="font-bold text-primary">$5.0M</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>シリーズA (予定)</span>
                      <span className="font-bold">$15.0M</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>シリーズB (予定)</span>
                      <span className="font-bold">$50.0M</span>
                    </div>
                  </div>
                  <div className="mt-6 p-4 bg-white/50 rounded-lg">
                    <h4 className="font-semibold mb-2">投資家特典</h4>
                    <div className="space-y-1 text-sm">
                      <div>• 四半期レポート</div>
                      <div>• 投資家限定イベント</div>
                      <div>• プロダクト早期アクセス</div>
                      <div>• 戦略的アドバイザリー参加</div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </motion.div>
        )}

        {/* 財務予測セクション */}
        {activeSection === 'financials' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-12"
          >
            <section>
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-3xl font-bold">財務予測</h2>
                <Button 
                  variant="outline"
                  onClick={() => navigate('/revenue-forecast')}
                >
                  <BarChart3 className="w-4 h-4 mr-2" />
                  詳細分析を見る
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl p-6 text-white">
                  <h3 className="text-lg font-semibold mb-2">Year 1</h3>
                  <div className="text-3xl font-bold mb-4">$991K</div>
                  <div className="space-y-2 text-sm opacity-90">
                    <div className="flex justify-between">
                      <span>MAU:</span>
                      <span>50K</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Proユーザー:</span>
                      <span>750</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl p-6 text-white">
                  <h3 className="text-lg font-semibold mb-2">Year 2</h3>
                  <div className="text-3xl font-bold mb-4">$5.6M</div>
                  <div className="space-y-2 text-sm opacity-90">
                    <div className="flex justify-between">
                      <span>MAU:</span>
                      <span>200K</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Proユーザー:</span>
                      <span>5K</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl p-6 text-white">
                  <h3 className="text-lg font-semibold mb-2">Year 3</h3>
                  <div className="text-3xl font-bold mb-4">$18.0M</div>
                  <div className="space-y-2 text-sm opacity-90">
                    <div className="flex justify-between">
                      <span>MAU:</span>
                      <span>500K</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Proユーザー:</span>
                      <span>17.5K</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-card rounded-xl p-6 border">
                <h3 className="font-semibold mb-4">投資収益率 (ROI) 分析</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-500 mb-2">360%</div>
                    <div className="text-sm text-muted-foreground">3年間ROI</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-500 mb-2">2.1年</div>
                    <div className="text-sm text-muted-foreground">投資回収期間</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-500 mb-2">$4.9</div>
                    <div className="text-sm text-muted-foreground">投資$1あたりのリターン</div>
                  </div>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold mb-8">マイルストーン</h2>
              <div className="space-y-4">
                {milestones.map((milestone, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-card rounded-xl p-6 border"
                  >
                    <div className="flex items-start gap-4">
                      <div className={cn(
                        "w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold",
                        milestone.status === '完了' ? 'bg-green-500' :
                        milestone.status === '進行中' ? 'bg-blue-500' : 'bg-gray-400'
                      )}>
                        {milestone.quarter.split(' ')[1]}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold">{milestone.title}</h3>
                          <span className="text-sm text-muted-foreground">{milestone.quarter}</span>
                          <span className={cn(
                            "px-2 py-1 rounded-full text-xs font-semibold",
                            milestone.status === '完了' ? 'bg-green-100 text-green-800' :
                            milestone.status === '進行中' ? 'bg-blue-100 text-blue-800' :
                            'bg-gray-100 text-gray-800'
                          )}>
                            {milestone.status}
                          </span>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                          {milestone.achievements.map((achievement, idx) => (
                            <div key={idx} className="flex items-center gap-2 text-sm">
                              <CheckCircle className={cn(
                                "w-4 h-4",
                                milestone.status === '完了' ? 'text-green-500' :
                                milestone.status === '進行中' ? 'text-blue-500' : 'text-gray-400'
                              )} />
                              <span>{achievement}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </section>
          </motion.div>
        )}

        {/* チームセクション */}
        {activeSection === 'team' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-12"
          >
            <section>
              <h2 className="text-3xl font-bold mb-8">経験豊富なチーム</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {teamMembers.map((member, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-card rounded-xl p-6 border"
                  >
                    <div className="flex items-start gap-4">
                      <div className="text-4xl">{member.image}</div>
                      <div>
                        <h3 className="font-semibold text-lg">{member.name}</h3>
                        <div className="text-primary font-medium mb-2">{member.role}</div>
                        <p className="text-sm text-muted-foreground">{member.background}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold mb-8">アドバイザー</h2>
              <div className="bg-card rounded-xl p-6 border">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl mb-2">👨‍💼</div>
                    <h3 className="font-semibold">Brian Armstrong</h3>
                    <div className="text-sm text-primary">元Coinbase CEO</div>
                    <p className="text-xs text-muted-foreground mt-2">暗号資産業界のパイオニア</p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl mb-2">👩‍💼</div>
                    <h3 className="font-semibold">Meltem Demirors</h3>
                    <div className="text-sm text-primary">CoinShares CSO</div>
                    <p className="text-xs text-muted-foreground mt-2">機関投資家向けWeb3専門家</p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl mb-2">👨‍💻</div>
                    <h3 className="font-semibold">Andre Cronje</h3>
                    <div className="text-sm text-primary">DeFi開発者</div>
                    <p className="text-xs text-muted-foreground mt-2">Yearn Finance創設者</p>
                  </div>
                </div>
              </div>
            </section>
          </motion.div>
        )}

        {/* お問い合わせセクション */}
        {activeSection === 'contact' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-12"
          >
            <section>
              <h2 className="text-3xl font-bold mb-8">投資に関するお問い合わせ</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div>
                    <h3 className="font-semibold mb-4">連絡先情報</h3>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <Mail className="w-5 h-5 text-primary" />
                        <span>investors@cheata.app</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Phone className="w-5 h-5 text-primary" />
                        <span>+81-3-1234-5678</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Building className="w-5 h-5 text-primary" />
                        <span>東京都渋谷区神宮前1-1-1</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-4">投資家向け資料</h3>
                    <div className="space-y-3">
                      <Button variant="outline" className="w-full justify-start">
                        <FileText className="w-4 h-4 mr-2" />
                        ピッチデック (PDF)
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <BarChart3 className="w-4 h-4 mr-2" />
                        財務モデル (Excel)
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <Presentation className="w-4 h-4 mr-2" />
                        デモビデオ (MP4)
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="bg-card rounded-xl p-6 border">
                  <h3 className="font-semibold mb-4">お問い合わせフォーム</h3>
                  <form onSubmit={handleContactSubmit} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">お名前 *</label>
                      <Input
                        required
                        value={contactForm.name}
                        onChange={(e) => setContactForm(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="山田太郎"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">メールアドレス *</label>
                      <Input
                        type="email"
                        required
                        value={contactForm.email}
                        onChange={(e) => setContactForm(prev => ({ ...prev, email: e.target.value }))}
                        placeholder="yamada@example.com"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">会社名</label>
                      <Input
                        value={contactForm.company}
                        onChange={(e) => setContactForm(prev => ({ ...prev, company: e.target.value }))}
                        placeholder="株式会社サンプル"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">メッセージ *</label>
                      <textarea
                        required
                        value={contactForm.message}
                        onChange={(e) => setContactForm(prev => ({ ...prev, message: e.target.value }))}
                        placeholder="投資に関するご質問やご要望をお聞かせください"
                        className="w-full p-3 border border-border rounded-lg resize-none h-24"
                      />
                    </div>
                    <Button type="submit" className="w-full">
                      <Mail className="w-4 h-4 mr-2" />
                      送信する
                    </Button>
                  </form>
                </div>
              </div>
            </section>
          </motion.div>
        )}

        {/* 最終CTA */}
        <section className="mt-16 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-primary to-accent rounded-2xl p-8 text-white"
          >
            <Rocket className="w-16 h-16 mx-auto mb-6" />
            <h2 className="text-3xl font-bold mb-4">Web3の未来に投資しませんか？</h2>
            <p className="mb-6 opacity-90 max-w-2xl mx-auto">
              CheatAと共に、次世代インターネットの基盤を構築し、
              37億円の収益ポテンシャルを実現しましょう
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-white text-primary hover:bg-white/90 h-14 px-8"
                onClick={() => setActiveSection('contact')}
              >
                <Mail className="mr-2 w-5 h-5" />
                投資相談を開始
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white/30 text-white hover:bg-white/10 h-14 px-8"
                onClick={() => navigate('/demo')}
              >
                <ExternalLink className="mr-2 w-5 h-5" />
                プロダクトを体験
              </Button>
            </div>
          </motion.div>
        </section>
      </main>
    </div>
  );
}