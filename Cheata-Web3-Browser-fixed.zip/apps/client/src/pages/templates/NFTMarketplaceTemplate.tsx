import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  Search,
  Filter,
  Grid3X3,
  List,
  Heart,
  Share2,
  Eye,
  Zap,
  TrendingUp,
  Clock,
  Users,
  Star,
  ShoppingCart,
  Wallet,
  ExternalLink
} from "lucide-react";
import { cn } from "@/lib/utils";
import { IMAGES } from "@/assets/images";

export default function NFTMarketplaceTemplate() {
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', name: 'すべて', count: 1247 },
    { id: 'art', name: 'アート', count: 456 },
    { id: 'gaming', name: 'ゲーミング', count: 234 },
    { id: 'music', name: 'ミュージック', count: 123 },
    { id: 'photography', name: '写真', count: 189 },
    { id: 'collectibles', name: 'コレクティブル', count: 245 }
  ];

  const nfts = [
    {
      id: 1,
      title: "Cosmic Dreams #001",
      creator: "ArtistDAO",
      price: "2.5 ETH",
      usdPrice: "$8,125",
      image: IMAGES.BROWSER_INTERFACE_1,
      likes: 234,
      views: 1567,
      category: "art",
      rarity: "Legendary",
      isLiked: false
    },
    {
      id: 2,
      title: "Cyber Punk Warrior",
      creator: "GameStudio",
      price: "1.8 ETH",
      usdPrice: "$5,850",
      image: IMAGES.BROWSER_INTERFACE_2,
      likes: 189,
      views: 892,
      category: "gaming",
      rarity: "Epic",
      isLiked: true
    },
    {
      id: 3,
      title: "Digital Harmony",
      creator: "MusicNFT",
      price: "0.9 ETH",
      usdPrice: "$2,925",
      image: IMAGES.BROWSER_INTERFACE_3,
      likes: 156,
      views: 743,
      category: "music",
      rarity: "Rare",
      isLiked: false
    },
    {
      id: 4,
      title: "Nature's Beauty",
      creator: "PhotoPro",
      price: "1.2 ETH",
      usdPrice: "$3,900",
      image: IMAGES.BROWSER_INTERFACE_4,
      likes: 298,
      views: 1234,
      category: "photography",
      rarity: "Epic",
      isLiked: false
    },
    {
      id: 5,
      title: "Rare Collectible #777",
      creator: "CollectorDAO",
      price: "5.0 ETH",
      usdPrice: "$16,250",
      image: IMAGES.BROWSER_INTERFACE_5,
      likes: 567,
      views: 2341,
      category: "collectibles",
      rarity: "Mythic",
      isLiked: true
    },
    {
      id: 6,
      title: "Abstract Vision",
      creator: "ModernArt",
      price: "3.2 ETH",
      usdPrice: "$10,400",
      image: IMAGES.BROWSER_INTERFACE_6,
      likes: 345,
      views: 1678,
      category: "art",
      rarity: "Legendary",
      isLiked: false
    }
  ];

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'Mythic': return 'text-purple-500 bg-purple-500/10 border-purple-500/20';
      case 'Legendary': return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20';
      case 'Epic': return 'text-blue-500 bg-blue-500/10 border-blue-500/20';
      case 'Rare': return 'text-green-500 bg-green-500/10 border-green-500/20';
      default: return 'text-gray-500 bg-gray-500/10 border-gray-500/20';
    }
  };

  const filteredNFTs = nfts.filter(nft => {
    const matchesSearch = nft.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         nft.creator.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || nft.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/dapps-builder")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              テンプレート一覧に戻る
            </Button>
            <div className="flex items-center gap-3">
              <div className="text-3xl">🎨</div>
              <div className="font-brand text-2xl font-bold text-primary">
                NFTマーケットプレイス
              </div>
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            デジタルアートとコレクティブルの究極のマーケットプレイス。
            クリエイターと コレクターを繋ぐ革新的なプラットフォーム。
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-8">
        {/* 統計情報 */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-primary mb-2">1,247</div>
            <div className="text-sm text-muted-foreground">総NFT数</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-green-500 mb-2">456</div>
            <div className="text-sm text-muted-foreground">アクティブユーザー</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-yellow-500 mb-2">234 ETH</div>
            <div className="text-sm text-muted-foreground">総取引量</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-purple-500 mb-2">89</div>
            <div className="text-sm text-muted-foreground">新着（24h）</div>
          </motion.div>
        </div>

        {/* 検索・フィルター */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="NFTを検索..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <Filter className="w-4 h-4 mr-2" />
              フィルター
            </Button>
            <div className="flex border rounded-lg">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="rounded-r-none"
              >
                <Grid3X3 className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="rounded-l-none"
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="flex gap-8">
          {/* サイドバー - カテゴリ */}
          <div className="w-64 hidden md:block">
            <div className="bg-card rounded-xl border p-6">
              <h3 className="font-semibold mb-4">カテゴリ</h3>
              <div className="space-y-2">
                {categories.map(category => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={cn(
                      "w-full text-left px-3 py-2 rounded-lg text-sm transition-colors",
                      selectedCategory === category.id
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-muted"
                    )}
                  >
                    <div className="flex justify-between items-center">
                      <span>{category.name}</span>
                      <span className="text-xs opacity-70">{category.count}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* NFTグリッド */}
          <div className="flex-1">
            <div className={cn(
              "grid gap-6",
              viewMode === 'grid' 
                ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" 
                : "grid-cols-1"
            )}>
              {filteredNFTs.map((nft, index) => (
                <motion.div
                  key={nft.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-card rounded-xl border overflow-hidden hover:shadow-lg transition-all group cursor-pointer"
                >
                  {/* NFT画像 */}
                  <div className="relative aspect-square overflow-hidden">
                    <img 
                      src={nft.image} 
                      alt={nft.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 right-3 flex gap-2">
                      <div className={cn(
                        "px-2 py-1 rounded-full text-xs font-semibold border",
                        getRarityColor(nft.rarity)
                      )}>
                        {nft.rarity}
                      </div>
                    </div>
                    <div className="absolute bottom-3 left-3 right-3 flex justify-between items-center">
                      <div className="flex items-center gap-2 text-white text-sm">
                        <Eye className="w-4 h-4" />
                        <span>{nft.views}</span>
                      </div>
                      <Button
                        size="sm"
                        variant="secondary"
                        className="opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Heart className={cn(
                          "w-4 h-4",
                          nft.isLiked ? "fill-red-500 text-red-500" : ""
                        )} />
                      </Button>
                    </div>
                  </div>

                  {/* NFT情報 */}
                  <div className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold text-lg truncate">{nft.title}</h3>
                      <Button variant="ghost" size="sm">
                        <Share2 className="w-4 h-4" />
                      </Button>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">by {nft.creator}</p>
                    
                    <div className="flex justify-between items-center mb-4">
                      <div>
                        <div className="text-xl font-bold">{nft.price}</div>
                        <div className="text-sm text-muted-foreground">{nft.usdPrice}</div>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Heart className="w-4 h-4" />
                        <span>{nft.likes}</span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button className="flex-1">
                        <ShoppingCart className="w-4 h-4 mr-2" />
                        購入
                      </Button>
                      <Button variant="outline">
                        <Wallet className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* ロードモアボタン */}
            <div className="text-center mt-12">
              <Button variant="outline" size="lg">
                さらに読み込む
              </Button>
            </div>
          </div>
        </div>
      </main>

      {/* フローティングアクションボタン */}
      <div className="fixed bottom-8 right-8 flex flex-col gap-3">
        <Button size="lg" className="rounded-full shadow-lg">
          <Zap className="w-5 h-5 mr-2" />
          NFT作成
        </Button>
      </div>
    </div>
  );
}