import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  Gamepad2,
  Trophy,
  Users,
  Star,
  Play,
  Pause,
  Download,
  Heart,
  Share2,
  MessageSquare,
  Zap,
  Coins,
  Crown,
  Sword,
  Shield,
  Target,
  Timer,
  Award,
  TrendingUp,
  Calendar,
  Search,
  Filter,
  Plus
} from "lucide-react";
import { cn } from "@/lib/utils";
import { IMAGES } from "@/assets/images";

export default function GamingPlatformTemplate() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'games' | 'tournaments' | 'leaderboard' | 'marketplace'>('games');
  const [selectedGame, setSelectedGame] = useState<number | null>(null);

  const games = [
    {
      id: 1,
      title: "Crypto Warriors",
      genre: "RPG",
      rating: 4.8,
      players: "12.5K",
      image: IMAGES.BROWSER_INTERFACE_1,
      description: "Epic blockchain RPG with NFT characters and P2E mechanics",
      developer: "GameStudio DAO",
      price: "Free to Play",
      earnings: "Up to 50 CHEATA/day",
      status: "live",
      tags: ["P2E", "NFT", "RPG", "Multiplayer"]
    },
    {
      id: 2,
      title: "DeFi Racing",
      genre: "Racing",
      rating: 4.6,
      players: "8.9K",
      image: IMAGES.BROWSER_INTERFACE_2,
      description: "High-speed racing with DeFi rewards and NFT cars",
      developer: "Speed Labs",
      price: "0.1 ETH",
      earnings: "Up to 25 CHEATA/day",
      status: "live",
      tags: ["Racing", "DeFi", "NFT", "Competitive"]
    },
    {
      id: 3,
      title: "MetaVerse Builder",
      genre: "Simulation",
      rating: 4.9,
      players: "15.2K",
      image: IMAGES.BROWSER_INTERFACE_3,
      description: "Build and monetize your virtual world",
      developer: "Meta Builders",
      price: "Free to Play",
      earnings: "Up to 100 CHEATA/day",
      status: "beta",
      tags: ["Metaverse", "Building", "Social", "Creative"]
    },
    {
      id: 4,
      title: "Battle Royale Crypto",
      genre: "Battle Royale",
      rating: 4.7,
      players: "25.8K",
      image: IMAGES.BROWSER_INTERFACE_4,
      description: "Last player standing wins crypto rewards",
      developer: "Battle Games",
      price: "Free to Play",
      earnings: "Up to 75 CHEATA/day",
      status: "live",
      tags: ["Battle Royale", "Competitive", "P2E", "Action"]
    },
    {
      id: 5,
      title: "NFT Card Masters",
      genre: "Card Game",
      rating: 4.5,
      players: "6.7K",
      image: IMAGES.BROWSER_INTERFACE_5,
      description: "Strategic card battles with tradeable NFT cards",
      developer: "Card Legends",
      price: "0.05 ETH",
      earnings: "Up to 30 CHEATA/day",
      status: "live",
      tags: ["Card Game", "Strategy", "NFT", "Trading"]
    },
    {
      id: 6,
      title: "Space Miners",
      genre: "Strategy",
      rating: 4.4,
      players: "4.3K",
      image: IMAGES.BROWSER_INTERFACE_6,
      description: "Mine asteroids and build your space empire",
      developer: "Cosmic Games",
      price: "Free to Play",
      earnings: "Up to 40 CHEATA/day",
      status: "coming_soon",
      tags: ["Strategy", "Mining", "Space", "Economy"]
    }
  ];

  const tournaments = [
    {
      id: 1,
      name: "Crypto Warriors Championship",
      game: "Crypto Warriors",
      prize: "10,000 CHEATA",
      participants: 256,
      maxParticipants: 512,
      startDate: "2026-03-01",
      endDate: "2026-03-07",
      status: "registration",
      entryFee: "5 CHEATA"
    },
    {
      id: 2,
      name: "DeFi Racing Grand Prix",
      game: "DeFi Racing",
      prize: "5,000 CHEATA",
      participants: 128,
      maxParticipants: 256,
      startDate: "2026-03-03",
      endDate: "2026-03-05",
      status: "live",
      entryFee: "10 CHEATA"
    },
    {
      id: 3,
      name: "Battle Royale Weekly",
      game: "Battle Royale Crypto",
      prize: "2,500 CHEATA",
      participants: 64,
      maxParticipants: 100,
      startDate: "2026-03-02",
      endDate: "2026-03-02",
      status: "ended",
      entryFee: "Free"
    }
  ];

  const leaderboard = [
    { rank: 1, player: "CryptoKing", earnings: "15,250 CHEATA", games: 45, winRate: "78%" },
    { rank: 2, player: "GameMaster", earnings: "12,890 CHEATA", games: 38, winRate: "72%" },
    { rank: 3, player: "NFTHunter", earnings: "11,560 CHEATA", games: 42, winRate: "69%" },
    { rank: 4, player: "DeFiRacer", earnings: "9,870 CHEATA", games: 35, winRate: "74%" },
    { rank: 5, player: "MetaBuilder", earnings: "8,920 CHEATA", games: 29, winRate: "81%" }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live': return 'text-green-500 bg-green-500/10 border-green-500/20';
      case 'beta': return 'text-blue-500 bg-blue-500/10 border-blue-500/20';
      case 'coming_soon': return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20';
      case 'registration': return 'text-purple-500 bg-purple-500/10 border-purple-500/20';
      case 'ended': return 'text-gray-500 bg-gray-500/10 border-gray-500/20';
      default: return 'text-gray-500 bg-gray-500/10 border-gray-500/20';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'live': return 'プレイ中';
      case 'beta': return 'ベータ版';
      case 'coming_soon': return '近日公開';
      case 'registration': return '参加受付中';
      case 'ended': return '終了';
      default: return '不明';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/dapps-builder")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              テンプレート一覧に戻る
            </Button>
            <div className="flex items-center gap-3">
              <div className="text-3xl">🎮</div>
              <div className="font-brand text-2xl font-bold text-primary">
                ゲーミングプラットフォーム
              </div>
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            Play-to-Earnゲームとトーナメントの究極のプラットフォーム。
            ゲームをプレイして暗号資産を獲得しよう。
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-8">
        {/* 統計情報 */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-primary mb-2">73.4K</div>
            <div className="text-sm text-muted-foreground">アクティブプレイヤー</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-green-500 mb-2">2.4M</div>
            <div className="text-sm text-muted-foreground">総獲得CHEATA</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-yellow-500 mb-2">156</div>
            <div className="text-sm text-muted-foreground">ゲーム数</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-purple-500 mb-2">23</div>
            <div className="text-sm text-muted-foreground">開催中トーナメント</div>
          </motion.div>
        </div>

        {/* タブナビゲーション */}
        <div className="flex gap-2 mb-8 bg-muted/50 p-1 rounded-xl w-fit">
          {[
            { id: 'games', label: 'ゲーム', icon: Gamepad2 },
            { id: 'tournaments', label: 'トーナメント', icon: Trophy },
            { id: 'leaderboard', label: 'ランキング', icon: Crown },
            { id: 'marketplace', label: 'マーケット', icon: Coins }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
                activeTab === tab.id
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* メインパネル */}
          <div className="lg:col-span-2">
            <AnimatePresence mode="wait">
              {/* ゲームタブ */}
              {activeTab === 'games' && (
                <motion.div
                  key="games"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold">ゲーム一覧</h2>
                    <div className="flex gap-2">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input placeholder="ゲームを検索..." className="pl-10 w-64" />
                      </div>
                      <Button variant="outline" size="sm">
                        <Filter className="w-4 h-4 mr-2" />
                        フィルター
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {games.map((game, index) => (
                      <motion.div
                        key={game.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="bg-card rounded-xl border overflow-hidden hover:shadow-lg transition-all group cursor-pointer"
                        onClick={() => setSelectedGame(selectedGame === game.id ? null : game.id)}
                      >
                        {/* ゲーム画像 */}
                        <div className="relative aspect-video overflow-hidden">
                          <img 
                            src={game.image} 
                            alt={game.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute top-3 left-3 flex gap-2">
                            <div className={cn(
                              "px-2 py-1 rounded-full text-xs font-semibold border",
                              getStatusColor(game.status)
                            )}>
                              {getStatusText(game.status)}
                            </div>
                            <div className="px-2 py-1 bg-black/50 text-white text-xs rounded-full">
                              {game.genre}
                            </div>
                          </div>
                          <div className="absolute top-3 right-3">
                            <Button size="sm" variant="secondary" className="opacity-0 group-hover:opacity-100 transition-opacity">
                              <Heart className="w-4 h-4" />
                            </Button>
                          </div>
                          <div className="absolute bottom-3 left-3 right-3 flex justify-between items-center">
                            <div className="flex items-center gap-2 text-white text-sm">
                              <Users className="w-4 h-4" />
                              <span>{game.players}</span>
                            </div>
                            <div className="flex items-center gap-1 text-white text-sm">
                              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                              <span>{game.rating}</span>
                            </div>
                          </div>
                        </div>

                        {/* ゲーム情報 */}
                        <div className="p-4">
                          <div className="flex justify-between items-start mb-2">
                            <h3 className="font-semibold text-lg">{game.title}</h3>
                            <Button variant="ghost" size="sm">
                              <Share2 className="w-4 h-4" />
                            </Button>
                          </div>
                          <p className="text-sm text-muted-foreground mb-3">{game.description}</p>
                          
                          <div className="flex justify-between items-center mb-3">
                            <div>
                              <div className="text-sm text-muted-foreground">開発者</div>
                              <div className="font-medium">{game.developer}</div>
                            </div>
                            <div className="text-right">
                              <div className="text-sm text-muted-foreground">価格</div>
                              <div className="font-medium">{game.price}</div>
                            </div>
                          </div>

                          <div className="mb-4">
                            <div className="text-sm text-muted-foreground mb-1">獲得可能</div>
                            <div className="font-semibold text-green-500">{game.earnings}</div>
                          </div>

                          <div className="flex flex-wrap gap-1 mb-4">
                            {game.tags.map((tag, tagIndex) => (
                              <span 
                                key={tagIndex}
                                className="px-2 py-1 bg-muted text-xs rounded-full"
                              >
                                {tag}
                              </span>
                            ))}
                          </div>

                          <div className="flex gap-2">
                            <Button className="flex-1" disabled={game.status === 'coming_soon'}>
                              <Play className="w-4 h-4 mr-2" />
                              {game.status === 'coming_soon' ? '近日公開' : 'プレイ'}
                            </Button>
                            <Button variant="outline">
                              <Download className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>

                        {/* 詳細表示 */}
                        <AnimatePresence>
                          {selectedGame === game.id && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              className="px-4 pb-4 border-t border-border"
                            >
                              <div className="pt-4">
                                <h4 className="font-semibold mb-2">ゲーム詳細</h4>
                                <div className="grid grid-cols-2 gap-4 text-sm">
                                  <div>
                                    <div className="text-muted-foreground">リリース日</div>
                                    <div>2026-01-15</div>
                                  </div>
                                  <div>
                                    <div className="text-muted-foreground">最終更新</div>
                                    <div>2026-02-25</div>
                                  </div>
                                  <div>
                                    <div className="text-muted-foreground">ファイルサイズ</div>
                                    <div>2.4 GB</div>
                                  </div>
                                  <div>
                                    <div className="text-muted-foreground">対応言語</div>
                                    <div>日本語, English</div>
                                  </div>
                                </div>
                                <div className="flex gap-2 mt-4">
                                  <Button variant="outline" size="sm">
                                    <MessageSquare className="w-4 h-4 mr-2" />
                                    レビュー
                                  </Button>
                                  <Button variant="outline" size="sm">
                                    <Trophy className="w-4 h-4 mr-2" />
                                    実績
                                  </Button>
                                </div>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* トーナメントタブ */}
              {activeTab === 'tournaments' && (
                <motion.div
                  key="tournaments"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold">トーナメント</h2>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      トーナメント作成
                    </Button>
                  </div>

                  <div className="space-y-4">
                    {tournaments.map((tournament, index) => (
                      <motion.div
                        key={tournament.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="bg-card rounded-xl border p-6"
                      >
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-xl font-semibold">{tournament.name}</h3>
                              <div className={cn(
                                "px-2 py-1 rounded-full text-xs font-semibold border",
                                getStatusColor(tournament.status)
                              )}>
                                {getStatusText(tournament.status)}
                              </div>
                            </div>
                            <p className="text-muted-foreground mb-2">{tournament.game}</p>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <span>参加費: {tournament.entryFee}</span>
                              <span>期間: {tournament.startDate} - {tournament.endDate}</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-yellow-500">{tournament.prize}</div>
                            <div className="text-sm text-muted-foreground">賞金総額</div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-4">
                            <div className="flex items-center gap-2">
                              <Users className="w-4 h-4 text-muted-foreground" />
                              <span className="text-sm">
                                {tournament.participants}/{tournament.maxParticipants} 参加者
                              </span>
                            </div>
                            <div className="w-32 bg-muted rounded-full h-2">
                              <div 
                                className="bg-primary h-2 rounded-full"
                                style={{ 
                                  width: `${(tournament.participants / tournament.maxParticipants) * 100}%` 
                                }}
                              />
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button 
                              size="sm" 
                              disabled={tournament.status === 'ended' || tournament.status === 'live'}
                            >
                              {tournament.status === 'registration' ? '参加登録' : 
                               tournament.status === 'live' ? '観戦' : '終了'}
                            </Button>
                            <Button variant="outline" size="sm">
                              詳細
                            </Button>
                          </div>
                        </div>

                        {tournament.status === 'live' && (
                          <div className="bg-muted/30 rounded-lg p-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                                <span className="text-sm font-medium">ライブ配信中</span>
                              </div>
                              <Button variant="outline" size="sm">
                                <Play className="w-4 h-4 mr-2" />
                                観戦
                              </Button>
                            </div>
                          </div>
                        )}
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* ランキングタブ */}
              {activeTab === 'leaderboard' && (
                <motion.div
                  key="leaderboard"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold">ランキング</h2>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Calendar className="w-4 h-4 mr-2" />
                        今月
                      </Button>
                      <Button variant="outline" size="sm">
                        <TrendingUp className="w-4 h-4 mr-2" />
                        全期間
                      </Button>
                    </div>
                  </div>

                  <div className="bg-card rounded-xl border overflow-hidden">
                    <div className="p-6 border-b border-border">
                      <h3 className="text-xl font-semibold">トップゲーマー</h3>
                    </div>
                    <div className="divide-y divide-border">
                      {leaderboard.map((player, index) => (
                        <div key={index} className="p-6 hover:bg-muted/30 transition-colors">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <div className={cn(
                                "w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg",
                                player.rank === 1 ? "bg-yellow-500 text-white" :
                                player.rank === 2 ? "bg-gray-400 text-white" :
                                player.rank === 3 ? "bg-amber-600 text-white" :
                                "bg-muted text-muted-foreground"
                              )}>
                                {player.rank === 1 ? <Crown className="w-6 h-6" /> :
                                 player.rank === 2 ? <Award className="w-6 h-6" /> :
                                 player.rank === 3 ? <Trophy className="w-6 h-6" /> :
                                 `#${player.rank}`}
                              </div>
                              <div>
                                <div className="font-semibold text-lg">{player.player}</div>
                                <div className="text-sm text-muted-foreground">
                                  {player.games}ゲーム | 勝率 {player.winRate}
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-xl font-bold text-green-500">{player.earnings}</div>
                              <div className="text-sm text-muted-foreground">総獲得額</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* あなたのランキング */}
                  <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-xl p-6 border border-primary/20">
                    <h3 className="text-lg font-semibold mb-4">あなたのランキング</h3>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center font-bold text-lg">
                          #42
                        </div>
                        <div>
                          <div className="font-semibold text-lg">あなた</div>
                          <div className="text-sm text-muted-foreground">
                            12ゲーム | 勝率 65%
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-bold text-green-500">1,250 CHEATA</div>
                        <div className="text-sm text-muted-foreground">総獲得額</div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* マーケットプレイスタブ */}
              {activeTab === 'marketplace' && (
                <motion.div
                  key="marketplace"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold">ゲームアイテム マーケット</h2>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      アイテム出品
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[
                      { name: "Legendary Sword", game: "Crypto Warriors", price: "2.5 ETH", rarity: "Legendary" },
                      { name: "Speed Boost Car", game: "DeFi Racing", price: "1.2 ETH", rarity: "Epic" },
                      { name: "Magic Staff", game: "Crypto Warriors", price: "0.8 ETH", rarity: "Rare" },
                      { name: "Racing Helmet", game: "DeFi Racing", price: "0.5 ETH", rarity: "Common" },
                      { name: "Dragon Pet", game: "Crypto Warriors", price: "5.0 ETH", rarity: "Mythic" },
                      { name: "Turbo Engine", game: "DeFi Racing", price: "1.8 ETH", rarity: "Epic" }
                    ].map((item, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="bg-card rounded-xl border overflow-hidden hover:shadow-lg transition-all"
                      >
                        <div className="aspect-square bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                          <div className="text-4xl">
                            {item.name.includes('Sword') ? <Sword className="w-16 h-16" /> :
                             item.name.includes('Car') || item.name.includes('Engine') || item.name.includes('Helmet') ? <Zap className="w-16 h-16" /> :
                             item.name.includes('Staff') ? <Target className="w-16 h-16" /> :
                             <Shield className="w-16 h-16" />}
                          </div>
                        </div>
                        <div className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="font-semibold">{item.name}</h3>
                            <div className={cn(
                              "px-2 py-1 rounded-full text-xs font-semibold",
                              item.rarity === 'Mythic' ? 'bg-purple-500/10 text-purple-500' :
                              item.rarity === 'Legendary' ? 'bg-yellow-500/10 text-yellow-500' :
                              item.rarity === 'Epic' ? 'bg-blue-500/10 text-blue-500' :
                              item.rarity === 'Rare' ? 'bg-green-500/10 text-green-500' :
                              'bg-gray-500/10 text-gray-500'
                            )}>
                              {item.rarity}
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground mb-3">{item.game}</p>
                          <div className="flex items-center justify-between mb-4">
                            <div className="text-xl font-bold">{item.price}</div>
                            <div className="flex items-center gap-1 text-sm text-muted-foreground">
                              <Heart className="w-4 h-4" />
                              <span>{Math.floor(Math.random() * 100) + 10}</span>
                            </div>
                          </div>
                          <Button className="w-full">
                            <Coins className="w-4 h-4 mr-2" />
                            購入
                          </Button>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* サイドパネル */}
          <div className="space-y-6">
            {/* あなたの統計 */}
            <div className="bg-card rounded-xl border p-6">
              <h3 className="font-semibold mb-4">あなたの統計</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">総獲得CHEATA</span>
                  <span className="font-semibold text-green-500">1,250</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">プレイ時間</span>
                  <span className="font-semibold">45時間</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">勝利数</span>
                  <span className="font-semibold">23</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">ランキング</span>
                  <span className="font-semibold">#42</span>
                </div>
              </div>
              <Button className="w-full mt-4" size="sm">
                <TrendingUp className="w-4 h-4 mr-2" />
                詳細統計
              </Button>
            </div>

            {/* 最新の活動 */}
            <div className="bg-card rounded-xl border p-6">
              <h3 className="font-semibold mb-4">最新の活動</h3>
              <div className="space-y-3">
                {[
                  { action: 'ゲーム勝利', game: 'Crypto Warriors', reward: '+25 CHEATA', time: '2時間前' },
                  { action: 'アイテム購入', game: 'DeFi Racing', reward: '-0.5 ETH', time: '5時間前' },
                  { action: 'トーナメント参加', game: 'Battle Royale', reward: '+100 CHEATA', time: '1日前' },
                  { action: 'レベルアップ', game: 'Crypto Warriors', reward: '+50 CHEATA', time: '2日前' }
                ].map((activity, index) => (
                  <div key={index} className="text-sm">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="font-medium">{activity.action}</div>
                        <div className="text-muted-foreground">{activity.game}</div>
                      </div>
                      <div className="text-right">
                        <div className={cn(
                          "font-semibold",
                          activity.reward.startsWith('+') ? 'text-green-500' : 'text-red-500'
                        )}>
                          {activity.reward}
                        </div>
                        <div className="text-xs text-muted-foreground">{activity.time}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* おすすめゲーム */}
            <div className="bg-card rounded-xl border p-6">
              <h3 className="font-semibold mb-4">おすすめゲーム</h3>
              <div className="space-y-3">
                {games.slice(0, 3).map((game, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <img 
                      src={game.image} 
                      alt={game.title}
                      className="w-12 h-12 rounded-lg object-cover"
                    />
                    <div className="flex-1">
                      <div className="font-medium text-sm">{game.title}</div>
                      <div className="text-xs text-muted-foreground">{game.genre}</div>
                      <div className="text-xs text-green-500">{game.earnings}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}