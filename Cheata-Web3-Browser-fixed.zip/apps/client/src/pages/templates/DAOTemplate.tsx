import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  Vote,
  Users,
  TrendingUp,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Plus,
  MessageSquare,
  BarChart3,
  Shield,
  Coins,
  Calendar,
  FileText,
  ExternalLink,
  ThumbsUp,
  ThumbsDown
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function DAOTemplate() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'proposals' | 'treasury' | 'members' | 'governance'>('proposals');
  const [selectedProposal, setSelectedProposal] = useState<number | null>(null);

  const proposals = [
    {
      id: 1,
      title: "プロトコル手数料を0.3%から0.25%に削減",
      description: "ユーザーの取引コストを削減し、プラットフォームの競争力を向上させる提案です。",
      proposer: "接続ウォレット",
      status: "active",
      votesFor: 1250000,
      votesAgainst: 340000,
      totalVotes: 1590000,
      quorum: 2000000,
      timeLeft: "2日 14時間",
      category: "Protocol",
      created: "2026-02-26"
    },
    {
      id: 2,
      title: "新しいトークンペアの追加承認",
      description: "MATIC/USDCペアをDEXに追加し、流動性インセンティブプログラムを開始する提案。",
      proposer: "0x9876...4321",
      status: "passed",
      votesFor: 2100000,
      votesAgainst: 450000,
      totalVotes: 2550000,
      quorum: 2000000,
      timeLeft: "終了",
      category: "Listing",
      created: "2026-02-20"
    },
    {
      id: 3,
      title: "コミュニティ開発基金の設立",
      description: "開発者エコシステムを支援するため、年間100万ドルの開発基金を設立する提案。",
      proposer: "0x5555...7777",
      status: "pending",
      votesFor: 0,
      votesAgainst: 0,
      totalVotes: 0,
      quorum: 2000000,
      timeLeft: "投票開始まで1日",
      category: "Treasury",
      created: "2026-02-28"
    },
    {
      id: 4,
      title: "ガバナンストークンの追加発行",
      description: "エコシステム拡大のため、総供給量の5%に相当するトークンを追加発行する提案。",
      proposer: "0x3333...9999",
      status: "rejected",
      votesFor: 800000,
      votesAgainst: 1900000,
      totalVotes: 2700000,
      quorum: 2000000,
      timeLeft: "終了",
      category: "Tokenomics",
      created: "2026-02-15"
    }
  ];

  const treasuryData = {
    totalValue: "$12.4M",
    assets: [
      { symbol: "ETH", amount: "2,450", value: "$7.95M", percentage: 64.1 },
      { symbol: "USDC", amount: "2,100,000", value: "$2.1M", percentage: 16.9 },
      { symbol: "CHEATA", amount: "5,000,000", value: "$1.25M", percentage: 10.1 },
      { symbol: "UNI", amount: "75,000", value: "$925K", percentage: 7.5 },
      { symbol: "その他", amount: "-", value: "$175K", percentage: 1.4 }
    ]
  };

  const members = [
    { address: "接続ウォレット", tokens: "125,000", votingPower: "6.25%", proposals: 3, votes: 45 },
    { address: "0x9876...4321", tokens: "98,500", votingPower: "4.93%", proposals: 2, votes: 38 },
    { address: "0x5555...7777", tokens: "87,200", votingPower: "4.36%", proposals: 1, votes: 42 },
    { address: "0x3333...9999", tokens: "76,800", votingPower: "3.84%", proposals: 4, votes: 51 },
    { address: "0x7777...1111", tokens: "65,400", votingPower: "3.27%", proposals: 0, votes: 29 }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-blue-500 bg-blue-500/10 border-blue-500/20';
      case 'passed': return 'text-green-500 bg-green-500/10 border-green-500/20';
      case 'rejected': return 'text-red-500 bg-red-500/10 border-red-500/20';
      case 'pending': return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20';
      default: return 'text-gray-500 bg-gray-500/10 border-gray-500/20';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <Vote className="w-4 h-4" />;
      case 'passed': return <CheckCircle className="w-4 h-4" />;
      case 'rejected': return <XCircle className="w-4 h-4" />;
      case 'pending': return <Clock className="w-4 h-4" />;
      default: return <AlertCircle className="w-4 h-4" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return '投票中';
      case 'passed': return '可決';
      case 'rejected': return '否決';
      case 'pending': return '待機中';
      default: return '不明';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/dapps-builder")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              テンプレート一覧に戻る
            </Button>
            <div className="flex items-center gap-3">
              <div className="text-3xl">🏛️</div>
              <div className="font-brand text-2xl font-bold text-primary">
                DAO運営ツール
              </div>
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            分散型自律組織（DAO）の完全な運営プラットフォーム。
            提案、投票、財務管理、メンバー管理を一つの場所で。
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-8">
        {/* 統計情報 */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-primary mb-2">2,000,000</div>
            <div className="text-sm text-muted-foreground">総投票権</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-green-500 mb-2">1,234</div>
            <div className="text-sm text-muted-foreground">アクティブメンバー</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-yellow-500 mb-2">$12.4M</div>
            <div className="text-sm text-muted-foreground">財務残高</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-purple-500 mb-2">47</div>
            <div className="text-sm text-muted-foreground">総提案数</div>
          </motion.div>
        </div>

        {/* タブナビゲーション */}
        <div className="flex gap-2 mb-8 bg-muted/50 p-1 rounded-xl w-fit">
          {[
            { id: 'proposals', label: '提案', icon: Vote },
            { id: 'treasury', label: '財務', icon: Coins },
            { id: 'members', label: 'メンバー', icon: Users },
            { id: 'governance', label: 'ガバナンス', icon: Shield }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
                activeTab === tab.id
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* メインパネル */}
          <div className="lg:col-span-2">
            <AnimatePresence mode="wait">
              {/* 提案タブ */}
              {activeTab === 'proposals' && (
                <motion.div
                  key="proposals"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold">提案一覧</h2>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      新しい提案
                    </Button>
                  </div>

                  <div className="space-y-4">
                    {proposals.map((proposal, index) => (
                      <motion.div
                        key={proposal.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="bg-card rounded-xl border p-6 hover:shadow-lg transition-all cursor-pointer"
                        onClick={() => setSelectedProposal(selectedProposal === proposal.id ? null : proposal.id)}
                      >
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-lg font-semibold">{proposal.title}</h3>
                              <div className={cn(
                                "flex items-center gap-1 px-2 py-1 rounded-full text-xs font-semibold border",
                                getStatusColor(proposal.status)
                              )}>
                                {getStatusIcon(proposal.status)}
                                {getStatusText(proposal.status)}
                              </div>
                            </div>
                            <p className="text-muted-foreground text-sm mb-3">{proposal.description}</p>
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span>提案者: {proposal.proposer}</span>
                              <span>カテゴリ: {proposal.category}</span>
                              <span>作成日: {proposal.created}</span>
                            </div>
                          </div>
                          <div className="text-right ml-4">
                            <div className="text-sm font-semibold">{proposal.timeLeft}</div>
                            <div className="text-xs text-muted-foreground">残り時間</div>
                          </div>
                        </div>

                        {/* 投票進捗 */}
                        <div className="space-y-3">
                          <div className="flex justify-between text-sm">
                            <span>賛成: {proposal.votesFor.toLocaleString()}</span>
                            <span>反対: {proposal.votesAgainst.toLocaleString()}</span>
                          </div>
                          <div className="w-full bg-muted rounded-full h-2">
                            <div 
                              className="bg-green-500 h-2 rounded-l-full"
                              style={{ 
                                width: `${(proposal.votesFor / (proposal.votesFor + proposal.votesAgainst)) * 100}%` 
                              }}
                            />
                          </div>
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>総投票数: {proposal.totalVotes.toLocaleString()}</span>
                            <span>必要数: {proposal.quorum.toLocaleString()}</span>
                          </div>
                        </div>

                        {/* 詳細表示 */}
                        <AnimatePresence>
                          {selectedProposal === proposal.id && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              className="mt-6 pt-6 border-t border-border"
                            >
                              <div className="flex gap-3 mb-4">
                                <Button className="flex-1" disabled={proposal.status !== 'active'}>
                                  <ThumbsUp className="w-4 h-4 mr-2" />
                                  賛成投票
                                </Button>
                                <Button variant="outline" className="flex-1" disabled={proposal.status !== 'active'}>
                                  <ThumbsDown className="w-4 h-4 mr-2" />
                                  反対投票
                                </Button>
                                <Button variant="outline">
                                  <MessageSquare className="w-4 h-4 mr-2" />
                                  議論
                                </Button>
                              </div>
                              <div className="text-sm text-muted-foreground">
                                <p>この提案について詳細な議論や追加情報は、コミュニティフォーラムでご確認いただけます。</p>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* 財務タブ */}
              {activeTab === 'treasury' && (
                <motion.div
                  key="treasury"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold">財務管理</h2>
                    <div className="text-right">
                      <div className="text-3xl font-bold text-primary">{treasuryData.totalValue}</div>
                      <div className="text-sm text-muted-foreground">総資産価値</div>
                    </div>
                  </div>

                  {/* 資産構成 */}
                  <div className="bg-card rounded-xl border p-6">
                    <h3 className="text-xl font-semibold mb-4">資産構成</h3>
                    <div className="space-y-4">
                      {treasuryData.assets.map((asset, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-semibold">
                              {asset.symbol.charAt(0)}
                            </div>
                            <div>
                              <div className="font-semibold">{asset.symbol}</div>
                              <div className="text-sm text-muted-foreground">{asset.amount}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold">{asset.value}</div>
                            <div className="text-sm text-muted-foreground">{asset.percentage}%</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 最近の取引 */}
                  <div className="bg-card rounded-xl border p-6">
                    <h3 className="text-xl font-semibold mb-4">最近の財務取引</h3>
                    <div className="space-y-3">
                      {[
                        { type: '受取', amount: '+$50,000 USDC', description: 'プロトコル手数料', time: '2時間前' },
                        { type: '支払', amount: '-$25,000 ETH', description: '開発者報酬', time: '1日前' },
                        { type: '受取', amount: '+$15,000 UNI', description: 'ステーキング報酬', time: '3日前' },
                        { type: '支払', amount: '-$10,000 USDC', description: 'マーケティング費用', time: '5日前' }
                      ].map((tx, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className={cn(
                              "w-2 h-2 rounded-full",
                              tx.type === '受取' ? 'bg-green-500' : 'bg-red-500'
                            )} />
                            <div>
                              <div className="font-medium">{tx.description}</div>
                              <div className="text-sm text-muted-foreground">{tx.time}</div>
                            </div>
                          </div>
                          <div className={cn(
                            "font-semibold",
                            tx.type === '受取' ? 'text-green-500' : 'text-red-500'
                          )}>
                            {tx.amount}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {/* メンバータブ */}
              {activeTab === 'members' && (
                <motion.div
                  key="members"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold">メンバー管理</h2>
                    <Button variant="outline">
                      <FileText className="w-4 h-4 mr-2" />
                      レポート出力
                    </Button>
                  </div>

                  <div className="bg-card rounded-xl border overflow-hidden">
                    <div className="p-6 border-b border-border">
                      <h3 className="text-xl font-semibold">トップメンバー</h3>
                    </div>
                    <div className="divide-y divide-border">
                      {members.map((member, index) => (
                        <div key={index} className="p-6 hover:bg-muted/30 transition-colors">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center font-semibold">
                                #{index + 1}
                              </div>
                              <div>
                                <div className="font-semibold">{member.address}</div>
                                <div className="text-sm text-muted-foreground">
                                  投票権: {member.votingPower}
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-semibold">{member.tokens} トークン</div>
                              <div className="text-sm text-muted-foreground">
                                提案: {member.proposals} | 投票: {member.votes}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {/* ガバナンスタブ */}
              {activeTab === 'governance' && (
                <motion.div
                  key="governance"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <h2 className="text-2xl font-bold">ガバナンス設定</h2>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-card rounded-xl border p-6">
                      <h3 className="text-lg font-semibold mb-4">投票パラメータ</h3>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">最小提案権</span>
                          <span className="font-semibold">10,000 トークン</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">クォーラム</span>
                          <span className="font-semibold">2,000,000 トークン</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">投票期間</span>
                          <span className="font-semibold">7日間</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">実行遅延</span>
                          <span className="font-semibold">2日間</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-card rounded-xl border p-6">
                      <h3 className="text-lg font-semibold mb-4">プロトコル統計</h3>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">総提案数</span>
                          <span className="font-semibold">47</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">可決率</span>
                          <span className="font-semibold text-green-500">68%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">平均参加率</span>
                          <span className="font-semibold">45%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">アクティブ期間</span>
                          <span className="font-semibold">8ヶ月</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-card rounded-xl border p-6">
                    <h3 className="text-lg font-semibold mb-4">ガバナンス履歴</h3>
                    <div className="space-y-4">
                      {[
                        { date: '2026-02-20', action: 'プロトコル手数料変更', result: '可決', impact: 'Medium' },
                        { date: '2026-02-15', action: 'トークン追加発行', result: '否決', impact: 'High' },
                        { date: '2026-02-10', action: 'セキュリティ監査予算', result: '可決', impact: 'High' },
                        { date: '2026-02-05', action: 'UI/UX改善提案', result: '可決', impact: 'Low' }
                      ].map((item, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="text-sm text-muted-foreground">{item.date}</div>
                            <div className="font-medium">{item.action}</div>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className={cn(
                              "px-2 py-1 rounded-full text-xs font-semibold",
                              item.result === '可決' ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'
                            )}>
                              {item.result}
                            </div>
                            <div className={cn(
                              "px-2 py-1 rounded-full text-xs",
                              item.impact === 'High' ? 'bg-red-500/10 text-red-500' :
                              item.impact === 'Medium' ? 'bg-yellow-500/10 text-yellow-500' :
                              'bg-green-500/10 text-green-500'
                            )}>
                              {item.impact}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* サイドパネル */}
          <div className="space-y-6">
            {/* あなたの投票権 */}
            <div className="bg-card rounded-xl border p-6">
              <h3 className="font-semibold mb-4">あなたの投票権</h3>
              <div className="text-center mb-4">
                <div className="text-3xl font-bold text-primary">25,000</div>
                <div className="text-sm text-muted-foreground">CHEATAトークン</div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">投票権</span>
                  <span className="font-semibold">1.25%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">参加した投票</span>
                  <span className="font-semibold">23/47</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">提案数</span>
                  <span className="font-semibold">2</span>
                </div>
              </div>
              <Button className="w-full mt-4" size="sm">
                <Plus className="w-4 h-4 mr-2" />
                トークン追加購入
              </Button>
            </div>

            {/* 最新の活動 */}
            <div className="bg-card rounded-xl border p-6">
              <h3 className="font-semibold mb-4">最新の活動</h3>
              <div className="space-y-3">
                {[
                  { action: '新しい提案', title: 'プロトコル手数料削減', time: '2時間前' },
                  { action: '投票完了', title: 'トークンペア追加', time: '1日前' },
                  { action: '議論開始', title: '開発基金設立', time: '2日前' },
                  { action: '提案可決', title: 'セキュリティ監査', time: '5日前' }
                ].map((activity, index) => (
                  <div key={index} className="text-sm">
                    <div className="font-medium">{activity.action}</div>
                    <div className="text-muted-foreground">{activity.title}</div>
                    <div className="text-xs text-muted-foreground">{activity.time}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* クイックアクション */}
            <div className="bg-card rounded-xl border p-6">
              <h3 className="font-semibold mb-4">クイックアクション</h3>
              <div className="space-y-3">
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <Plus className="w-4 h-4 mr-2" />
                  新しい提案を作成
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  統計を確認
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  フォーラムに参加
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  ドキュメント
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}