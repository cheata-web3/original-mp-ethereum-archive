import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  ArrowUpDown,
  TrendingUp,
  TrendingDown,
  BarChart3,
  Droplets,
  Zap,
  Settings,
  RefreshCw,
  Plus,
  Minus,
  DollarSign,
  Percent,
  Clock,
  Shield,
  Info
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function DEXTemplate() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'swap' | 'pool' | 'farm' | 'stake'>('swap');
  const [fromAmount, setFromAmount] = useState<string>('');
  const [toAmount, setToAmount] = useState<string>('');
  const [fromToken, setFromToken] = useState<string>('ETH');
  const [toToken, setToToken] = useState<string>('USDC');

  const tokens = [
    { symbol: 'ETH', name: 'Ethereum', balance: '2.5847', price: '$3,245.67', change: '+2.4%', icon: '⟠' },
    { symbol: 'BTC', name: 'Bitcoin', balance: '0.1234', price: '$67,890.12', change: '+1.8%', icon: '₿' },
    { symbol: 'USDC', name: 'USD Coin', balance: '1,250.00', price: '$1.00', change: '0.0%', icon: '💵' },
    { symbol: 'USDT', name: 'Tether', balance: '890.50', price: '$1.00', change: '+0.1%', icon: '💰' },
    { symbol: 'UNI', name: 'Uniswap', balance: '45.67', price: '$12.34', change: '+5.2%', icon: '🦄' },
    { symbol: 'LINK', name: 'Chainlink', balance: '123.45', price: '$18.90', change: '+3.1%', icon: '🔗' }
  ];

  const pools = [
    { pair: 'ETH/USDC', tvl: '$2.4M', apr: '12.5%', volume24h: '$456K', fees: '$1.2K' },
    { pair: 'BTC/ETH', tvl: '$1.8M', apr: '8.9%', volume24h: '$234K', fees: '$890' },
    { pair: 'UNI/ETH', tvl: '$890K', apr: '15.2%', volume24h: '$123K', fees: '$456' },
    { pair: 'LINK/USDC', tvl: '$567K', apr: '11.8%', volume24h: '$89K', fees: '$234' }
  ];

  const farms = [
    { pair: 'ETH/USDC LP', rewards: 'UNI + CHEATA', apr: '45.6%', staked: '$12.3K', earned: '23.45 UNI' },
    { pair: 'BTC/ETH LP', rewards: 'UNI', apr: '32.1%', staked: '$8.9K', earned: '15.67 UNI' },
    { pair: 'UNI/ETH LP', rewards: 'CHEATA', apr: '67.8%', staked: '$5.6K', earned: '89.12 CHEATA' }
  ];

  const getTokenInfo = (symbol: string) => tokens.find(t => t.symbol === symbol) || tokens[0];

  const handleAmountChange = (value: string, isFrom: boolean) => {
    if (isFrom) {
      setFromAmount(value);
      // 簡単な変換レート計算
      const rate = fromToken === 'ETH' && toToken === 'USDC' ? 3245.67 : 1;
      setToAmount((parseFloat(value || '0') * rate).toFixed(6));
    } else {
      setToAmount(value);
      const rate = fromToken === 'ETH' && toToken === 'USDC' ? 3245.67 : 1;
      setFromAmount((parseFloat(value || '0') / rate).toFixed(6));
    }
  };

  const swapTokens = () => {
    const tempToken = fromToken;
    const tempAmount = fromAmount;
    setFromToken(toToken);
    setToToken(tempToken);
    setFromAmount(toAmount);
    setToAmount(tempAmount);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/dapps-builder")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              テンプレート一覧に戻る
            </Button>
            <div className="flex items-center gap-3">
              <div className="text-3xl">💱</div>
              <div className="font-brand text-2xl font-bold text-primary">
                分散型取引所（DEX）
              </div>
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            完全分散型の暗号資産取引プラットフォーム。
            スワップ、流動性提供、ファーミング、ステーキングを一つの場所で。
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-8">
        {/* 統計情報 */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-primary mb-2">$5.7M</div>
            <div className="text-sm text-muted-foreground">総流動性</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-green-500 mb-2">$902K</div>
            <div className="text-sm text-muted-foreground">24h取引量</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-yellow-500 mb-2">$2.7K</div>
            <div className="text-sm text-muted-foreground">24h手数料</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-card rounded-xl p-6 border text-center"
          >
            <div className="text-3xl font-bold text-purple-500 mb-2">1,234</div>
            <div className="text-sm text-muted-foreground">アクティブユーザー</div>
          </motion.div>
        </div>

        {/* タブナビゲーション */}
        <div className="flex gap-2 mb-8 bg-muted/50 p-1 rounded-xl w-fit">
          {[
            { id: 'swap', label: 'スワップ', icon: ArrowUpDown },
            { id: 'pool', label: '流動性', icon: Droplets },
            { id: 'farm', label: 'ファーム', icon: TrendingUp },
            { id: 'stake', label: 'ステーク', icon: Zap }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
                activeTab === tab.id
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* メインパネル */}
          <div className="lg:col-span-2">
            <AnimatePresence mode="wait">
              {/* スワップタブ */}
              {activeTab === 'swap' && (
                <motion.div
                  key="swap"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="bg-card rounded-2xl border p-6"
                >
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold">トークンスワップ</h2>
                    <Button variant="ghost" size="sm">
                      <Settings className="w-4 h-4" />
                    </Button>
                  </div>

                  {/* From Token */}
                  <div className="space-y-4">
                    <div className="bg-muted/50 rounded-xl p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-muted-foreground">From</span>
                        <span className="text-sm text-muted-foreground">
                          残高: {getTokenInfo(fromToken).balance}
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <select 
                          value={fromToken}
                          onChange={(e) => setFromToken(e.target.value)}
                          className="bg-background border border-border rounded-lg px-3 py-2 text-sm font-medium min-w-[120px]"
                        >
                          {tokens.map(token => (
                            <option key={token.symbol} value={token.symbol}>
                              {token.icon} {token.symbol}
                            </option>
                          ))}
                        </select>
                        <Input
                          type="number"
                          placeholder="0.0"
                          value={fromAmount}
                          onChange={(e) => handleAmountChange(e.target.value, true)}
                          className="text-right text-lg font-semibold border-0 bg-transparent p-0 h-auto"
                        />
                      </div>
                    </div>

                    {/* スワップボタン */}
                    <div className="flex justify-center">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={swapTokens}
                        className="rounded-full w-10 h-10 p-0"
                      >
                        <ArrowUpDown className="w-4 h-4" />
                      </Button>
                    </div>

                    {/* To Token */}
                    <div className="bg-muted/50 rounded-xl p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-muted-foreground">To</span>
                        <span className="text-sm text-muted-foreground">
                          残高: {getTokenInfo(toToken).balance}
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <select 
                          value={toToken}
                          onChange={(e) => setToToken(e.target.value)}
                          className="bg-background border border-border rounded-lg px-3 py-2 text-sm font-medium min-w-[120px]"
                        >
                          {tokens.map(token => (
                            <option key={token.symbol} value={token.symbol}>
                              {token.icon} {token.symbol}
                            </option>
                          ))}
                        </select>
                        <Input
                          type="number"
                          placeholder="0.0"
                          value={toAmount}
                          onChange={(e) => handleAmountChange(e.target.value, false)}
                          className="text-right text-lg font-semibold border-0 bg-transparent p-0 h-auto"
                          readOnly
                        />
                      </div>
                    </div>
                  </div>

                  {/* スワップ詳細 */}
                  <div className="mt-6 space-y-3 p-4 bg-muted/30 rounded-xl">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">レート</span>
                      <span>1 {fromToken} = {fromToken === 'ETH' && toToken === 'USDC' ? '3,245.67' : '1'} {toToken}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">価格インパクト</span>
                      <span className="text-green-500">0.12%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">流動性プロバイダー手数料</span>
                      <span>0.3%</span>
                    </div>
                  </div>

                  <Button className="w-full mt-6 h-12 text-lg font-semibold">
                    <ArrowUpDown className="w-5 h-5 mr-2" />
                    スワップ実行
                  </Button>
                </motion.div>
              )}

              {/* 流動性タブ */}
              {activeTab === 'pool' && (
                <motion.div
                  key="pool"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="bg-card rounded-2xl border p-6"
                >
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold">流動性プール</h2>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      流動性追加
                    </Button>
                  </div>

                  <div className="space-y-4">
                    {pools.map((pool, index) => (
                      <div key={index} className="bg-muted/30 rounded-xl p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <div className="text-lg font-semibold">{pool.pair}</div>
                            <div className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">
                              {pool.apr} APR
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              <Plus className="w-4 h-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Minus className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <div className="text-muted-foreground">TVL</div>
                            <div className="font-semibold">{pool.tvl}</div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">24h取引量</div>
                            <div className="font-semibold">{pool.volume24h}</div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">24h手数料</div>
                            <div className="font-semibold text-green-500">{pool.fees}</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* ファームタブ */}
              {activeTab === 'farm' && (
                <motion.div
                  key="farm"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="bg-card rounded-2xl border p-6"
                >
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold">イールドファーミング</h2>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Info className="w-4 h-4" />
                      <span>LPトークンをステークして報酬を獲得</span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {farms.map((farm, index) => (
                      <div key={index} className="bg-muted/30 rounded-xl p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <div className="text-lg font-semibold">{farm.pair}</div>
                            <div className="px-2 py-1 bg-green-500/10 text-green-500 text-xs rounded-full">
                              {farm.apr} APR
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm">
                              ステーク
                            </Button>
                            <Button variant="outline" size="sm">
                              収穫
                            </Button>
                          </div>
                        </div>
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <div className="text-muted-foreground">報酬トークン</div>
                            <div className="font-semibold">{farm.rewards}</div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">ステーク済み</div>
                            <div className="font-semibold">{farm.staked}</div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">獲得済み</div>
                            <div className="font-semibold text-green-500">{farm.earned}</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* ステークタブ */}
              {activeTab === 'stake' && (
                <motion.div
                  key="stake"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="bg-card rounded-2xl border p-6"
                >
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold">シングルトークンステーキング</h2>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Shield className="w-4 h-4" />
                      <span>安全なステーキング</span>
                    </div>
                  </div>

                  <div className="space-y-6">
                    {/* CHEATAステーキング */}
                    <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-xl p-6 border border-primary/20">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="text-2xl">🧩</div>
                          <div>
                            <div className="text-xl font-bold">CHEATAステーキング</div>
                            <div className="text-sm text-muted-foreground">ガバナンストークンをステーク</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-primary">15.6% APY</div>
                          <div className="text-sm text-muted-foreground">年利</div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <div className="text-sm text-muted-foreground">ステーク済み</div>
                          <div className="text-lg font-semibold">1,250 CHEATA</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">獲得済み報酬</div>
                          <div className="text-lg font-semibold text-green-500">45.67 CHEATA</div>
                        </div>
                      </div>

                      <div className="flex gap-3">
                        <Button className="flex-1">
                          <Plus className="w-4 h-4 mr-2" />
                          ステーク
                        </Button>
                        <Button variant="outline" className="flex-1">
                          <Minus className="w-4 h-4 mr-2" />
                          アンステーク
                        </Button>
                        <Button variant="outline">
                          収穫
                        </Button>
                      </div>
                    </div>

                    {/* その他のステーキングオプション */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-muted/30 rounded-xl p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="text-xl">⟠</div>
                          <div>
                            <div className="font-semibold">ETHステーキング</div>
                            <div className="text-sm text-muted-foreground">4.2% APY</div>
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="w-full">
                          ステーク開始
                        </Button>
                      </div>

                      <div className="bg-muted/30 rounded-xl p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="text-xl">🦄</div>
                          <div>
                            <div className="font-semibold">UNIステーキング</div>
                            <div className="text-sm text-muted-foreground">8.9% APY</div>
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="w-full">
                          ステーク開始
                        </Button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* サイドパネル */}
          <div className="space-y-6">
            {/* 価格チャート */}
            <div className="bg-card rounded-xl border p-6">
              <h3 className="font-semibold mb-4">価格チャート</h3>
              <div className="space-y-3">
                {tokens.slice(0, 4).map((token, index) => (
                  <div key={token.symbol} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{token.icon}</span>
                      <div>
                        <div className="font-medium">{token.symbol}</div>
                        <div className="text-xs text-muted-foreground">{token.name}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">{token.price}</div>
                      <div className={cn(
                        "text-xs",
                        token.change.startsWith('+') ? 'text-green-500' : 'text-red-500'
                      )}>
                        {token.change}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 最近の取引 */}
            <div className="bg-card rounded-xl border p-6">
              <h3 className="font-semibold mb-4">最近の取引</h3>
              <div className="space-y-3">
                {[
                  { type: 'Swap', tokens: 'ETH → USDC', amount: '1.5 ETH', time: '2分前' },
                  { type: 'Add', tokens: 'ETH/USDC', amount: '$5,000', time: '5分前' },
                  { type: 'Swap', tokens: 'UNI → ETH', amount: '100 UNI', time: '8分前' },
                  { type: 'Remove', tokens: 'BTC/ETH', amount: '$2,500', time: '12分前' }
                ].map((tx, index) => (
                  <div key={index} className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div className={cn(
                        "w-2 h-2 rounded-full",
                        tx.type === 'Swap' ? 'bg-blue-500' :
                        tx.type === 'Add' ? 'bg-green-500' : 'bg-red-500'
                      )} />
                      <div>
                        <div className="font-medium">{tx.tokens}</div>
                        <div className="text-muted-foreground">{tx.amount}</div>
                      </div>
                    </div>
                    <div className="text-muted-foreground">{tx.time}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}