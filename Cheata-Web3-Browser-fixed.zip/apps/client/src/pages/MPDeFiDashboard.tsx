import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft, 
  TrendingUp,
  TrendingDown,
  BarChart3,
  PieChart,
  DollarSign,
  Coins,
  Zap,
  Shield,
  Target,
  RefreshCw,
  ArrowUpRight,
  ArrowDownLeft,
  Plus,
  Minus,
  Info,
  ExternalLink,
  Activity,
  Layers,
  Globe,
  Lock,
  Unlock,
  Clock,
  Star
} from "lucide-react";
import { cn } from "@/lib/utils";
import { IMAGES } from "@/assets/images";

export default function MPDeFiDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'overview' | 'pools' | 'farming' | 'lending'>('overview');
  const [totalValue, setTotalValue] = useState<string>('125,847.32');
  const [dailyYield, setDailyYield] = useState<string>('247.83');

  // DeFiプロトコル統計
  const defiStats = [
    {
      label: '総ロック価値',
      value: '$' + totalValue,
      change: '+12.5%',
      positive: true,
      icon: Lock,
      description: 'DeFiプロトコルにロックされた総価値'
    },
    {
      label: '日次利回り',
      value: dailyYield + ' MP',
      change: '+8.7%',
      positive: true,
      icon: TrendingUp,
      description: '過去24時間の利回り'
    },
    {
      label: 'アクティブポジション',
      value: '7',
      change: '+2',
      positive: true,
      icon: Activity,
      description: '現在アクティブなDeFiポジション'
    },
    {
      label: 'リスクスコア',
      value: '6.8/10',
      change: '-0.2',
      positive: false,
      icon: Shield,
      description: 'ポートフォリオのリスクレベル'
    }
  ];

  // 流動性プール
  const liquidityPools = [
    {
      id: 'mp-usdc',
      name: 'MP/USDC',
      protocol: 'UniswapV3',
      apy: '24.5%',
      tvl: '$2,450,000',
      volume24h: '$125,000',
      fees24h: '$312.50',
      myLiquidity: '$5,250.00',
      impermanentLoss: '-2.3%',
      status: 'active',
      risk: 'medium'
    },
    {
      id: 'mp-eth',
      name: 'MP/ETH',
      protocol: 'SushiSwap',
      apy: '18.7%',
      tvl: '$1,850,000',
      volume24h: '$89,000',
      fees24h: '$223.00',
      myLiquidity: '$3,100.00',
      impermanentLoss: '+1.2%',
      status: 'active',
      risk: 'high'
    },
    {
      id: 'mp-btc',
      name: 'MP/WBTC',
      protocol: 'PancakeSwap',
      apy: '15.2%',
      tvl: '$980,000',
      volume24h: '$45,000',
      fees24h: '$112.50',
      myLiquidity: '$0.00',
      impermanentLoss: '0%',
      status: 'available',
      risk: 'low'
    }
  ];

  // イールドファーミング
  const farmingPools = [
    {
      id: 'mp-farm-1',
      name: 'MP Mega Farm',
      protocol: 'CheatA Farm',
      apy: '156%',
      totalStaked: '$5,200,000',
      rewardToken: 'CHEATA',
      myStaked: '$8,500.00',
      pendingRewards: '245.67 CHEATA',
      multiplier: '3x',
      endDate: '2026-06-15',
      risk: 'high'
    },
    {
      id: 'mp-farm-2',
      name: 'Stable Yield',
      protocol: 'Compound',
      apy: '12.5%',
      totalStaked: '$12,800,000',
      rewardToken: 'COMP',
      myStaked: '$15,200.00',
      pendingRewards: '12.34 COMP',
      multiplier: '1x',
      endDate: 'Perpetual',
      risk: 'low'
    }
  ];

  // レンディング
  const lendingPools = [
    {
      id: 'mp-lend-1',
      asset: 'MP',
      protocol: 'Aave',
      supplyApy: '8.5%',
      borrowApy: '12.3%',
      supplied: '25,000 MP',
      borrowed: '0 MP',
      collateral: true,
      ltv: '75%',
      liquidationThreshold: '80%'
    },
    {
      id: 'usdc-lend',
      asset: 'USDC',
      protocol: 'Compound',
      supplyApy: '4.2%',
      borrowApy: '6.8%',
      supplied: '50,000 USDC',
      borrowed: '15,000 USDC',
      collateral: true,
      ltv: '85%',
      liquidationThreshold: '90%'
    }
  ];

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-500 bg-green-500/10';
      case 'medium': return 'text-yellow-500 bg-yellow-500/10';
      case 'high': return 'text-red-500 bg-red-500/10';
      default: return 'text-muted-foreground bg-muted/10';
    }
  };

  const getRiskText = (risk: string) => {
    switch (risk) {
      case 'low': return '低リスク';
      case 'medium': return '中リスク';
      case 'high': return '高リスク';
      default: return '不明';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto max-w-7xl">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 flex items-center justify-center">
                <img 
                  src="/images/777.png" 
                  alt="MP DeFi Logo" 
                  className="w-10 h-10 object-contain drop-shadow-md z-10"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                    if (fallback) fallback.style.display = 'flex';
                  }}
                />
                <div 
                  className="absolute inset-0 w-auto h-10 flex items-center justify-center text-lg font-bold tracking-tight"
                  style={{ 
                    display: 'none',
                    background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text'
                  }}
                >
                  CheatA
                </div>
              </div>
              <div className="font-brand text-2xl font-bold tracking-tight" style={{
                background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}>
                📊 MP DeFiダッシュボード
              </div>
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            Magic PointのDeFi活動を一元管理。
            流動性提供、イールドファーミング、レンディングの収益を最大化しましょう。
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-12 max-w-7xl">
        {/* 統計カード */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {defiStats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-card rounded-2xl border p-6 hover:shadow-lg transition-shadow group"
            >
              <div className="flex items-center justify-between mb-4">
                <stat.icon className="w-8 h-8 text-primary" />
                <div className={cn(
                  "text-sm px-2 py-1 rounded-full",
                  stat.positive ? "text-green-500 bg-green-500/10" : "text-red-500 bg-red-500/10"
                )}>
                  {stat.change}
                </div>
              </div>
              <div className="text-2xl font-bold mb-1">{stat.value}</div>
              <div className="text-sm text-muted-foreground mb-2">{stat.label}</div>
              <div className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">
                {stat.description}
              </div>
            </motion.div>
          ))}
        </div>

        {/* タブナビゲーション */}
        <div className="flex space-x-1 bg-muted p-1 rounded-xl mb-8">
          {[
            { id: 'overview', label: '概要', icon: BarChart3 },
            { id: 'pools', label: '流動性プール', icon: Layers },
            { id: 'farming', label: 'ファーミング', icon: Target },
            { id: 'lending', label: 'レンディング', icon: DollarSign }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg text-sm font-medium transition-all",
                activeTab === tab.id
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* タブコンテンツ */}
        <AnimatePresence mode="wait">
          {activeTab === 'overview' && (
            <motion.div
              key="overview"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {/* ポートフォリオ概要 */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-card rounded-2xl border p-6">
                  <h3 className="text-xl font-bold mb-6">ポートフォリオ分布</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
                        <span>流動性プール</span>
                      </div>
                      <span className="font-medium">$8,350 (42%)</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                        <span>イールドファーミング</span>
                      </div>
                      <span className="font-medium">$23,700 (35%)</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-4 h-4 bg-purple-500 rounded-full"></div>
                        <span>レンディング</span>
                      </div>
                      <span className="font-medium">$75,000 (23%)</span>
                    </div>
                  </div>
                </div>

                <div className="bg-card rounded-2xl border p-6">
                  <h3 className="text-xl font-bold mb-6">収益トレンド</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">今日</span>
                      <span className="font-bold text-green-500">+$247.83</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">今週</span>
                      <span className="font-bold text-green-500">+$1,834.21</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">今月</span>
                      <span className="font-bold text-green-500">+$7,245.67</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">年間予想</span>
                      <span className="font-bold text-blue-500">+$89,348.04</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* アクティブポジション */}
              <div className="bg-card rounded-2xl border p-6">
                <h3 className="text-xl font-bold mb-6">アクティブポジション</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {liquidityPools.filter(pool => pool.status === 'active').map((pool) => (
                    <div key={pool.id} className="bg-muted/50 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{pool.name}</span>
                        <span className="text-sm text-green-500">{pool.apy}</span>
                      </div>
                      <div className="text-sm text-muted-foreground mb-1">{pool.protocol}</div>
                      <div className="text-lg font-bold">{pool.myLiquidity}</div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'pools' && (
            <motion.div
              key="pools"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {liquidityPools.map((pool) => (
                <div key={pool.id} className="bg-card rounded-2xl border p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-4">
                      <div className="text-2xl">💧</div>
                      <div>
                        <h3 className="text-xl font-bold">{pool.name}</h3>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-muted-foreground">{pool.protocol}</span>
                          <span className={cn("px-2 py-1 rounded-full text-xs", getRiskColor(pool.risk))}>
                            {getRiskText(pool.risk)}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary">{pool.apy}</div>
                      <div className="text-xs text-muted-foreground">APY</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div>
                      <div className="text-sm text-muted-foreground">TVL</div>
                      <div className="font-medium">{pool.tvl}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">24h Volume</div>
                      <div className="font-medium">{pool.volume24h}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">24h Fees</div>
                      <div className="font-medium">{pool.fees24h}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">My Liquidity</div>
                      <div className="font-medium">{pool.myLiquidity}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">Impermanent Loss:</span>
                      <span className={cn(
                        "text-sm font-medium",
                        pool.impermanentLoss.startsWith('+') ? "text-green-500" : "text-red-500"
                      )}>
                        {pool.impermanentLoss}
                      </span>
                    </div>
                    <div className="flex gap-2">
                      {pool.status === 'active' ? (
                        <>
                          <Button variant="outline" size="sm">
                            <Minus className="w-4 h-4 mr-1" />
                            Remove
                          </Button>
                          <Button size="sm">
                            <Plus className="w-4 h-4 mr-1" />
                            Add
                          </Button>
                        </>
                      ) : (
                        <Button size="sm">
                          <Plus className="w-4 h-4 mr-1" />
                          Add Liquidity
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          )}

          {activeTab === 'farming' && (
            <motion.div
              key="farming"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {farmingPools.map((farm) => (
                <div key={farm.id} className="bg-card rounded-2xl border p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-4">
                      <div className="text-2xl">🚜</div>
                      <div>
                        <h3 className="text-xl font-bold">{farm.name}</h3>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-muted-foreground">{farm.protocol}</span>
                          <span className="bg-orange-500/10 text-orange-500 text-xs px-2 py-1 rounded-full">
                            {farm.multiplier}
                          </span>
                          <span className={cn("px-2 py-1 rounded-full text-xs", getRiskColor(farm.risk))}>
                            {getRiskText(farm.risk)}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary">{farm.apy}</div>
                      <div className="text-xs text-muted-foreground">APY</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div>
                      <div className="text-sm text-muted-foreground">Total Staked</div>
                      <div className="font-medium">{farm.totalStaked}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">My Staked</div>
                      <div className="font-medium">{farm.myStaked}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Pending Rewards</div>
                      <div className="font-medium text-green-500">{farm.pendingRewards}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">End Date</div>
                      <div className="font-medium">{farm.endDate}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-sm text-muted-foreground">
                      Reward Token: <span className="font-medium">{farm.rewardToken}</span>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Harvest
                      </Button>
                      <Button size="sm">
                        <Plus className="w-4 h-4 mr-1" />
                        Stake More
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          )}

          {activeTab === 'lending' && (
            <motion.div
              key="lending"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {lendingPools.map((lending) => (
                <div key={lending.id} className="bg-card rounded-2xl border p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-4">
                      <div className="text-2xl">🏦</div>
                      <div>
                        <h3 className="text-xl font-bold">{lending.asset}</h3>
                        <div className="text-sm text-muted-foreground">{lending.protocol}</div>
                      </div>
                    </div>
                    <div className="flex gap-6">
                      <div className="text-right">
                        <div className="text-lg font-bold text-green-500">{lending.supplyApy}</div>
                        <div className="text-xs text-muted-foreground">Supply APY</div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-red-500">{lending.borrowApy}</div>
                        <div className="text-xs text-muted-foreground">Borrow APY</div>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div>
                      <div className="text-sm text-muted-foreground">Supplied</div>
                      <div className="font-medium">{lending.supplied}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Borrowed</div>
                      <div className="font-medium">{lending.borrowed}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">LTV</div>
                      <div className="font-medium">{lending.ltv}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Liquidation</div>
                      <div className="font-medium">{lending.liquidationThreshold}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {lending.collateral && (
                        <span className="bg-blue-500/10 text-blue-500 text-xs px-2 py-1 rounded-full">
                          Collateral
                        </span>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Withdraw
                      </Button>
                      <Button variant="outline" size="sm">
                        Repay
                      </Button>
                      <Button size="sm">
                        Supply More
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}