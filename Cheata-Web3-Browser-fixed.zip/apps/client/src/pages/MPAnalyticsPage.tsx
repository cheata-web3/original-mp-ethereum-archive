import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft, 
  TrendingUp,
  TrendingDown,
  BarChart3,
  PieChart,
  LineChart,
  Activity,
  DollarSign,
  Users,
  Globe,
  Zap,
  Target,
  RefreshCw,
  Calendar,
  Filter,
  Download,
  Share,
  Eye,
  Clock,
  Coins,
  ArrowUpRight,
  ArrowDownLeft,
  Info,
  Star,
  Crown,
  Flame
} from "lucide-react";
import { cn } from "@/lib/utils";
import { IMAGES } from "@/assets/images";

export default function MPAnalyticsPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'overview' | 'price' | 'volume' | 'holders'>('overview');
  const [timeframe, setTimeframe] = useState<'24h' | '7d' | '30d' | '90d' | '1y'>('7d');
  const [currentPrice, setCurrentPrice] = useState<string>('0.2456');
  const [priceChange, setPriceChange] = useState<string>('+8.7%');

  // 主要統計
  const keyMetrics = [
    {
      label: 'MP価格',
      value: '$' + currentPrice,
      change: priceChange,
      positive: true,
      icon: DollarSign,
      description: '現在のMagic Point価格'
    },
    {
      label: '時価総額',
      value: '$24.56M',
      change: '+12.3%',
      positive: true,
      icon: BarChart3,
      description: '総時価総額'
    },
    {
      label: '24h取引量',
      value: '$2.45M',
      change: '+15.8%',
      positive: true,
      icon: Activity,
      description: '過去24時間の取引量'
    },
    {
      label: 'ホルダー数',
      value: '12,847',
      change: '+234',
      positive: true,
      icon: Users,
      description: 'MPを保有するアドレス数'
    },
    {
      label: '流通供給量',
      value: '100M MP',
      change: '0%',
      positive: true,
      icon: Coins,
      description: '現在の流通供給量'
    },
    {
      label: 'ステーキング率',
      value: '45.2%',
      change: '+2.1%',
      positive: true,
      icon: Target,
      description: 'ステーキングされているMP割合'
    }
  ];

  // 価格履歴データ（模擬）
  const priceHistory = [
    { date: '2026-03-01', price: 0.2234, volume: 1850000 },
    { date: '2026-03-02', price: 0.2189, volume: 2100000 },
    { date: '2026-03-03', price: 0.2298, volume: 1950000 },
    { date: '2026-03-04', price: 0.2367, volume: 2300000 },
    { date: '2026-03-05', price: 0.2445, volume: 2650000 },
    { date: '2026-03-06', price: 0.2398, volume: 2200000 },
    { date: '2026-03-07', price: 0.2456, volume: 2450000 }
  ];

  // トップホルダー
  const topHolders = [
    {
      rank: 1,
      address: '接続ウォレット',
      balance: '5,000,000 MP',
      percentage: '5.0%',
      label: 'CheatA Treasury',
      type: 'treasury'
    },
    {
      rank: 2,
      address: '0x2345...6789',
      balance: '3,500,000 MP',
      percentage: '3.5%',
      label: 'Staking Pool',
      type: 'contract'
    },
    {
      rank: 3,
      address: '0x3456...7890',
      balance: '2,800,000 MP',
      percentage: '2.8%',
      label: 'DeFi Vault',
      type: 'contract'
    },
    {
      rank: 4,
      address: '0x4567...8901',
      balance: '1,250,000 MP',
      percentage: '1.25%',
      label: 'Whale #1',
      type: 'whale'
    },
    {
      rank: 5,
      address: '0x5678...9012',
      balance: '980,000 MP',
      percentage: '0.98%',
      label: 'Whale #2',
      type: 'whale'
    }
  ];

  // 取引所データ
  const exchangeData = [
    {
      name: 'UniswapV3',
      volume24h: '$1,250,000',
      price: '$0.2456',
      change: '+8.7%',
      liquidity: '$850,000',
      share: '51%'
    },
    {
      name: 'SushiSwap',
      volume24h: '$680,000',
      price: '$0.2454',
      change: '+8.5%',
      liquidity: '$420,000',
      share: '28%'
    },
    {
      name: 'PancakeSwap',
      volume24h: '$520,000',
      price: '$0.2458',
      change: '+8.9%',
      liquidity: '$310,000',
      share: '21%'
    }
  ];

  // DeFi統計
  const defiMetrics = [
    {
      protocol: 'Staking Pools',
      tvl: '$45.2M',
      change: '+12.5%',
      apy: '15.2%',
      participants: '8,547'
    },
    {
      protocol: 'Liquidity Pools',
      tvl: '$18.7M',
      change: '+8.9%',
      apy: '24.5%',
      participants: '3,421'
    },
    {
      protocol: 'Lending Markets',
      tvl: '$12.3M',
      change: '+15.2%',
      apy: '8.5%',
      participants: '1,892'
    }
  ];

  const getHolderTypeColor = (type: string) => {
    switch (type) {
      case 'treasury': return 'text-blue-500 bg-blue-500/10';
      case 'contract': return 'text-purple-500 bg-purple-500/10';
      case 'whale': return 'text-orange-500 bg-orange-500/10';
      default: return 'text-muted-foreground bg-muted/10';
    }
  };

  const getHolderTypeText = (type: string) => {
    switch (type) {
      case 'treasury': return 'Treasury';
      case 'contract': return 'Contract';
      case 'whale': return 'Whale';
      default: return 'Unknown';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto max-w-7xl">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 flex items-center justify-center">
                <img 
                  src="/images/777.png" 
                  alt="MP Analytics Logo" 
                  className="w-10 h-10 object-contain drop-shadow-md z-10"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                    if (fallback) fallback.style.display = 'flex';
                  }}
                />
                <div 
                  className="absolute inset-0 w-auto h-10 flex items-center justify-center text-lg font-bold tracking-tight"
                  style={{ 
                    display: 'none',
                    background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text'
                  }}
                >
                  CheatA
                </div>
              </div>
              <div className="font-brand text-2xl font-bold tracking-tight" style={{
                background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}>
                📈 MP統計・分析
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-muted-foreground max-w-2xl">
              Magic Pointの詳細な統計データと市場分析。
              価格動向、取引量、ホルダー分析などの包括的な情報を提供します。
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                レポート
              </Button>
              <Button variant="outline" size="sm">
                <RefreshCw className="w-4 h-4 mr-2" />
                更新
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-12 max-w-7xl">
        {/* 主要統計 */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6 mb-8">
          {keyMetrics.map((metric, index) => (
            <motion.div
              key={metric.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-card rounded-2xl border p-6 hover:shadow-lg transition-shadow group"
            >
              <div className="flex items-center justify-between mb-4">
                <metric.icon className="w-6 h-6 text-primary" />
                <div className={cn(
                  "text-xs px-2 py-1 rounded-full",
                  metric.positive ? "text-green-500 bg-green-500/10" : "text-red-500 bg-red-500/10"
                )}>
                  {metric.change}
                </div>
              </div>
              <div className="text-xl font-bold mb-1">{metric.value}</div>
              <div className="text-sm text-muted-foreground mb-2">{metric.label}</div>
              <div className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">
                {metric.description}
              </div>
            </motion.div>
          ))}
        </div>

        {/* 時間枠選択 */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex space-x-1 bg-muted p-1 rounded-xl">
            {[
              { id: '24h', label: '24時間' },
              { id: '7d', label: '7日' },
              { id: '30d', label: '30日' },
              { id: '90d', label: '90日' },
              { id: '1y', label: '1年' }
            ].map((period) => (
              <button
                key={period.id}
                onClick={() => setTimeframe(period.id as any)}
                className={cn(
                  "px-4 py-2 rounded-lg text-sm font-medium transition-all",
                  timeframe === period.id
                    ? "bg-background text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {period.label}
              </button>
            ))}
          </div>
        </div>

        {/* タブナビゲーション */}
        <div className="flex space-x-1 bg-muted p-1 rounded-xl mb-8">
          {[
            { id: 'overview', label: '概要', icon: BarChart3 },
            { id: 'price', label: '価格分析', icon: LineChart },
            { id: 'volume', label: '取引量', icon: Activity },
            { id: 'holders', label: 'ホルダー分析', icon: Users }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg text-sm font-medium transition-all",
                activeTab === tab.id
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* タブコンテンツ */}
        <AnimatePresence mode="wait">
          {activeTab === 'overview' && (
            <motion.div
              key="overview"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {/* 価格チャート（プレースホルダー） */}
              <div className="bg-card rounded-2xl border p-6">
                <h3 className="text-xl font-bold mb-6">価格チャート</h3>
                <div className="h-64 bg-muted/50 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <LineChart className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">価格チャートがここに表示されます</p>
                  </div>
                </div>
              </div>

              {/* 取引所データ */}
              <div className="bg-card rounded-2xl border p-6">
                <h3 className="text-xl font-bold mb-6">取引所別データ</h3>
                <div className="space-y-4">
                  {exchangeData.map((exchange, index) => (
                    <div key={exchange.name} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                          <Globe className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <div className="font-medium">{exchange.name}</div>
                          <div className="text-sm text-muted-foreground">Market Share: {exchange.share}</div>
                        </div>
                      </div>
                      <div className="grid grid-cols-4 gap-6 text-right">
                        <div>
                          <div className="text-sm text-muted-foreground">Price</div>
                          <div className="font-medium">{exchange.price}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">24h Volume</div>
                          <div className="font-medium">{exchange.volume24h}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Liquidity</div>
                          <div className="font-medium">{exchange.liquidity}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Change</div>
                          <div className="font-medium text-green-500">{exchange.change}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* DeFi統計 */}
              <div className="bg-card rounded-2xl border p-6">
                <h3 className="text-xl font-bold mb-6">DeFi統計</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {defiMetrics.map((metric) => (
                    <div key={metric.protocol} className="bg-muted/50 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium">{metric.protocol}</h4>
                        <span className="text-sm text-green-500">{metric.change}</span>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">TVL</span>
                          <span className="font-medium">{metric.tvl}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">APY</span>
                          <span className="font-medium">{metric.apy}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Participants</span>
                          <span className="font-medium">{metric.participants}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'price' && (
            <motion.div
              key="price"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="bg-card rounded-2xl border p-6">
                <h3 className="text-xl font-bold mb-6">価格履歴</h3>
                <div className="h-96 bg-muted/50 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <TrendingUp className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">詳細な価格チャートがここに表示されます</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-card rounded-2xl border p-6">
                  <h3 className="text-lg font-bold mb-4">価格統計</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">現在価格</span>
                      <span className="font-medium">${currentPrice}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">24h高値</span>
                      <span className="font-medium">$0.2489</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">24h安値</span>
                      <span className="font-medium">$0.2398</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">7日高値</span>
                      <span className="font-medium">$0.2567</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">7日安値</span>
                      <span className="font-medium">$0.2189</span>
                    </div>
                  </div>
                </div>

                <div className="bg-card rounded-2xl border p-6">
                  <h3 className="text-lg font-bold mb-4">市場指標</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">RSI (14)</span>
                      <span className="font-medium">68.5</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">MACD</span>
                      <span className="font-medium text-green-500">+0.0023</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">移動平均 (20)</span>
                      <span className="font-medium">$0.2387</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">移動平均 (50)</span>
                      <span className="font-medium">$0.2298</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">ボリンジャー上限</span>
                      <span className="font-medium">$0.2534</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'volume' && (
            <motion.div
              key="volume"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="bg-card rounded-2xl border p-6">
                <h3 className="text-xl font-bold mb-6">取引量チャート</h3>
                <div className="h-96 bg-muted/50 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <BarChart3 className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">取引量チャートがここに表示されます</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-card rounded-2xl border p-6">
                  <h3 className="text-lg font-bold mb-4">24時間</h3>
                  <div className="text-2xl font-bold text-primary mb-2">$2.45M</div>
                  <div className="text-sm text-green-500">+15.8%</div>
                </div>
                <div className="bg-card rounded-2xl border p-6">
                  <h3 className="text-lg font-bold mb-4">7日間</h3>
                  <div className="text-2xl font-bold text-primary mb-2">$16.8M</div>
                  <div className="text-sm text-green-500">+22.3%</div>
                </div>
                <div className="bg-card rounded-2xl border p-6">
                  <h3 className="text-lg font-bold mb-4">30日間</h3>
                  <div className="text-2xl font-bold text-primary mb-2">$68.2M</div>
                  <div className="text-sm text-green-500">+18.7%</div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'holders' && (
            <motion.div
              key="holders"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="bg-card rounded-2xl border p-6">
                <h3 className="text-xl font-bold mb-6">トップホルダー</h3>
                <div className="space-y-4">
                  {topHolders.map((holder) => (
                    <div key={holder.rank} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-sm font-bold">#{holder.rank}</span>
                        </div>
                        <div>
                          <div className="font-medium">{holder.address}</div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-muted-foreground">{holder.label}</span>
                            <span className={cn("px-2 py-1 rounded-full text-xs", getHolderTypeColor(holder.type))}>
                              {getHolderTypeText(holder.type)}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">{holder.balance}</div>
                        <div className="text-sm text-muted-foreground">{holder.percentage}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-card rounded-2xl border p-6">
                  <h3 className="text-lg font-bold mb-4">ホルダー分布</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">1-100 MP</span>
                      <span className="font-medium">8,547 (66.5%)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">100-1K MP</span>
                      <span className="font-medium">2,834 (22.1%)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">1K-10K MP</span>
                      <span className="font-medium">1,245 (9.7%)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">10K+ MP</span>
                      <span className="font-medium">221 (1.7%)</span>
                    </div>
                  </div>
                </div>

                <div className="bg-card rounded-2xl border p-6">
                  <h3 className="text-lg font-bold mb-4">ホルダー成長</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">今日</span>
                      <span className="font-medium text-green-500">+47</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">今週</span>
                      <span className="font-medium text-green-500">+234</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">今月</span>
                      <span className="font-medium text-green-500">+1,089</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">成長率</span>
                      <span className="font-medium text-green-500">+9.3%</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}