import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  ArrowRight,
  Play,
  Puzzle,
  Smartphone,
  Plug,
  RefreshCw,
  Wrench,
  Shield,
  Code,
  Palette,
  Settings,
  TestTube,
  Rocket,
  CheckCircle,
  Star,
  Users,
  Zap,
  Globe,
  Lock,
  Crown,
  Building,
  Download,
  ExternalLink,
  MousePointer,
  Layers,
  Database,
  Network,
  Eye,
  Upload
} from "lucide-react";
import { cn } from "@/lib/utils";
import { IMAGES } from "@/assets/images";

export default function DAppsBuilderPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'overview' | 'features' | 'templates' | 'pricing' | 'demo'>('overview');
  const [selectedTemplate, setSelectedTemplate] = useState<string>('nft-marketplace');
  const [selectedPlan, setSelectedPlan] = useState<'standard' | 'professional' | 'enterprise'>('professional');

  const features = [
    {
      icon: Puzzle,
      title: "ノーコードビルダー",
      description: "コーディング不要のドラッグ＆ドロップインターフェースで、誰でも簡単にDAppsを作成できます。複雑なスマートコントラクトも視覚的に構築可能です。",
      color: "text-blue-500"
    },
    {
      icon: Plug,
      title: "ウォレット連携",
      description: "MetaMask、WalletConnect、Cheataウォレットなど、主要なWeb3ウォレットとの連携機能を簡単に実装できます。",
      color: "text-green-500"
    },
    {
      icon: Smartphone,
      title: "レスポンシブデザイン",
      description: "自動的にモバイル対応のUIを生成。スマートフォン、タブレット、デスクトップなど、あらゆるデバイスで最適な表示を実現します。",
      color: "text-purple-500"
    },
    {
      icon: RefreshCw,
      title: "マルチチェーン対応",
      description: "Ethereum、Polygon、Solana、BSCなど、複数のブロックチェーンに対応。ワンクリックで異なるネットワークにデプロイできます。",
      color: "text-orange-500"
    },
    {
      icon: Wrench,
      title: "テンプレートライブラリ",
      description: "NFTマーケットプレイス、DEX、DAOなど、様々なDAppsテンプレートを用意。カスタマイズして素早くローンチできます。",
      color: "text-cyan-500"
    },
    {
      icon: Shield,
      title: "セキュリティ監査",
      description: "自動セキュリティチェック機能で、スマートコントラクトの脆弱性を事前に検出。安全なDAppsの構築をサポートします。",
      color: "text-red-500"
    }
  ];

  const buildingSteps = [
    {
      step: 1,
      title: "テンプレート選択",
      description: "目的に合ったテンプレートを選択するか、白紙の状態から作成を開始します。NFTマーケットプレイス、トークン交換、DAO、ソーシャルメディアなど、様々なテンプレートが用意されています。",
      icon: Layers,
      color: "bg-blue-500"
    },
    {
      step: 2,
      title: "UIデザイン",
      description: "ドラッグ＆ドロップでUIを構築。ボタン、フォーム、カード、リストなど、Web3に最適化された豊富なコンポーネントを自由に配置できます。カスタムCSSやテーマ設定も可能です。",
      icon: Palette,
      color: "bg-green-500"
    },
    {
      step: 3,
      title: "スマートコントラクト設定",
      description: "ビジュアルフローエディタでスマートコントラクトのロジックを設計。事前に監査済みのコントラクトモジュールを組み合わせるか、既存のコントラクトをインポートすることも可能です。",
      icon: Settings,
      color: "bg-purple-500"
    },
    {
      step: 4,
      title: "テスト",
      description: "内蔵のテストネット環境で、実際のブロックチェーンにデプロイする前にDAppsの動作を確認。トランザクションのシミュレーションやエラーチェックを行えます。",
      icon: TestTube,
      color: "bg-orange-500"
    },
    {
      step: 5,
      title: "デプロイ",
      description: "ワンクリックで選択したブロックチェーンにデプロイ。Cheataの分散型ホスティングサービスを利用するか、IPFSやArweaveなどの分散型ストレージにフロントエンドをデプロイできます。",
      icon: Rocket,
      color: "bg-cyan-500"
    }
  ];

  const templates = [
    {
      id: 'nft-marketplace',
      title: 'NFTマーケットプレイス',
      category: 'アート・コレクティブル',
      description: 'NFTの作成、販売、購入ができる完全なマーケットプレイス',
      features: ['NFTミント機能', 'オークション', 'ロイヤリティ設定', 'コレクション管理'],
      difficulty: 'Medium',
      estimatedTime: '2-3時間',
      icon: '🎨',
      popular: true,
      demoUrl: '/templates/nft-marketplace'
    },
    {
      id: 'dex',
      title: 'トークン交換（DEX）',
      category: 'DeFi',
      description: '分散型取引所でトークンのスワップと流動性提供',
      features: ['トークンスワップ', '流動性プール', 'ファーミング', 'ガバナンストークン'],
      difficulty: 'Hard',
      estimatedTime: '4-6時間',
      icon: '💱',
      popular: true,
      demoUrl: '/templates/dex'
    },
    {
      id: 'dao',
      title: 'DAO運営ツール',
      category: 'ガバナンス',
      description: '分散型自律組織の運営と投票システム',
      features: ['提案システム', '投票機能', 'トークン配布', 'マルチシグ'],
      difficulty: 'Medium',
      estimatedTime: '3-4時間',
      icon: '🏛️',
      popular: false,
      demoUrl: '/templates/dao'
    },
    {
      id: 'gaming',
      title: 'ゲーミングプラットフォーム',
      category: 'ゲーミング',
      description: 'Play-to-Earnゲームとアセット管理プラットフォーム',
      features: ['ゲームアセット', 'P2E機能', 'リーダーボード', 'マルチプレイヤー'],
      difficulty: 'Hard',
      estimatedTime: '6-8時間',
      icon: '🎮',
      popular: true,
      demoUrl: '/templates/gaming-platform'
    },
    {
      id: 'social',
      title: '分散型ソーシャル',
      category: 'コミュニケーション',
      description: 'Web3ベースのソーシャルメディアプラットフォーム',
      features: ['投稿機能', 'NFTプロフィール', 'トークン報酬', 'コミュニティ'],
      difficulty: 'Easy',
      estimatedTime: '1-2時間',
      icon: '💬',
      popular: false,
      demoUrl: '#'
    },
    {
      id: 'defi-lending',
      title: 'レンディングプロトコル',
      category: 'DeFi',
      description: '暗号資産の貸借プラットフォーム',
      features: ['貸出機能', '借入機能', '利率計算', 'リスク管理'],
      difficulty: 'Hard',
      estimatedTime: '5-7時間',
      icon: '🏦',
      popular: false,
      demoUrl: '#'
    }
  ];

  const pricingPlans = [
    {
      id: 'standard',
      name: 'スタンダード',
      price: '無料',
      description: '個人開発者向けの基本プラン',
      features: [
        '基本テンプレート',
        '1つのDAppsを作成可能',
        'テストネットデプロイ',
        'コミュニティサポート'
      ],
      limitations: [
        'メインネットデプロイ不可',
        'カスタムドメイン不可',
        'セキュリティ監査なし'
      ],
      buttonText: '今すぐ始める',
      popular: false
    },
    {
      id: 'professional',
      name: 'プロフェッショナル',
      price: '50 CHEATA/月',
      description: 'プロ開発者・スタートアップ向け',
      features: [
        'すべてのテンプレート',
        '無制限のDApps作成',
        'メインネットデプロイ',
        '自動セキュリティ監査',
        'カスタムドメイン',
        '優先サポート'
      ],
      limitations: [],
      buttonText: 'アップグレード',
      popular: true
    },
    {
      id: 'enterprise',
      name: 'エンタープライズ',
      price: '要問合せ',
      description: '大企業・エンタープライズ向け',
      features: [
        'カスタムテンプレート開発',
        'ホワイトラベル対応',
        '専用サポートマネージャー',
        '手動セキュリティ監査',
        'API統合',
        'SLA保証'
      ],
      limitations: [],
      buttonText: 'お問い合わせ',
      popular: false
    }
  ];

  const demoSteps = [
    {
      title: "テンプレート選択",
      description: "NFTマーケットプレイステンプレートを選択",
      action: "クリックしてテンプレートを選択"
    },
    {
      title: "UIカスタマイズ",
      description: "ドラッグ&ドロップでレイアウトを調整",
      action: "コンポーネントをドラッグして配置"
    },
    {
      title: "スマートコントラクト設定",
      description: "NFTミント機能を設定",
      action: "パラメータを設定"
    },
    {
      title: "プレビュー",
      description: "作成したDAppsをプレビュー",
      action: "プレビューボタンをクリック"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 flex items-center justify-center">
                <img 
                  src="/images/777.png" 
                  alt="CheatA Logo" 
                  className="w-10 h-10 object-contain drop-shadow-md z-10"
                  onLoad={() => console.log('DApps page logo loaded successfully')}
                  onError={(e) => {
                    console.log('DApps page logo failed to load, showing text-based logo');
                    e.currentTarget.style.display = 'none';
                    const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                    if (fallback) fallback.style.display = 'flex';
                  }}
                />
                {/* 高品質テキストベースロゴ（フォールバック） */}
                <div 
                  className="absolute inset-0 w-auto h-10 flex items-center justify-center text-lg font-bold tracking-wide"
                  style={{ 
                    display: 'none',
                    fontFamily: '"Inter", "Helvetica Neue", "Arial", sans-serif',
                    fontWeight: '700',
                    letterSpacing: '0.02em',
                    background: 'linear-gradient(135deg, #002FA7 0%, #001F6B 50%, #000F3D 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text',
                    filter: 'drop-shadow(0 2px 4px rgba(0, 47, 167, 0.3))',
                    transform: 'skew(-2deg)'
                  }}
                >
                  CheatA
                </div>
              </div>
              <div className="font-brand text-2xl font-bold tracking-tight" style={{
                background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
                filter: 'drop-shadow(0 1px 2px rgba(59, 130, 246, 0.3))'
              }}>
                🧩 DApps作成ツール
              </div>
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            プログラミング知識がなくても、ドラッグ＆ドロップで簡単に分散型アプリケーション（DApps）を作成できます。
            Web3の可能性を最大限に引き出し、あなたのアイデアを形にしましょう。
          </p>
        </div>
      </header>

      {/* タブナビゲーション */}
      <nav className="bg-muted/50 border-b border-border p-4">
        <div className="container mx-auto">
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'overview', label: '概要', icon: Eye },
              { id: 'features', label: '機能', icon: Zap },
              { id: 'templates', label: 'テンプレート', icon: Layers },
              { id: 'pricing', label: '料金プラン', icon: Crown },
              { id: 'demo', label: 'デモ', icon: Play }
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
                  activeTab === item.id
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-background"
                )}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-12">
        <AnimatePresence mode="wait">
          {/* 概要タブ */}
          {activeTab === 'overview' && (
            <motion.div
              key="overview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-12"
            >
              {/* ヒーローセクション */}
              <section className="text-center">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="max-w-4xl mx-auto"
                >
                  <div className="text-6xl mb-6">🧩</div>
                  <h1 className="text-4xl md:text-6xl font-bold mb-6">
                    誰でも簡単に
                    <span className="text-primary block">DAppsを作成</span>
                  </h1>
                  <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                    ノーコードでWeb3アプリケーションを構築。
                    ドラッグ＆ドロップだけで、あなたのアイデアを分散型アプリケーションに変えましょう。
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Button size="lg" className="h-14 px-8" onClick={() => setActiveTab('demo')}>
                      <Play className="mr-2 w-5 h-5" />
                      デモを体験
                    </Button>
                    <Button size="lg" variant="outline" className="h-14 px-8" onClick={() => setActiveTab('templates')}>
                      <Layers className="mr-2 w-5 h-5" />
                      テンプレートを見る
                    </Button>
                  </div>
                </motion.div>
              </section>

              {/* 主要機能 */}
              <section>
                <h2 className="text-3xl font-bold text-center mb-12">主要機能</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {features.map((feature, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-card rounded-xl p-6 border hover:shadow-lg transition-all"
                    >
                      <feature.icon className={cn("w-12 h-12 mb-4", feature.color)} />
                      <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                      <p className="text-muted-foreground text-sm leading-relaxed">
                        {feature.description}
                      </p>
                    </motion.div>
                  ))}
                </div>
              </section>

              {/* 作成の流れ */}
              <section>
                <h2 className="text-3xl font-bold text-center mb-12">DApps作成の流れ</h2>
                <div className="space-y-8">
                  {buildingSteps.map((step, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={cn(
                        "flex items-start gap-6",
                        index % 2 === 1 && "flex-row-reverse"
                      )}
                    >
                      <div className={cn(
                        "w-16 h-16 rounded-2xl flex items-center justify-center text-white font-bold text-xl flex-shrink-0",
                        step.color
                      )}>
                        {step.step}
                      </div>
                      <div className="flex-1 bg-card rounded-xl p-6 border">
                        <div className="flex items-center gap-3 mb-3">
                          <step.icon className="w-6 h-6 text-primary" />
                          <h3 className="text-xl font-bold">{step.title}</h3>
                        </div>
                        <p className="text-muted-foreground leading-relaxed">
                          {step.description}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </section>
            </motion.div>
          )}

          {/* 機能タブ */}
          {activeTab === 'features' && (
            <motion.div
              key="features"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-12"
            >
              <section>
                <h2 className="text-3xl font-bold text-center mb-12">詳細機能</h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {features.map((feature, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-card rounded-xl p-8 border"
                    >
                      <div className="flex items-start gap-4">
                        <feature.icon className={cn("w-10 h-10 mt-1", feature.color)} />
                        <div>
                          <h3 className="text-2xl font-bold mb-4">{feature.title}</h3>
                          <p className="text-muted-foreground mb-6 leading-relaxed">
                            {feature.description}
                          </p>
                          
                          {/* 機能詳細 */}
                          <div className="space-y-3">
                            {index === 0 && (
                              <>
                                <div className="flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                  <span className="text-sm">ビジュアルフローエディタ</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                  <span className="text-sm">プリビルトコンポーネント</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                  <span className="text-sm">リアルタイムプレビュー</span>
                                </div>
                              </>
                            )}
                            {index === 1 && (
                              <>
                                <div className="flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                  <span className="text-sm">MetaMask統合</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                  <span className="text-sm">WalletConnect対応</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                  <span className="text-sm">マルチウォレット対応</span>
                                </div>
                              </>
                            )}
                            {index === 2 && (
                              <>
                                <div className="flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                  <span className="text-sm">自動レスポンシブ</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                  <span className="text-sm">PWA対応</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                  <span className="text-sm">クロスプラットフォーム</span>
                                </div>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </section>
            </motion.div>
          )}

          {/* テンプレートタブ */}
          {activeTab === 'templates' && (
            <motion.div
              key="templates"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-12"
            >
              <section>
                <h2 className="text-3xl font-bold text-center mb-12">人気のDAppsテンプレート</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {templates.map((template, index) => (
                    <motion.div
                      key={template.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={cn(
                        "bg-card rounded-xl p-6 border cursor-pointer transition-all hover:shadow-lg",
                        selectedTemplate === template.id && "ring-2 ring-primary"
                      )}
                      onClick={() => setSelectedTemplate(template.id)}
                    >
                      {template.popular && (
                        <div className="flex justify-end mb-2">
                          <span className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full font-semibold">
                            人気
                          </span>
                        </div>
                      )}
                      
                      <div className="text-center mb-4">
                        <div className="text-4xl mb-3">{template.icon}</div>
                        <h3 className="text-xl font-bold mb-2">{template.title}</h3>
                        <p className="text-sm text-primary font-medium">{template.category}</p>
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-4">
                        {template.description}
                      </p>
                      
                      <div className="space-y-2 mb-4">
                        {template.features.map((feature, idx) => (
                          <div key={idx} className="flex items-center gap-2 text-xs">
                            <CheckCircle className="w-3 h-3 text-green-500" />
                            <span>{feature}</span>
                          </div>
                        ))}
                      </div>
                      
                      <div className="flex justify-between items-center text-xs text-muted-foreground mb-4">
                        <span className={cn(
                          "px-2 py-1 rounded-full",
                          template.difficulty === 'Easy' ? 'bg-green-100 text-green-800' :
                          template.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        )}>
                          {template.difficulty}
                        </span>
                        <span>{template.estimatedTime}</span>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button 
                          className="flex-1" 
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (template.demoUrl && template.demoUrl !== '#') {
                              navigate(template.demoUrl);
                            }
                          }}
                          disabled={template.demoUrl === '#'}
                        >
                          {template.demoUrl === '#' ? '近日公開' : 'デモを見る'}
                        </Button>
                        <Button 
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveTab('demo');
                          }}
                        >
                          作成
                        </Button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </section>
            </motion.div>
          )}

          {/* 料金プランタブ */}
          {activeTab === 'pricing' && (
            <motion.div
              key="pricing"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-12"
            >
              <section>
                <h2 className="text-3xl font-bold text-center mb-12">料金プラン</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {pricingPlans.map((plan, index) => (
                    <motion.div
                      key={plan.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={cn(
                        "bg-card rounded-xl p-8 border relative",
                        plan.popular && "ring-2 ring-primary shadow-lg scale-105"
                      )}
                    >
                      {plan.popular && (
                        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                          <span className="bg-primary text-primary-foreground text-sm px-4 py-1 rounded-full font-semibold">
                            おすすめ
                          </span>
                        </div>
                      )}
                      
                      <div className="text-center mb-6">
                        <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                        <div className="text-3xl font-bold text-primary mb-2">{plan.price}</div>
                        <p className="text-sm text-muted-foreground">{plan.description}</p>
                      </div>
                      
                      <div className="space-y-3 mb-6">
                        {plan.features.map((feature, idx) => (
                          <div key={idx} className="flex items-center gap-2">
                            <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                            <span className="text-sm">{feature}</span>
                          </div>
                        ))}
                      </div>
                      
                      <Button 
                        className={cn(
                          "w-full",
                          plan.popular ? "bg-primary" : ""
                        )}
                        variant={plan.popular ? "default" : "outline"}
                        onClick={() => setSelectedPlan(plan.id as any)}
                      >
                        {plan.buttonText}
                      </Button>
                    </motion.div>
                  ))}
                </div>
              </section>

              {/* 比較表 */}
              <section>
                <h3 className="text-2xl font-bold text-center mb-8">機能比較</h3>
                <div className="bg-card rounded-xl p-6 border overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-4">機能</th>
                        <th className="text-center py-3 px-4">スタンダード</th>
                        <th className="text-center py-3 px-4">プロフェッショナル</th>
                        <th className="text-center py-3 px-4">エンタープライズ</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        ['DApps作成数', '1個', '無制限', '無制限'],
                        ['テンプレート', '基本のみ', 'すべて', 'すべて + カスタム'],
                        ['デプロイ', 'テストネットのみ', 'メインネット対応', 'メインネット対応'],
                        ['セキュリティ監査', '×', '自動', '手動 + 自動'],
                        ['サポート', 'コミュニティ', '優先サポート', '専用マネージャー'],
                        ['カスタムドメイン', '×', '○', '○'],
                        ['API統合', '×', '×', '○'],
                        ['SLA保証', '×', '×', '○']
                      ].map((row, idx) => (
                        <tr key={idx} className="border-b">
                          <td className="py-3 px-4 font-medium">{row[0]}</td>
                          <td className="py-3 px-4 text-center text-sm">{row[1]}</td>
                          <td className="py-3 px-4 text-center text-sm">{row[2]}</td>
                          <td className="py-3 px-4 text-center text-sm">{row[3]}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            </motion.div>
          )}

          {/* デモタブ */}
          {activeTab === 'demo' && (
            <motion.div
              key="demo"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-12"
            >
              <section>
                <h2 className="text-3xl font-bold text-center mb-12">インタラクティブデモ</h2>
                
                {/* デモ画面 */}
                <div className="bg-card rounded-xl p-8 border">
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* ステップ表示 */}
                    <div className="lg:col-span-1">
                      <h3 className="font-semibold mb-4">作成ステップ</h3>
                      <div className="space-y-3">
                        {demoSteps.map((step, index) => (
                          <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                            <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                              {index + 1}
                            </div>
                            <div>
                              <h4 className="font-medium text-sm">{step.title}</h4>
                              <p className="text-xs text-muted-foreground">{step.description}</p>
                              <p className="text-xs text-primary mt-1">{step.action}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    {/* デモ画面 */}
                    <div className="lg:col-span-2">
                      <div className="bg-gradient-to-br from-primary/5 to-accent/5 rounded-xl p-6 border-2 border-dashed border-primary/20">
                        <div className="text-center">
                          <div className="text-6xl mb-4">🎨</div>
                          <h3 className="text-xl font-bold mb-2">NFTマーケットプレイス</h3>
                          <p className="text-muted-foreground mb-6">
                            ドラッグ＆ドロップでUIをカスタマイズ
                          </p>
                          
                          {/* モックアップUI */}
                          <div className="bg-background rounded-lg p-4 border">
                            <div className="grid grid-cols-2 gap-4">
                              <div className="bg-muted rounded-lg p-3 text-center">
                                <div className="w-full h-20 bg-primary/20 rounded mb-2"></div>
                                <p className="text-xs">NFT Card</p>
                              </div>
                              <div className="bg-muted rounded-lg p-3 text-center">
                                <div className="w-full h-20 bg-green-500/20 rounded mb-2"></div>
                                <p className="text-xs">Buy Button</p>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex gap-2 justify-center mt-6">
                            <Button size="sm" variant="outline">
                              <MousePointer className="w-4 h-4 mr-2" />
                              コンポーネント追加
                            </Button>
                            <Button size="sm" variant="outline">
                              <Eye className="w-4 h-4 mr-2" />
                              プレビュー
                            </Button>
                            <Button size="sm">
                              <Upload className="w-4 h-4 mr-2" />
                              デプロイ
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* 実際のデモを開始 */}
                <div className="text-center">
                  <Button size="lg" className="h-14 px-8" onClick={() => navigate('/demo')}>
                    <Play className="mr-2 w-5 h-5" />
                    実際のデモを体験
                  </Button>
                </div>
              </section>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 最終CTA */}
        <section className="mt-16 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-primary to-accent rounded-2xl p-8 text-white"
          >
            <Puzzle className="w-16 h-16 mx-auto mb-6" />
            <h2 className="text-3xl font-bold mb-4">DApps作成を始める</h2>
            <p className="mb-6 opacity-90 max-w-2xl mx-auto">
              あなたのアイデアをWeb3アプリケーションに変えましょう。
              ノーコードで簡単に、プロフェッショナルなDAppsを作成できます。
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-white text-primary hover:bg-white/90 h-14 px-8"
                onClick={() => setActiveTab('demo')}
              >
                <Play className="mr-2 w-5 h-5" />
                無料で始める
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white/30 text-white hover:bg-white/10 h-14 px-8"
                onClick={() => setActiveTab('templates')}
              >
                <Layers className="mr-2 w-5 h-5" />
                テンプレートを見る
              </Button>
            </div>
          </motion.div>
        </section>
      </main>
    </div>
  );
}