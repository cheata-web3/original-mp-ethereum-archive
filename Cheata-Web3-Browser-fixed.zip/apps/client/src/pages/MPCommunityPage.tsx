import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  Users,
  MessageCircle,
  Heart,
  Share,
  Trophy,
  Star,
  Crown,
  Flame,
  Zap,
  Target,
  Gift,
  Calendar,
  Clock,
  ThumbsUp,
  ThumbsDown,
  Reply,
  Send,
  Plus,
  Filter,
  Search,
  Bell,
  Settings,
  ExternalLink,
  Award,
  TrendingUp,
  Activity,
  Globe,
  Shield
} from "lucide-react";
import { cn } from "@/lib/utils";
import { IMAGES } from "@/assets/images";

export default function MPCommunityPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'feed' | 'governance' | 'events' | 'leaderboard'>('feed');
  const [newPost, setNewPost] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // コミュニティ統計
  const communityStats = [
    {
      label: 'アクティブメンバー',
      value: '12,847',
      change: '+234',
      positive: true,
      icon: Users,
      description: '過去30日間のアクティブユーザー'
    },
    {
      label: '今日の投稿',
      value: '156',
      change: '+23',
      positive: true,
      icon: MessageCircle,
      description: '本日の新規投稿数'
    },
    {
      label: 'ガバナンス提案',
      value: '8',
      change: '+2',
      positive: true,
      icon: Trophy,
      description: 'アクティブな提案数'
    },
    {
      label: 'コミュニティスコア',
      value: '9.2/10',
      change: '+0.3',
      positive: true,
      icon: Star,
      description: 'コミュニティの健全性スコア'
    }
  ];

  // フィード投稿
  const feedPosts = [
    {
      id: 1,
      author: 'CheatADev',
      avatar: '👨‍💻',
      role: 'Team',
      timestamp: '2時間前',
      content: 'MP v2.0のアップデートが完了しました！新しいステーキング機能をお試しください。',
      likes: 47,
      replies: 12,
      shares: 8,
      category: 'announcement',
      pinned: true
    },
    {
      id: 2,
      author: 'CryptoWhale',
      avatar: '🐋',
      role: 'Whale',
      timestamp: '4時間前',
      content: 'MPの価格が$0.25を突破！長期ホルダーとして嬉しい限りです。コミュニティの成長が素晴らしい！',
      likes: 89,
      replies: 23,
      shares: 15,
      category: 'discussion',
      pinned: false
    },
    {
      id: 3,
      author: 'DeFiExplorer',
      avatar: '🔍',
      role: 'Contributor',
      timestamp: '6時間前',
      content: 'MPのDeFiプールで年利25%を達成中。リスク管理についてのガイドを作成しました。',
      likes: 34,
      replies: 18,
      shares: 22,
      category: 'education',
      pinned: false
    },
    {
      id: 4,
      author: 'NewbieMPer',
      avatar: '🌱',
      role: 'Member',
      timestamp: '8時間前',
      content: 'MPを始めたばかりです。ステーキングの始め方を教えてください！',
      likes: 12,
      replies: 31,
      shares: 3,
      category: 'question',
      pinned: false
    }
  ];

  // ガバナンス提案
  const governanceProposals = [
    {
      id: 1,
      title: 'MPステーキング報酬の増加提案',
      description: 'コミュニティの成長に伴い、ステーキング報酬を15%から18%に増加する提案',
      proposer: 'CheatADAO',
      status: 'active',
      votesFor: 8547,
      votesAgainst: 1234,
      totalVotes: 9781,
      endDate: '2026-03-15',
      category: 'rewards'
    },
    {
      id: 2,
      title: '新しいDeFiパートナーシップ承認',
      description: 'Compound Protocolとの統合によるレンディング機能の追加',
      proposer: 'DeFiCommittee',
      status: 'active',
      votesFor: 6234,
      votesAgainst: 2876,
      totalVotes: 9110,
      endDate: '2026-03-12',
      category: 'partnership'
    },
    {
      id: 3,
      title: 'コミュニティファンドの設立',
      description: '開発者支援とマーケティング活動のための専用ファンドを設立',
      proposer: 'CommunityLead',
      status: 'passed',
      votesFor: 12456,
      votesAgainst: 3421,
      totalVotes: 15877,
      endDate: '2026-03-01',
      category: 'fund'
    }
  ];

  // イベント
  const upcomingEvents = [
    {
      id: 1,
      title: 'MP Community AMA',
      description: 'チーム開発者との質疑応答セッション',
      date: '2026-03-10',
      time: '20:00 JST',
      type: 'ama',
      participants: 234,
      status: 'upcoming'
    },
    {
      id: 2,
      title: 'DeFi Workshop',
      description: 'MPを使ったDeFi戦略の実践ワークショップ',
      date: '2026-03-15',
      time: '19:00 JST',
      type: 'workshop',
      participants: 156,
      status: 'upcoming'
    },
    {
      id: 3,
      title: 'Trading Competition',
      description: 'MP取引コンテスト - 賞金総額10,000 MP',
      date: '2026-03-20',
      time: '00:00 JST',
      type: 'competition',
      participants: 89,
      status: 'upcoming'
    }
  ];

  // リーダーボード
  const leaderboard = [
    {
      rank: 1,
      username: 'MPMaster',
      avatar: '👑',
      points: 15847,
      contributions: 234,
      badge: 'Legend',
      level: 50
    },
    {
      rank: 2,
      username: 'CryptoSage',
      avatar: '🧙‍♂️',
      points: 12456,
      contributions: 189,
      badge: 'Expert',
      level: 45
    },
    {
      rank: 3,
      username: 'DeFiNinja',
      avatar: '🥷',
      points: 9876,
      contributions: 156,
      badge: 'Pro',
      level: 38
    },
    {
      rank: 4,
      username: 'BlockchainBard',
      avatar: '📜',
      points: 8234,
      contributions: 134,
      badge: 'Advanced',
      level: 32
    },
    {
      rank: 5,
      username: 'TokenTamer',
      avatar: '🎯',
      points: 6789,
      contributions: 98,
      badge: 'Intermediate',
      level: 28
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-blue-500 bg-blue-500/10';
      case 'passed': return 'text-green-500 bg-green-500/10';
      case 'rejected': return 'text-red-500 bg-red-500/10';
      default: return 'text-muted-foreground bg-muted/10';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return '投票中';
      case 'passed': return '可決';
      case 'rejected': return '否決';
      default: return '不明';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'announcement': return 'text-blue-500 bg-blue-500/10';
      case 'discussion': return 'text-green-500 bg-green-500/10';
      case 'education': return 'text-purple-500 bg-purple-500/10';
      case 'question': return 'text-orange-500 bg-orange-500/10';
      default: return 'text-muted-foreground bg-muted/10';
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'Team': return 'text-blue-500 bg-blue-500/10';
      case 'Whale': return 'text-purple-500 bg-purple-500/10';
      case 'Contributor': return 'text-green-500 bg-green-500/10';
      default: return 'text-muted-foreground bg-muted/10';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto max-w-7xl">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 flex items-center justify-center">
                <img 
                  src="/images/777.png" 
                  alt="MP Community Logo" 
                  className="w-10 h-10 object-contain drop-shadow-md z-10"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                    if (fallback) fallback.style.display = 'flex';
                  }}
                />
                <div 
                  className="absolute inset-0 w-auto h-10 flex items-center justify-center text-lg font-bold tracking-tight"
                  style={{ 
                    display: 'none',
                    background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text'
                  }}
                >
                  CheatA
                </div>
              </div>
              <div className="font-brand text-2xl font-bold tracking-tight" style={{
                background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}>
                👥 MPコミュニティ
              </div>
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            Magic Pointコミュニティの中心地。
            最新情報の共有、ガバナンス参加、イベント情報をチェックしましょう。
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-12 max-w-7xl">
        {/* 統計カード */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {communityStats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-card rounded-2xl border p-6 hover:shadow-lg transition-shadow group"
            >
              <div className="flex items-center justify-between mb-4">
                <stat.icon className="w-8 h-8 text-primary" />
                <div className={cn(
                  "text-sm px-2 py-1 rounded-full",
                  stat.positive ? "text-green-500 bg-green-500/10" : "text-red-500 bg-red-500/10"
                )}>
                  {stat.change}
                </div>
              </div>
              <div className="text-2xl font-bold mb-1">{stat.value}</div>
              <div className="text-sm text-muted-foreground mb-2">{stat.label}</div>
              <div className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">
                {stat.description}
              </div>
            </motion.div>
          ))}
        </div>

        {/* タブナビゲーション */}
        <div className="flex space-x-1 bg-muted p-1 rounded-xl mb-8">
          {[
            { id: 'feed', label: 'フィード', icon: MessageCircle },
            { id: 'governance', label: 'ガバナンス', icon: Trophy },
            { id: 'events', label: 'イベント', icon: Calendar },
            { id: 'leaderboard', label: 'リーダーボード', icon: Crown }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg text-sm font-medium transition-all",
                activeTab === tab.id
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* タブコンテンツ */}
        <AnimatePresence mode="wait">
          {activeTab === 'feed' && (
            <motion.div
              key="feed"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {/* 新規投稿 */}
              <div className="bg-card rounded-2xl border p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-lg">👤</span>
                  </div>
                  <div className="flex-1">
                    <Input
                      placeholder="コミュニティと共有したいことはありますか？"
                      value={newPost}
                      onChange={(e) => setNewPost(e.target.value)}
                      className="mb-4"
                    />
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <select className="text-sm border border-border rounded px-2 py-1">
                          <option value="discussion">ディスカッション</option>
                          <option value="question">質問</option>
                          <option value="education">教育</option>
                          <option value="announcement">お知らせ</option>
                        </select>
                      </div>
                      <Button size="sm" disabled={!newPost.trim()}>
                        <Send className="w-4 h-4 mr-2" />
                        投稿
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              {/* フィード投稿一覧 */}
              <div className="space-y-4">
                {feedPosts.map((post) => (
                  <div key={post.id} className={cn(
                    "bg-card rounded-2xl border p-6",
                    post.pinned && "border-primary/50 bg-primary/5"
                  )}>
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center text-xl">
                        {post.avatar}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="font-medium">{post.author}</span>
                          <span className={cn("px-2 py-1 rounded-full text-xs", getRoleColor(post.role))}>
                            {post.role}
                          </span>
                          <span className={cn("px-2 py-1 rounded-full text-xs", getCategoryColor(post.category))}>
                            {post.category}
                          </span>
                          <span className="text-sm text-muted-foreground">{post.timestamp}</span>
                          {post.pinned && (
                            <span className="text-primary text-xs">📌 ピン留め</span>
                          )}
                        </div>
                        <p className="text-foreground mb-4">{post.content}</p>
                        <div className="flex items-center gap-6">
                          <button className="flex items-center gap-2 text-muted-foreground hover:text-red-500 transition-colors">
                            <Heart className="w-4 h-4" />
                            <span className="text-sm">{post.likes}</span>
                          </button>
                          <button className="flex items-center gap-2 text-muted-foreground hover:text-blue-500 transition-colors">
                            <Reply className="w-4 h-4" />
                            <span className="text-sm">{post.replies}</span>
                          </button>
                          <button className="flex items-center gap-2 text-muted-foreground hover:text-green-500 transition-colors">
                            <Share className="w-4 h-4" />
                            <span className="text-sm">{post.shares}</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'governance' && (
            <motion.div
              key="governance"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {governanceProposals.map((proposal) => (
                <div key={proposal.id} className="bg-card rounded-2xl border p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-xl font-bold">{proposal.title}</h3>
                        <span className={cn("px-2 py-1 rounded-full text-xs", getStatusColor(proposal.status))}>
                          {getStatusText(proposal.status)}
                        </span>
                      </div>
                      <p className="text-muted-foreground mb-4">{proposal.description}</p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>提案者: {proposal.proposer}</span>
                        <span>終了日: {proposal.endDate}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          <ThumbsUp className="w-4 h-4 text-green-500" />
                          <span className="font-medium">{proposal.votesFor.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <ThumbsDown className="w-4 h-4 text-red-500" />
                          <span className="font-medium">{proposal.votesAgainst.toLocaleString()}</span>
                        </div>
                        <span className="text-sm text-muted-foreground">
                          総投票数: {proposal.totalVotes.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    <div className="w-full bg-muted rounded-full h-2">
                      <div 
                        className="bg-green-500 h-2 rounded-full"
                        style={{ width: `${(proposal.votesFor / proposal.totalVotes) * 100}%` }}
                      />
                    </div>

                    {proposal.status === 'active' && (
                      <div className="flex gap-2">
                        <Button size="sm" className="bg-green-500 hover:bg-green-600">
                          <ThumbsUp className="w-4 h-4 mr-2" />
                          賛成
                        </Button>
                        <Button size="sm" variant="outline" className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white">
                          <ThumbsDown className="w-4 h-4 mr-2" />
                          反対
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </motion.div>
          )}

          {activeTab === 'events' && (
            <motion.div
              key="events"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {upcomingEvents.map((event) => (
                <div key={event.id} className="bg-card rounded-2xl border p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-16 bg-primary/10 rounded-xl flex items-center justify-center">
                      <Calendar className="w-8 h-8 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-xl font-bold">{event.title}</h3>
                        <span className="bg-blue-500/10 text-blue-500 text-xs px-2 py-1 rounded-full">
                          {event.type}
                        </span>
                      </div>
                      <p className="text-muted-foreground mb-4">{event.description}</p>
                      <div className="flex items-center gap-6 text-sm">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-muted-foreground" />
                          <span>{event.date}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span>{event.time}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 text-muted-foreground" />
                          <span>{event.participants} 参加予定</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col gap-2">
                      <Button size="sm">
                        参加する
                      </Button>
                      <Button size="sm" variant="outline">
                        <Bell className="w-4 h-4 mr-2" />
                        通知
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          )}

          {activeTab === 'leaderboard' && (
            <motion.div
              key="leaderboard"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="bg-card rounded-2xl border p-6">
                <h3 className="text-xl font-bold mb-6">コミュニティリーダーボード</h3>
                <div className="space-y-4">
                  {leaderboard.map((user) => (
                    <div key={user.rank} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className={cn(
                          "w-10 h-10 rounded-full flex items-center justify-center font-bold",
                          user.rank === 1 ? "bg-yellow-500/20 text-yellow-500" :
                          user.rank === 2 ? "bg-gray-400/20 text-gray-400" :
                          user.rank === 3 ? "bg-orange-500/20 text-orange-500" :
                          "bg-muted text-muted-foreground"
                        )}>
                          #{user.rank}
                        </div>
                        <div className="text-2xl">{user.avatar}</div>
                        <div>
                          <div className="font-medium">{user.username}</div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-muted-foreground">Level {user.level}</span>
                            <span className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full">
                              {user.badge}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">{user.points.toLocaleString()} pts</div>
                        <div className="text-sm text-muted-foreground">{user.contributions} contributions</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-card rounded-2xl border p-6">
                  <h4 className="font-bold mb-4">今月のMVP</h4>
                  <div className="flex items-center gap-3">
                    <div className="text-3xl">👑</div>
                    <div>
                      <div className="font-medium">MPMaster</div>
                      <div className="text-sm text-muted-foreground">2,847 pts</div>
                    </div>
                  </div>
                </div>

                <div className="bg-card rounded-2xl border p-6">
                  <h4 className="font-bold mb-4">新人賞</h4>
                  <div className="flex items-center gap-3">
                    <div className="text-3xl">🌟</div>
                    <div>
                      <div className="font-medium">RisingMPer</div>
                      <div className="text-sm text-muted-foreground">456 pts</div>
                    </div>
                  </div>
                </div>

                <div className="bg-card rounded-2xl border p-6">
                  <h4 className="font-bold mb-4">貢献者賞</h4>
                  <div className="flex items-center gap-3">
                    <div className="text-3xl">🏆</div>
                    <div>
                      <div className="font-medium">HelpfulMPer</div>
                      <div className="text-sm text-muted-foreground">89 helps</div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}