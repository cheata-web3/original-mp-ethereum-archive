import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft, 
  Shield, 
  Users, 
  Leaf, 
  CheckCircle, 
  AlertTriangle,
  Lightbulb,
  Target,
  TrendingUp,
  Lock,
  Globe,
  Zap
} from "lucide-react";

export default function BestPracticesPage() {
  const navigate = useNavigate();

  const practices = [
    {
      id: "security",
      icon: Shield,
      title: "⚡ セキュリティファースト",
      description: "Web3の世界では、セキュリティが最優先事項です",
      details: [
        "プライベートキーの安全な管理",
        "マルチシグウォレットの活用",
        "定期的なセキュリティ監査",
        "フィッシング攻撃への対策",
        "スマートコントラクトの検証"
      ],
      tips: [
        "ハードウェアウォレットを使用する",
        "シードフレーズを安全な場所に保管",
        "怪しいリンクはクリックしない",
        "公式サイトのURLを確認する"
      ]
    },
    {
      id: "community",
      icon: Users,
      title: "🧠 コミュニティ中心",
      description: "強固なコミュニティがプロジェクトの成功の鍵です",
      details: [
        "透明性のあるコミュニケーション",
        "コミュニティガバナンスの実装",
        "定期的なAMA（Ask Me Anything）",
        "フィードバックの積極的な収集",
        "コミュニティ主導の開発"
      ],
      tips: [
        "Discord/Telegramでの活発な議論",
        "提案システムの構築",
        "コミュニティリーダーの育成",
        "イベントやミートアップの開催"
      ]
    },
    {
      id: "sustainability",
      icon: Leaf,
      title: "💰 持続可能性",
      description: "長期的な成長と持続可能なエコシステムの構築",
      details: [
        "環境に配慮したブロックチェーン選択",
        "持続可能なトークノミクス設計",
        "エネルギー効率の最適化",
        "循環型経済モデルの採用",
        "社会的責任の重視"
      ],
      tips: [
        "Proof of Stakeチェーンの活用",
        "カーボンオフセットの実施",
        "長期的なロードマップの策定",
        "ステークホルダーとの協力"
      ]
    }
  ];

  const commonMistakes = [
    {
      mistake: "プライベートキーの不適切な管理",
      solution: "ハードウェアウォレットとマルチシグの使用"
    },
    {
      mistake: "ガス代の最適化不足",
      solution: "トランザクションタイミングとレイヤー2の活用"
    },
    {
      mistake: "スマートコントラクトの脆弱性",
      solution: "徹底的な監査とテストの実施"
    },
    {
      mistake: "コミュニティとの疎通不足",
      solution: "定期的な更新と透明性のあるコミュニケーション"
    }
  ];

  const successMetrics = [
    {
      metric: "セキュリティスコア",
      target: "95%以上",
      description: "セキュリティ監査での評価"
    },
    {
      metric: "コミュニティ参加率",
      target: "60%以上",
      description: "アクティブユーザーの割合"
    },
    {
      metric: "ガバナンス参加",
      target: "40%以上",
      description: "投票参加率"
    },
    {
      metric: "持続可能性指標",
      target: "A評価",
      description: "環境・社会・ガバナンス評価"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="font-brand text-2xl font-bold text-primary">
              Web3ベストプラクティス
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            Web3プロジェクトを成功に導くための実践的なガイドラインと戦略
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-12">
        {/* 概要セクション */}
        <section className="mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-8 border border-primary/20"
          >
            <h2 className="text-3xl font-bold mb-6 text-center">
              🌐 Web3成功の3つの柱
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {practices.map((practice, index) => (
                <motion.div
                  key={practice.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center p-6 bg-card rounded-xl border"
                >
                  <practice.icon className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-2">{practice.title}</h3>
                  <p className="text-muted-foreground">{practice.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>

        {/* 詳細ベストプラクティス */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">📋 実践ガイド</h2>
          <div className="space-y-8">
            {practices.map((practice, index) => (
              <motion.div
                key={practice.id}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.2 }}
                className="bg-card rounded-2xl p-8 border"
              >
                <div className="flex items-start gap-6">
                  <div className="flex-shrink-0">
                    <practice.icon className="w-16 h-16 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold mb-4">{practice.title}</h3>
                    <p className="text-muted-foreground mb-6">{practice.description}</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold mb-3 flex items-center gap-2">
                          <CheckCircle className="w-5 h-5 text-green-500" />
                          重要なポイント
                        </h4>
                        <ul className="space-y-2">
                          {practice.details.map((detail, idx) => (
                            <li key={idx} className="text-sm text-muted-foreground flex items-start gap-2">
                              <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                              {detail}
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold mb-3 flex items-center gap-2">
                          <Lightbulb className="w-5 h-5 text-yellow-500" />
                          実践のコツ
                        </h4>
                        <ul className="space-y-2">
                          {practice.tips.map((tip, idx) => (
                            <li key={idx} className="text-sm text-muted-foreground flex items-start gap-2">
                              <div className="w-1.5 h-1.5 bg-yellow-500 rounded-full mt-2 flex-shrink-0" />
                              {tip}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* よくある間違いと対策 */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">⚠️ よくある間違いと対策</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {commonMistakes.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-card rounded-xl p-6 border border-red-200"
              >
                <div className="flex items-start gap-4">
                  <AlertTriangle className="w-6 h-6 text-red-500 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold mb-2 text-red-700">間違い</h3>
                    <p className="text-sm text-muted-foreground mb-3">{item.mistake}</p>
                    <div className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-green-700 text-sm">解決策</h4>
                        <p className="text-sm text-muted-foreground">{item.solution}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* 成功指標 */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">📊 成功指標</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {successMetrics.map((metric, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className="bg-card rounded-xl p-6 border text-center"
              >
                <Target className="w-8 h-8 text-primary mx-auto mb-3" />
                <h3 className="font-semibold mb-2">{metric.metric}</h3>
                <div className="text-2xl font-bold text-primary mb-2">{metric.target}</div>
                <p className="text-sm text-muted-foreground">{metric.description}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* 行動喚起 */}
        <section className="text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-primary to-accent rounded-2xl p-8 text-white"
          >
            <h2 className="text-3xl font-bold mb-4">🚀 今すぐ実践を始めよう</h2>
            <p className="mb-6 opacity-90 max-w-2xl mx-auto">
              これらのベストプラクティスを実践して、成功するWeb3プロジェクトを構築しましょう
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-white text-primary hover:bg-white/90"
                onClick={() => navigate("/demo")}
              >
                <Zap className="mr-2 w-5 h-5" />
                デモを試す
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white/30 text-white hover:bg-white/10"
                onClick={() => navigate("/")}
              >
                <Globe className="mr-2 w-5 h-5" />
                他の機能を見る
              </Button>
            </div>
          </motion.div>
        </section>
      </main>
    </div>
  );
}