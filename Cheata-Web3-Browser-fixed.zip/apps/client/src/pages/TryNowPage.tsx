import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft, 
  ArrowRight,
  Play,
  Download,
  Chrome,
  CheckCircle,
  Star,
  Shield,
  Zap,
  Rocket,
  Video,
  Wallet
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function TryNowPage() {
  const navigate = useNavigate();
  const [selectedOption, setSelectedOption] = useState<'demo' | 'download' | 'extension'>('demo');

  const options = [
    {
      id: 'demo' as const,
      title: 'オンラインデモ',
      subtitle: 'ブラウザで即座に体験',
      description: 'インストール不要で、すぐにCheatAの機能を試せます',
      icon: Play,
      color: 'from-green-500 to-emerald-600',
      features: [
        'ウォレット接続デモ',
        'ビデオ通話機能',
        'DeFi ダッシュボード',
        'Web3 検索'
      ],
      action: () => navigate('/demo'),
      actionText: 'デモを開始',
      time: '即座に開始',
      popular: true
    },
    {
      id: 'download' as const,
      title: 'フル版ダウンロード',
      subtitle: '完全な機能を体験',
      description: 'すべての機能が使える完全版をダウンロード',
      icon: Download,
      color: 'from-blue-500 to-cyan-600',
      features: [
        'すべての機能利用可能',
        'オフライン対応',
        '高速パフォーマンス',
        '定期アップデート'
      ],
      action: () => navigate('/download'),
      actionText: 'ダウンロード',
      time: '2-3分でセットアップ',
      popular: false
    },
    {
      id: 'extension' as const,
      title: 'ブラウザ拡張機能',
      subtitle: '既存ブラウザに追加',
      description: 'Chrome/Edgeに拡張機能として追加',
      icon: Chrome,
      color: 'from-purple-500 to-violet-600',
      features: [
        '軽量インストール',
        '既存ブラウザと統合',
        'Web3機能を追加',
        '簡単セットアップ'
      ],
      action: () => navigate('/download'),
      actionText: '拡張機能を追加',
      time: '30秒でインストール',
      popular: false
    }
  ];

  const quickFeatures = [
    {
      icon: Wallet,
      title: 'マルチチェーンウォレット',
      description: 'Ethereum、Solana、Polygonなど主要チェーンに対応'
    },
    {
      icon: Video,
      title: 'セキュア通話',
      description: 'エンドツーエンド暗号化されたビデオ・音声通話'
    },
    {
      icon: Shield,
      title: 'プライバシー保護',
      description: 'ゼロ知識証明技術による完全なプライバシー保護'
    },
    {
      icon: Zap,
      title: 'DeFi統合',
      description: 'DEX、レンディング、ステーキングを統合管理'
    }
  ];

  const selectedOptionData = options.find(opt => opt.id === selectedOption);

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="font-brand text-2xl font-bold text-primary">
              CheatA を今すぐ試す
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            あなたに最適な方法でCheatAブラウザを体験してください
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-12">
        {/* ヒーローセクション */}
        <section className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Web3の世界へ
              <span className="text-primary block">ようこそ</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              3つの方法からお選びいただけます。どの方法でも、CheatAの革新的な機能を体験できます。
            </p>
          </motion.div>
        </section>

        {/* オプション選択 */}
        <section className="mb-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {options.map((option, index) => (
              <motion.button
                key={option.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => setSelectedOption(option.id)}
                className={cn(
                  "relative p-6 rounded-2xl border-2 transition-all text-left h-full",
                  selectedOption === option.id
                    ? "border-primary bg-primary/5 shadow-lg"
                    : "border-border hover:border-primary/50 hover:shadow-md"
                )}
              >
                {option.popular && (
                  <div className="absolute -top-3 left-6 bg-primary text-primary-foreground text-sm px-3 py-1 rounded-full font-semibold">
                    おすすめ
                  </div>
                )}
                
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center mb-4 bg-gradient-to-br",
                  option.color
                )}>
                  <option.icon className="w-6 h-6 text-white" />
                </div>
                
                <h3 className="text-xl font-bold mb-2">{option.title}</h3>
                <p className="text-primary font-semibold mb-2">{option.subtitle}</p>
                <p className="text-muted-foreground text-sm mb-4">{option.description}</p>
                
                <div className="space-y-2">
                  {option.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
                
                <div className="mt-4 pt-4 border-t border-border">
                  <p className="text-xs text-muted-foreground">{option.time}</p>
                </div>
              </motion.button>
            ))}
          </div>

          {/* 選択されたオプションの詳細 */}
          {selectedOptionData && (
            <motion.div
              key={selectedOption}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card rounded-2xl p-8 border text-center"
            >
              <div className={cn(
                "w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 bg-gradient-to-br",
                selectedOptionData.color
              )}>
                <selectedOptionData.icon className="w-8 h-8 text-white" />
              </div>
              
              <h2 className="text-2xl font-bold mb-4">{selectedOptionData.title}</h2>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                {selectedOptionData.description}
              </p>
              
              <Button
                size="lg"
                onClick={selectedOptionData.action}
                className="h-14 px-8 text-lg font-semibold"
              >
                {selectedOptionData.actionText}
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </motion.div>
          )}
        </section>

        {/* 主要機能 */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-12">体験できる主要機能</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {quickFeatures.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-card rounded-xl p-6 border text-center"
              >
                <feature.icon className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* 最終CTA */}
        <section className="text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-primary to-accent rounded-2xl p-8 text-white"
          >
            <Rocket className="w-16 h-16 mx-auto mb-6" />
            <h2 className="text-3xl font-bold mb-4">今すぐWeb3の世界へ</h2>
            <p className="mb-6 opacity-90 max-w-2xl mx-auto">
              CheatAで、分散型インターネットの可能性を体験してください。
              あなたのデジタルライフが変わります。
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-white text-primary hover:bg-white/90 h-14 px-8"
                onClick={() => navigate('/demo')}
              >
                <Play className="mr-2 w-5 h-5" />
                無料でデモを試す
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white/30 text-white hover:bg-white/10 h-14 px-8"
                onClick={() => navigate('/download')}
              >
                <Download className="mr-2 w-5 h-5" />
                フル版をダウンロード
              </Button>
            </div>
          </motion.div>
        </section>
      </main>
    </div>
  );
}