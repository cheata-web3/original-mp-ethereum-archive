import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  Wallet,
  Send,
  ArrowDownToLine,
  ArrowUpFromLine,
  Copy,
  Eye,
  EyeOff,
  Settings,
  History,
  QrCode,
  Shield,
  Key,
  RefreshCw,
  ExternalLink,
  Plus,
  Minus,
  TrendingUp,
  TrendingDown,
  Clock,
  CheckCircle,
  AlertTriangle,
  Zap
} from "lucide-react";
import { cn } from "@/lib/utils";
import { IMAGES } from "@/assets/images";

export default function MPWalletPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'assets' | 'activity' | 'swap' | 'nft'>('assets');
  const [isConnected, setIsConnected] = useState<boolean>(true);
  const [balance, setBalance] = useState<string>('2.5847');
  const [selectedNetwork, setSelectedNetwork] = useState<string>('ethereum');

  // ウォレット情報
  const walletAddress = "0x742d35Cc6634C0532925a3b8D4C0532925a3b8D4";

  // ネットワーク設定
  const networks = [
    {
      id: 'ethereum',
      name: 'Ethereum Mainnet',
      symbol: 'ETH',
      rpcUrl: 'https://ethereum-rpc.publicnode.com',
      chainId: 1,
      blockExplorer: 'https://etherscan.io',
      icon: '⟠'
    },
    {
      id: 'polygon',
      name: 'Polygon Mainnet',
      symbol: 'MATIC',
      rpcUrl: 'https://polygon-rpc.com/',
      chainId: 137,
      blockExplorer: 'https://polygonscan.com',
      icon: '🔷'
    },
    {
      id: 'bsc',
      name: 'BNB Smart Chain',
      symbol: 'BNB',
      rpcUrl: 'https://bsc-dataseed1.binance.org/',
      chainId: 56,
      blockExplorer: 'https://bscscan.com',
      icon: '🟡'
    }
  ];

  const getCurrentNetwork = () => networks.find(n => n.id === selectedNetwork) || networks[0];

  // 資産データ
  const assets = [
    {
      symbol: 'MATIC',
      name: 'Polygon',
      balance: '3,247.85',
      value: '$2,598.28',
      price: '$0.80',
      change: '+5.2%',
      changePositive: true,
      icon: '🔷'
    },
    {
      symbol: 'MP',
      name: 'Magic Point (Polygon)',
      balance: '75,000.00',
      value: '$1,837.50',
      price: '$0.0245',
      change: '+32.1%',
      changePositive: true,
      icon: '🔷'
    },
    {
      symbol: 'USDC',
      name: 'USD Coin (Polygon)',
      balance: '1,250.00',
      value: '$1,250.00',
      price: '$1.00',
      change: '0.0%',
      changePositive: true,
      icon: '💵'
    },
    {
      symbol: 'CHEATA',
      name: 'CheatA Token',
      balance: '5,000.00',
      value: '$625.00',
      price: '$0.125',
      change: '+8.7%',
      changePositive: true,
      icon: '🧩'
    },
    {
      symbol: 'UNI',
      name: 'Uniswap',
      balance: '45.67',
      value: '$563.57',
      price: '$12.34',
      change: '+5.2%',
      changePositive: true,
      icon: '🦄'
    }
  ];

  // 現在はチェーンRPCに接続していないため、以下はUIプレビュー用のデータです。
  const isPreviewData = true;

  // 取引履歴
  const activities = [
    {
      type: 'send',
      token: 'ETH',
      amount: '-0.5',
      value: '-$1,622.84',
      to: '接続先ウォレット',
      time: '2分前',
      status: 'confirmed',
      hash: '0xabcd...1234'
    },
    {
      type: 'receive',
      token: 'MP',
      amount: '+1,000',
      value: '+$24.50',
      from: '0x9876...4321',
      time: '1時間前',
      status: 'confirmed',
      hash: '0xefgh...5678'
    },
    {
      type: 'swap',
      tokenFrom: 'USDC',
      tokenTo: 'CHEATA',
      amountFrom: '-100',
      amountTo: '+800',
      time: '3時間前',
      status: 'confirmed',
      hash: '0xijkl...9012'
    },
    {
      type: 'send',
      token: 'USDC',
      amount: '-250',
      value: '-$250.00',
      to: '0x5555...7777',
      time: '1日前',
      status: 'confirmed',
      hash: '0xmnop...3456'
    },
    {
      type: 'receive',
      token: 'ETH',
      amount: '+1.2',
      value: '+$3,894.80',
      from: '0x3333...9999',
      time: '2日前',
      status: 'confirmed',
      hash: '0xqrst...7890'
    }
  ];

  // NFTデータ
  const nfts = [
    {
      id: 1,
      name: 'Crypto Punk #1234',
      collection: 'CryptoPunks',
      image: IMAGES.BROWSER_INTERFACE_1,
      value: '15.5 ETH'
    },
    {
      id: 2,
      name: 'Bored Ape #5678',
      collection: 'BAYC',
      image: IMAGES.BROWSER_INTERFACE_2,
      value: '12.3 ETH'
    },
    {
      id: 3,
      name: 'Art Block #9012',
      collection: 'Art Blocks',
      image: IMAGES.BROWSER_INTERFACE_3,
      value: '2.8 ETH'
    }
  ];

  const totalValue = assets.reduce((sum, asset) => {
    return sum + parseFloat(asset.value.replace('$', '').replace(',', ''));
  }, 0);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // Toast notification would go here
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'send': return <ArrowUpFromLine className="w-4 h-4 text-red-500" />;
      case 'receive': return <ArrowDownToLine className="w-4 h-4 text-green-500" />;
      case 'swap': return <RefreshCw className="w-4 h-4 text-blue-500" />;
      default: return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getActivityText = (activity: any) => {
    switch (activity.type) {
      case 'send':
        return `${activity.amount} ${activity.token} を送信`;
      case 'receive':
        return `${activity.amount} ${activity.token} を受信`;
      case 'swap':
        return `${activity.amountFrom} ${activity.tokenFrom} → ${activity.amountTo} ${activity.tokenTo}`;
      default:
        return '不明な取引';
    }
  };

  const previewNotice = isPreviewData ? (
    <div className="mx-4 mb-4 rounded-xl border border-amber-500/20 bg-amber-500/10 px-4 py-3 text-sm text-amber-700 dark:text-amber-300">
      プレビュー表示：残高・取引履歴は実際のブロックチェーンから取得していません。送金・署名は実行されません。
    </div>
  ) : null;

  return (
    <div className="min-h-screen bg-background">
      {previewNotice}
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto max-w-4xl">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 flex items-center justify-center">
                <img 
                  src="/images/777.png" 
                  alt="MP Wallet Logo" 
                  className="w-10 h-10 object-contain drop-shadow-md z-10"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                    if (fallback) fallback.style.display = 'flex';
                  }}
                />
                <div 
                  className="absolute inset-0 w-auto h-10 flex items-center justify-center text-lg font-bold tracking-tight"
                  style={{ 
                    display: 'none',
                    background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text'
                  }}
                >
                  MP
                </div>
              </div>
              <div className="font-brand text-2xl font-bold tracking-tight" style={{
                background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}>
                🔷 Magic Point Polygonウォレット
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-muted-foreground max-w-2xl">
              Polygonネットワーク専用のMagic Pointウォレット。
              高速・低コストで暗号資産の管理、送受信、スワップができます。
            </p>
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => navigate('/mp-staking')}
                className="flex items-center gap-2"
              >
                <Zap className="w-4 h-4" />
                ステーキング
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => navigate('/mp-defi-dashboard')}
                className="flex items-center gap-2"
              >
                <TrendingUp className="w-4 h-4" />
                DeFi
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => navigate('/mp-analytics')}
                className="flex items-center gap-2"
              >
                <TrendingUp className="w-4 h-4" />
                統計
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto max-w-4xl px-6 py-8">
        {/* ウォレット概要 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl p-8 border border-primary/20 mb-8"
        >
          <div className="text-center mb-6">
            <div className="flex items-center justify-center gap-2 mb-2">
              <div className={cn(
                "w-3 h-3 rounded-full",
                isConnected ? "bg-green-500" : "bg-red-500"
              )} />
              <span className="text-sm text-muted-foreground">
                {isConnected ? "接続済み" : "未接続"}
              </span>
            </div>
            <div className="text-4xl font-bold mb-2">${totalValue.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">総資産価値</div>
          </div>

          {/* ウォレットアドレス */}
          <div className="bg-card rounded-xl p-4 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="text-sm text-muted-foreground mb-1">ウォレットアドレス</div>
                <div className="font-mono text-sm">{walletAddress}</div>
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => copyToClipboard(walletAddress)}
                >
                  <Copy className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="sm">
                  <QrCode className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* アクションボタン */}
          <div className="grid grid-cols-4 gap-3">
            <Button className="flex flex-col gap-2 h-auto py-4">
              <Send className="w-5 h-5" />
              <span className="text-xs">送信</span>
            </Button>
            <Button variant="outline" className="flex flex-col gap-2 h-auto py-4">
              <ArrowDownToLine className="w-5 h-5" />
              <span className="text-xs">受信</span>
            </Button>
            <Button 
              variant="outline" 
              className="flex flex-col gap-2 h-auto py-4"
              onClick={() => navigate('/mp-coin-swap')}
            >
              <RefreshCw className="w-5 h-5" />
              <span className="text-xs">スワップ</span>
            </Button>
            <Button variant="outline" className="flex flex-col gap-2 h-auto py-4">
              <Settings className="w-5 h-5" />
              <span className="text-xs">設定</span>
            </Button>
          </div>
        </motion.div>

        {/* タブナビゲーション */}
        <div className="flex gap-2 mb-8 bg-muted/50 p-1 rounded-xl w-fit">
          {[
            { id: 'assets', label: '資産', icon: Wallet },
            { id: 'activity', label: '履歴', icon: History },
            { id: 'swap', label: 'スワップ', icon: RefreshCw },
            { id: 'nft', label: 'NFT', icon: Zap }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
                activeTab === tab.id
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* タブコンテンツ */}
        <AnimatePresence mode="wait">
          {/* 資産タブ */}
          {activeTab === 'assets' && (
            <motion.div
              key="assets"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
            >
              {assets.map((asset, index) => (
                <motion.div
                  key={asset.symbol}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-card rounded-xl border p-6 hover:shadow-lg transition-all cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-2xl">
                        {asset.icon}
                      </div>
                      <div>
                        <div className="font-semibold text-lg">{asset.symbol}</div>
                        <div className="text-sm text-muted-foreground">{asset.name}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold text-lg">{asset.balance}</div>
                      <div className="text-sm text-muted-foreground">{asset.value}</div>
                      <div className={cn(
                        "text-xs font-medium",
                        asset.changePositive ? "text-green-500" : "text-red-500"
                      )}>
                        {asset.change}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}

          {/* 履歴タブ */}
          {activeTab === 'activity' && (
            <motion.div
              key="activity"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
            >
              {activities.map((activity, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-card rounded-xl border p-6 hover:shadow-lg transition-all cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                        {getActivityIcon(activity.type)}
                      </div>
                      <div>
                        <div className="font-medium">{getActivityText(activity)}</div>
                        <div className="text-sm text-muted-foreground">{activity.time}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <span className="text-sm text-green-500">確認済み</span>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {activity.hash}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}

          {/* スワップタブ */}
          {activeTab === 'swap' && (
            <motion.div
              key="swap"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-card rounded-xl border p-8"
            >
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold mb-4">クイックスワップ</h3>
                <p className="text-muted-foreground">
                  MPウォレット内で直接トークンをスワップできます
                </p>
              </div>

              <div className="max-w-md mx-auto space-y-6">
                <div className="bg-muted/50 rounded-xl p-4">
                  <div className="text-sm text-muted-foreground mb-2">From</div>
                  <div className="flex items-center gap-3">
                    <select className="bg-background border border-border rounded-lg px-3 py-2 text-sm font-medium">
                      <option>⟠ ETH</option>
                      <option>🔷 MP</option>
                      <option>💵 USDC</option>
                    </select>
                    <Input placeholder="0.0" className="text-right" />
                  </div>
                </div>

                <div className="flex justify-center">
                  <Button variant="outline" size="sm" className="rounded-full w-10 h-10 p-0">
                    <RefreshCw className="w-4 h-4" />
                  </Button>
                </div>

                <div className="bg-muted/50 rounded-xl p-4">
                  <div className="text-sm text-muted-foreground mb-2">To</div>
                  <div className="flex items-center gap-3">
                    <select className="bg-background border border-border rounded-lg px-3 py-2 text-sm font-medium">
                      <option>🔷 MP</option>
                      <option>⟠ ETH</option>
                      <option>💵 USDC</option>
                    </select>
                    <Input placeholder="0.0" className="text-right" readOnly />
                  </div>
                </div>

                <Button className="w-full h-12 text-lg font-semibold">
                  <RefreshCw className="w-5 h-5 mr-2" />
                  スワップ実行
                </Button>

                <div className="text-center">
                  <Button 
                    variant="outline"
                    onClick={() => navigate('/mp-coin-swap')}
                  >
                    詳細なスワップページへ
                  </Button>
                </div>
              </div>
            </motion.div>
          )}

          {/* NFTタブ */}
          {activeTab === 'nft' && (
            <motion.div
              key="nft"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {nfts.map((nft, index) => (
                <motion.div
                  key={nft.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-card rounded-xl border overflow-hidden hover:shadow-lg transition-all cursor-pointer"
                >
                  <div className="aspect-square">
                    <img 
                      src={nft.image} 
                      alt={nft.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold mb-1">{nft.name}</h3>
                    <p className="text-sm text-muted-foreground mb-2">{nft.collection}</p>
                    <div className="text-lg font-bold text-primary">{nft.value}</div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* セキュリティ情報 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-12 bg-card rounded-xl border p-6"
        >
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-semibold">セキュリティ情報</h3>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
              <div className="flex items-center gap-3">
                <Key className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm">秘密鍵</span>
              </div>
              <span className="text-xs text-muted-foreground">外部ウォレットで安全に管理</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span>暗号化済み</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span>ローカル保存</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span>バックアップ推奨</span>
              </div>
            </div>
          </div>
        </motion.div>
      </main>
    </div>
  );
}