import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  ArrowLeft, 
  Video, 
  Phone, 
  MessageCircle, 
  Users, 
  Send,
  Mic,
  MicOff,
  VideoOff,
  PhoneOff,
  Settings,
  Share2,
  Copy,
  Check,
  User,
  Shield,
  Globe,
  Zap
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function CommunicationPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'video' | 'voice' | 'chat'>('video');
  const [isCallActive, setIsCallActive] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [messages, setMessages] = useState([
    { id: 1, user: "Alice", message: "Web3プロジェクトについて話し合いましょう！", time: "14:30", isOwn: false },
    { id: 2, user: "You", message: "いいですね！DeFiの新しいアイデアがあります", time: "14:32", isOwn: true },
    { id: 3, user: "Bob", message: "NFTマーケットプレイスも検討してみませんか？", time: "14:35", isOwn: false },
  ]);
  const [newMessage, setNewMessage] = useState("");
  const [roomId] = useState("cheata-room-" + Math.random().toString(36).substr(2, 9));
  const [copied, setCopied] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  // デモ用のビデオストリーム開始
  useEffect(() => {
    if (activeTab === 'video' && videoRef.current) {
      // デモ用の背景色アニメーション
      const canvas = document.createElement('canvas');
      canvas.width = 640;
      canvas.height = 480;
      const ctx = canvas.getContext('2d');
      
      const animate = () => {
        if (ctx) {
          const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
          gradient.addColorStop(0, `hsl(${Date.now() / 50 % 360}, 70%, 50%)`);
          gradient.addColorStop(1, `hsl(${(Date.now() / 50 + 180) % 360}, 70%, 30%)`);
          
          ctx.fillStyle = gradient;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          
          // "DEMO" テキスト
          ctx.fillStyle = 'white';
          ctx.font = 'bold 48px Arial';
          ctx.textAlign = 'center';
          ctx.fillText('DEMO VIDEO', canvas.width / 2, canvas.height / 2);
          ctx.font = '24px Arial';
          ctx.fillText('CheatA Communication', canvas.width / 2, canvas.height / 2 + 40);
        }
        requestAnimationFrame(animate);
      };
      animate();
      
      const stream = canvas.captureStream(30);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    }
  }, [activeTab]);

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const newMsg = {
        id: messages.length + 1,
        user: "You",
        message: newMessage,
        time: new Date().toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' }),
        isOwn: true
      };
      setMessages([...messages, newMsg]);
      setNewMessage("");
    }
  };

  const copyRoomId = () => {
    navigator.clipboard.writeText(roomId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const startCall = () => {
    setIsCallActive(true);
  };

  const endCall = () => {
    setIsCallActive(false);
    setIsMuted(false);
    setIsVideoOff(false);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="font-brand text-2xl font-bold text-primary">
              📞 CheatA コミュニケーション
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            Web3ネイティブなコミュニケーションツール。暗号化された安全な通話とメッセージング
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-8">
        {/* タブナビゲーション */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex p-1 bg-muted rounded-xl">
            <button
              onClick={() => setActiveTab('video')}
              className={cn(
                "px-6 py-3 rounded-lg text-sm font-semibold transition-all flex items-center gap-2",
                activeTab === 'video' 
                  ? "bg-primary text-primary-foreground shadow-lg" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Video className="w-4 h-4" />
              ビデオ通話
            </button>
            <button
              onClick={() => setActiveTab('voice')}
              className={cn(
                "px-6 py-3 rounded-lg text-sm font-semibold transition-all flex items-center gap-2",
                activeTab === 'voice' 
                  ? "bg-primary text-primary-foreground shadow-lg" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Phone className="w-4 h-4" />
              音声通話
            </button>
            <button
              onClick={() => setActiveTab('chat')}
              className={cn(
                "px-6 py-3 rounded-lg text-sm font-semibold transition-all flex items-center gap-2",
                activeTab === 'chat' 
                  ? "bg-primary text-primary-foreground shadow-lg" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <MessageCircle className="w-4 h-4" />
              チャット
            </button>
          </div>
        </div>

        {/* ルーム情報 */}
        <div className="bg-card rounded-xl p-6 mb-8 border">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold mb-2">ルームID</h3>
              <code className="text-sm bg-muted px-3 py-1 rounded">{roomId}</code>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={copyRoomId}
              className="flex items-center gap-2"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? "コピー済み" : "コピー"}
            </Button>
          </div>
          <p className="text-sm text-muted-foreground mt-2">
            このルームIDを共有して、他のユーザーを招待できます
          </p>
        </div>

        <AnimatePresence mode="wait">
          {/* ビデオ通話タブ */}
          {activeTab === 'video' && (
            <motion.div
              key="video"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* メインビデオ */}
                <div className="bg-card rounded-xl overflow-hidden border">
                  <div className="aspect-video bg-black relative">
                    <video
                      ref={videoRef}
                      autoPlay
                      muted
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-4 left-4 bg-black/50 text-white px-3 py-1 rounded text-sm">
                      あなた
                    </div>
                    {isVideoOff && (
                      <div className="absolute inset-0 bg-gray-800 flex items-center justify-center">
                        <div className="text-center text-white">
                          <VideoOff className="w-12 h-12 mx-auto mb-2" />
                          <p>ビデオがオフです</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* 参加者ビデオ */}
                <div className="space-y-4">
                  <h3 className="font-semibold">参加者 (2名)</h3>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="bg-card rounded-xl overflow-hidden border">
                      <div className="aspect-video bg-gradient-to-br from-blue-500 to-purple-600 relative flex items-center justify-center">
                        <div className="text-center text-white">
                          <User className="w-12 h-12 mx-auto mb-2" />
                          <p className="font-semibold">Alice</p>
                        </div>
                        <div className="absolute bottom-2 left-2 bg-black/50 text-white px-2 py-1 rounded text-xs">
                          Alice
                        </div>
                      </div>
                    </div>
                    <div className="bg-card rounded-xl overflow-hidden border">
                      <div className="aspect-video bg-gradient-to-br from-green-500 to-teal-600 relative flex items-center justify-center">
                        <div className="text-center text-white">
                          <User className="w-12 h-12 mx-auto mb-2" />
                          <p className="font-semibold">Bob</p>
                        </div>
                        <div className="absolute bottom-2 left-2 bg-black/50 text-white px-2 py-1 rounded text-xs">
                          Bob
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 通話コントロール */}
              <div className="flex justify-center gap-4">
                {!isCallActive ? (
                  <Button
                    size="lg"
                    onClick={startCall}
                    className="bg-green-500 hover:bg-green-600 text-white px-8"
                  >
                    <Video className="w-5 h-5 mr-2" />
                    通話開始
                  </Button>
                ) : (
                  <>
                    <Button
                      variant={isMuted ? "destructive" : "outline"}
                      size="lg"
                      onClick={() => setIsMuted(!isMuted)}
                    >
                      {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                    </Button>
                    <Button
                      variant={isVideoOff ? "destructive" : "outline"}
                      size="lg"
                      onClick={() => setIsVideoOff(!isVideoOff)}
                    >
                      {isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
                    </Button>
                    <Button
                      variant="outline"
                      size="lg"
                    >
                      <Settings className="w-5 h-5" />
                    </Button>
                    <Button
                      variant="outline"
                      size="lg"
                    >
                      <Share2 className="w-5 h-5" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="lg"
                      onClick={endCall}
                    >
                      <PhoneOff className="w-5 h-5" />
                    </Button>
                  </>
                )}
              </div>
            </motion.div>
          )}

          {/* 音声通話タブ */}
          {activeTab === 'voice' && (
            <motion.div
              key="voice"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <div className="bg-card rounded-xl p-8 border text-center">
                <div className="max-w-md mx-auto">
                  <div className="w-32 h-32 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center mx-auto mb-6">
                    <Phone className="w-16 h-16 text-white" />
                  </div>
                  <h2 className="text-2xl font-bold mb-4">音声通話</h2>
                  <p className="text-muted-foreground mb-6">
                    高品質な音声通話で、Web3プロジェクトについて議論しましょう
                  </p>
                  
                  {/* 参加者リスト */}
                  <div className="mb-6">
                    <h3 className="font-semibold mb-3">参加者</h3>
                    <div className="flex justify-center gap-4">
                      <div className="text-center">
                        <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold mb-2">
                          A
                        </div>
                        <p className="text-sm">Alice</p>
                      </div>
                      <div className="text-center">
                        <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center text-white font-bold mb-2">
                          B
                        </div>
                        <p className="text-sm">Bob</p>
                      </div>
                      <div className="text-center">
                        <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-bold mb-2">
                          Y
                        </div>
                        <p className="text-sm">You</p>
                      </div>
                    </div>
                  </div>

                  {/* 通話コントロール */}
                  <div className="flex justify-center gap-4">
                    {!isCallActive ? (
                      <Button
                        size="lg"
                        onClick={startCall}
                        className="bg-green-500 hover:bg-green-600 text-white px-8"
                      >
                        <Phone className="w-5 h-5 mr-2" />
                        通話開始
                      </Button>
                    ) : (
                      <>
                        <Button
                          variant={isMuted ? "destructive" : "outline"}
                          size="lg"
                          onClick={() => setIsMuted(!isMuted)}
                        >
                          {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                        </Button>
                        <Button
                          variant="destructive"
                          size="lg"
                          onClick={endCall}
                        >
                          <PhoneOff className="w-5 h-5" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* チャットタブ */}
          {activeTab === 'chat' && (
            <motion.div
              key="chat"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <div className="bg-card rounded-xl border overflow-hidden">
                {/* チャットヘッダー */}
                <div className="p-4 border-b bg-muted/50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Users className="w-5 h-5 text-primary" />
                      <h3 className="font-semibold">Web3プロジェクト議論</h3>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      3名参加中
                    </div>
                  </div>
                </div>

                {/* メッセージエリア */}
                <div className="h-96 overflow-y-auto p-4 space-y-4">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={cn(
                        "flex gap-3",
                        msg.isOwn ? "justify-end" : "justify-start"
                      )}
                    >
                      {!msg.isOwn && (
                        <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                          {msg.user[0]}
                        </div>
                      )}
                      <div className={cn(
                        "max-w-xs lg:max-w-md px-4 py-2 rounded-lg",
                        msg.isOwn 
                          ? "bg-primary text-primary-foreground" 
                          : "bg-muted"
                      )}>
                        {!msg.isOwn && (
                          <p className="text-xs font-semibold mb-1 opacity-70">
                            {msg.user}
                          </p>
                        )}
                        <p className="text-sm">{msg.message}</p>
                        <p className={cn(
                          "text-xs mt-1",
                          msg.isOwn ? "opacity-70" : "text-muted-foreground"
                        )}>
                          {msg.time}
                        </p>
                      </div>
                      {msg.isOwn && (
                        <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                          Y
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* メッセージ入力 */}
                <div className="p-4 border-t">
                  <div className="flex gap-2">
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="メッセージを入力..."
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      className="flex-1"
                    />
                    <Button onClick={handleSendMessage}>
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 機能説明 */}
        <section className="mt-12">
          <h2 className="text-2xl font-bold mb-6 text-center">🔒 Web3セキュリティ機能</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-card rounded-xl p-6 border text-center">
              <Shield className="w-12 h-12 text-green-500 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">エンドツーエンド暗号化</h3>
              <p className="text-sm text-muted-foreground">
                すべての通話とメッセージは暗号化され、完全にプライベートです
              </p>
            </div>
            <div className="bg-card rounded-xl p-6 border text-center">
              <Globe className="w-12 h-12 text-blue-500 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">分散型インフラ</h3>
              <p className="text-sm text-muted-foreground">
                中央サーバーに依存しない、真の分散型コミュニケーション
              </p>
            </div>
            <div className="bg-card rounded-xl p-6 border text-center">
              <Zap className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">高速・低遅延</h3>
              <p className="text-sm text-muted-foreground">
                最新のWebRTC技術により、遅延のないリアルタイム通信を実現
              </p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}