import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  ArrowUpDown,
  Wallet,
  TrendingUp,
  Clock,
  Shield,
  Zap,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  Info,
  ExternalLink,
  Copy,
  Settings
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function MPCoinSwapPage() {
  const navigate = useNavigate();
  const [fromAmount, setFromAmount] = useState<string>('');
  const [toAmount, setToAmount] = useState<string>('');
  const [fromToken, setFromToken] = useState<string>('MATIC');
  const [toToken, setToToken] = useState<string>('MP');
  const [isSwapping, setIsSwapping] = useState<boolean>(false);
  const [swapComplete, setSwapComplete] = useState<boolean>(false);
  const [slippage, setSlippage] = useState<number>(0.5);

  const tokens = [
    { symbol: 'MATIC', name: 'Polygon', balance: '3,247.85', price: '$0.80', icon: '🔷' },
    { symbol: 'MP', name: 'Magic Point (Polygon)', balance: '75,000.00', price: '$0.0245', icon: '🔷' },
    { symbol: 'USDC', name: 'USD Coin (Polygon)', balance: '1,250.00', price: '$1.00', icon: '💵' },
    { symbol: 'WETH', name: 'Wrapped ETH (Polygon)', balance: '2.5847', price: '$3,245.67', icon: '⟠' },
    { symbol: 'CHEATA', name: 'CheatA Token (Polygon)', balance: '5,000.00', price: '$0.125', icon: '🧩' }
  ];

  const getTokenInfo = (symbol: string) => tokens.find(t => t.symbol === symbol) || tokens[0];

  const handleSwap = async () => {
    setIsSwapping(true);
    // シミュレートされたスワップ処理
    await new Promise(resolve => setTimeout(resolve, 3000));
    setIsSwapping(false);
    setSwapComplete(true);
    setTimeout(() => setSwapComplete(false), 5000);
  };

  const handleAmountChange = (value: string, isFrom: boolean) => {
    if (isFrom) {
      setFromAmount(value);
      // 簡単な変換レート計算（実際にはAPIから取得）
      const rate = fromToken === 'MATIC' && toToken === 'MP' ? 32.65 : 1;
      setToAmount((parseFloat(value || '0') * rate).toFixed(6));
    } else {
      setToAmount(value);
      const rate = fromToken === 'MATIC' && toToken === 'MP' ? 32.65 : 1;
      setFromAmount((parseFloat(value || '0') / rate).toFixed(6));
    }
  };

  const swapTokens = () => {
    const tempToken = fromToken;
    const tempAmount = fromAmount;
    setFromToken(toToken);
    setToToken(tempToken);
    setFromAmount(toAmount);
    setToAmount(tempAmount);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 flex items-center justify-center">
                <img 
                  src="/images/777.png" 
                  alt="CheatA Logo" 
                  className="w-10 h-10 object-contain drop-shadow-md z-10"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                    if (fallback) fallback.style.display = 'flex';
                  }}
                />
                <div 
                  className="absolute inset-0 w-auto h-10 flex items-center justify-center text-lg font-bold tracking-tight"
                  style={{ 
                    display: 'none',
                    background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text'
                  }}
                >
                  CheatA
                </div>
              </div>
              <div className="font-brand text-2xl font-bold tracking-tight" style={{
                background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}>
                🔷 Magic Point on Polygon
              </div>
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            PolygonネットワークでMagic Point（MP）コインを高速・低コストでスワップ。
            ガス代$0.01未満で瞬時交換を実現します。
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-12">
        <div className="max-w-2xl mx-auto">
          {/* スワップカード */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-card rounded-2xl border p-6 shadow-lg"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">トークンスワップ</h2>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
            </div>

            {/* From Token */}
            <div className="space-y-4">
              <div className="bg-muted/50 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">From</span>
                  <span className="text-sm text-muted-foreground">
                    残高: {getTokenInfo(fromToken).balance}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <select 
                    value={fromToken}
                    onChange={(e) => setFromToken(e.target.value)}
                    className="bg-background border border-border rounded-lg px-3 py-2 text-sm font-medium min-w-[120px]"
                  >
                    {tokens.map(token => (
                      <option key={token.symbol} value={token.symbol}>
                        {token.icon} {token.symbol}
                      </option>
                    ))}
                  </select>
                  <Input
                    type="number"
                    placeholder="0.0"
                    value={fromAmount}
                    onChange={(e) => handleAmountChange(e.target.value, true)}
                    className="text-right text-lg font-semibold border-0 bg-transparent p-0 h-auto"
                  />
                </div>
                <div className="text-right text-sm text-muted-foreground mt-1">
                  ≈ ${(parseFloat(fromAmount || '0') * parseFloat(getTokenInfo(fromToken).price.replace('$', '').replace(',', ''))).toLocaleString()}
                </div>
              </div>

              {/* スワップボタン */}
              <div className="flex justify-center">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={swapTokens}
                  className="rounded-full w-10 h-10 p-0"
                >
                  <ArrowUpDown className="w-4 h-4" />
                </Button>
              </div>

              {/* To Token */}
              <div className="bg-muted/50 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">To</span>
                  <span className="text-sm text-muted-foreground">
                    残高: {getTokenInfo(toToken).balance}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <select 
                    value={toToken}
                    onChange={(e) => setToToken(e.target.value)}
                    className="bg-background border border-border rounded-lg px-3 py-2 text-sm font-medium min-w-[120px]"
                  >
                    {tokens.map(token => (
                      <option key={token.symbol} value={token.symbol}>
                        {token.icon} {token.symbol}
                      </option>
                    ))}
                  </select>
                  <Input
                    type="number"
                    placeholder="0.0"
                    value={toAmount}
                    onChange={(e) => handleAmountChange(e.target.value, false)}
                    className="text-right text-lg font-semibold border-0 bg-transparent p-0 h-auto"
                    readOnly
                  />
                </div>
                <div className="text-right text-sm text-muted-foreground mt-1">
                  ≈ ${(parseFloat(toAmount || '0') * parseFloat(getTokenInfo(toToken).price.replace('$', '').replace(',', ''))).toLocaleString()}
                </div>
              </div>
            </div>

            {/* スワップ詳細 */}
            <div className="mt-6 space-y-3 p-4 bg-muted/30 rounded-xl">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">レート</span>
                <span>1 {fromToken} = {fromToken === 'ETH' && toToken === 'MP' ? '132,450' : '1'} {toToken}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">スリッページ許容度</span>
                <span>{slippage}%</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">ネットワーク手数料</span>
                <span>~$2.45</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">最小受取量</span>
                <span>{(parseFloat(toAmount || '0') * (1 - slippage / 100)).toFixed(6)} {toToken}</span>
              </div>
            </div>

            {/* スワップボタン */}
            <Button 
              className="w-full mt-6 h-12 text-lg font-semibold"
              onClick={handleSwap}
              disabled={!fromAmount || parseFloat(fromAmount) <= 0 || isSwapping}
            >
              {isSwapping ? (
                <>
                  <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                  スワップ中...
                </>
              ) : (
                <>
                  <ArrowUpDown className="w-5 h-5 mr-2" />
                  スワップ実行
                </>
              )}
            </Button>

            {/* 成功メッセージ */}
            <AnimatePresence>
              {swapComplete && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="mt-4 p-4 bg-green-500/10 border border-green-500/20 rounded-xl flex items-center gap-3"
                >
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <div>
                    <p className="font-semibold text-green-700">スワップ完了！</p>
                    <p className="text-sm text-green-600">
                      {fromAmount} {fromToken} → {toAmount} {toToken}
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>

          {/* MPコイン情報 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-8 bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl p-6 border border-primary/20"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="text-3xl">🔷</div>
              <div>
                <h3 className="text-xl font-bold">MPコイン（MetaPoint Coin）</h3>
                <p className="text-sm text-muted-foreground">CheatAエコシステムの中核トークン</p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">$0.0245</div>
                <div className="text-sm text-muted-foreground">現在価格</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-500">+12.5%</div>
                <div className="text-sm text-muted-foreground">24h変動</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">$2.4M</div>
                <div className="text-sm text-muted-foreground">時価総額</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">$145K</div>
                <div className="text-sm text-muted-foreground">24h出来高</div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <Shield className="w-4 h-4 text-primary" />
                <span>セキュリティ監査済み</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Zap className="w-4 h-4 text-primary" />
                <span>高速トランザクション（平均2秒）</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <TrendingUp className="w-4 h-4 text-primary" />
                <span>ステーキング報酬最大15% APY</span>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <Button variant="outline" size="sm">
                <ExternalLink className="w-4 h-4 mr-2" />
                詳細情報
              </Button>
              <Button variant="outline" size="sm">
                <Copy className="w-4 h-4 mr-2" />
                コントラクトアドレス
              </Button>
            </div>
          </motion.div>

          {/* 最近のスワップ履歴 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mt-8 bg-card rounded-2xl border p-6"
          >
            <h3 className="text-xl font-bold mb-4">最近のスワップ履歴</h3>
            <div className="space-y-3">
              {[
                { from: 'ETH', to: 'MP', fromAmount: '0.5', toAmount: '66,225', time: '2分前', status: '完了' },
                { from: 'USDC', to: 'MP', fromAmount: '100', toAmount: '4,081', time: '1時間前', status: '完了' },
                { from: 'MP', to: 'CHEATA', fromAmount: '10,000', toAmount: '1,960', time: '3時間前', status: '完了' }
              ].map((swap, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      <span>{getTokenInfo(swap.from).icon}</span>
                      <ArrowUpDown className="w-3 h-3 text-muted-foreground" />
                      <span>{getTokenInfo(swap.to).icon}</span>
                    </div>
                    <div>
                      <div className="font-medium text-sm">
                        {swap.fromAmount} {swap.from} → {swap.toAmount} {swap.to}
                      </div>
                      <div className="text-xs text-muted-foreground">{swap.time}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-green-600">{swap.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}