import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft, 
  Copy, 
  Send, 
  Download, 
  Eye, 
  EyeOff, 
  ExternalLink,
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  RefreshCw,
  Settings,
  ChevronDown,
  Check,
  AlertTriangle
} from "lucide-react";

// MetaMask型定義
declare global {
  interface Window {
    ethereum?: {
      request: (args: { method: string; params?: any[] }) => Promise<any>;
    };
  }
}

// 資産の型定義
interface Asset {
  symbol: string;
  name: string;
  balance: string;
  value: string;
  price: string;
  change: string;
  changePositive: boolean;
  icon: string;
  isOriginal?: boolean;
  bridged?: boolean;
}

export default function PolygonWalletPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'assets' | 'nfts' | 'history' | 'security'>('assets');
  const [selectedNetwork, setSelectedNetwork] = useState('polygon');
  const [showNetworkDropdown, setShowNetworkDropdown] = useState(false);

  // ネットワーク設定
  const networks = [
    {
      id: 'ethereum',
      name: 'Ethereum Mainnet',
      symbol: 'ETH',
      rpcUrl: 'https://ethereum-rpc.publicnode.com',
      chainId: 1,
      blockExplorer: 'https://etherscan.io',
      icon: '⟠',
      color: 'text-blue-500'
    },
    {
      id: 'polygon',
      name: 'Polygon Mainnet',
      symbol: 'MATIC',
      rpcUrl: 'https://polygon-rpc.com/',
      chainId: 137,
      blockExplorer: 'https://polygonscan.com',
      icon: '🔷',
      color: 'text-purple-500'
    },
    {
      id: 'bsc',
      name: 'BNB Smart Chain',
      symbol: 'BNB',
      rpcUrl: 'https://bsc-dataseed1.binance.org/',
      chainId: 56,
      blockExplorer: 'https://bscscan.com',
      icon: '🟡',
      color: 'text-yellow-500'
    }
  ];

  const getCurrentNetwork = () => networks.find(n => n.id === selectedNetwork) || networks[1];

  // 2018年コインのデータ（ネットワーク別）
  const getAssetsForNetwork = (networkId: string): Asset[] => {
    const baseAssets: Record<string, Asset[]> = {
      ethereum: [
        {
          symbol: 'ETH',
          name: 'Ethereum',
          balance: '2.5847',
          value: '$8,392.45',
          price: '$3,245.67',
          change: '+2.4%',
          changePositive: true,
          icon: '⟠'
        },
        {
          symbol: 'MP2018',
          name: 'Magic Point 2018 (Original)',
          balance: '50,000.00',
          value: '$1,225.00',
          price: '$0.0245',
          change: '+25.8%',
          changePositive: true,
          icon: '💎',
          isOriginal: true
        }
      ],
      polygon: [
        {
          symbol: 'MATIC',
          name: 'Polygon',
          balance: '3,247.85',
          value: '$2,598.28',
          price: '$0.80',
          change: '+5.2%',
          changePositive: true,
          icon: '🔷'
        },
        {
          symbol: 'MP2018',
          name: 'Magic Point 2018 (Polygon)',
          balance: '75,000.00',
          value: '$1,837.50',
          price: '$0.0245',
          change: '+32.1%',
          changePositive: true,
          icon: '💎',
          isOriginal: true,
          bridged: true
        }
      ],
      bsc: [
        {
          symbol: 'BNB',
          name: 'BNB',
          balance: '12.4521',
          value: '$3,735.63',
          price: '$300.00',
          change: '+3.9%',
          changePositive: true,
          icon: '🟡'
        }
      ]
    };
    return baseAssets[networkId] || baseAssets.polygon;
  };

  const assets = getAssetsForNetwork(selectedNetwork);
  const totalValue = assets.reduce((sum, asset) => sum + parseFloat(asset.value.replace('$', '').replace(',', '')), 0);

  const walletAddress = "0x742d35Cc6634C0532925a3b8D4C0532925a3b8D4";

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const addNetworkToMetaMask = async () => {
    const network = getCurrentNetwork();
    if (window.ethereum) {
      try {
        await window.ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [{
            chainId: `0x${network.chainId.toString(16)}`,
            chainName: network.name,
            nativeCurrency: {
              name: network.symbol,
              symbol: network.symbol,
              decimals: 18
            },
            rpcUrls: [network.rpcUrl],
            blockExplorerUrls: [network.blockExplorer]
          }]
        });
      } catch (error) {
        console.error('Failed to add network:', error);
      }
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => navigate("/")}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                ホームに戻る
              </Button>
              <div className="flex items-center gap-3">
                <Wallet className="w-8 h-8 text-primary" />
                <div>
                  <div className="font-brand text-2xl font-bold text-primary">
                    Polygon MPウォレット
                  </div>
                  <div className="text-sm text-muted-foreground">
                    2018年コイン対応マルチチェーンウォレット
                  </div>
                </div>
              </div>
            </div>

            {/* ネットワーク選択 */}
            <div className="relative">
              <Button
                variant="outline"
                onClick={() => setShowNetworkDropdown(!showNetworkDropdown)}
                className="flex items-center gap-2"
              >
                <span className="text-lg">{getCurrentNetwork().icon}</span>
                <span>{getCurrentNetwork().name}</span>
                <ChevronDown className="w-4 h-4" />
              </Button>

              {showNetworkDropdown && (
                <div className="absolute right-0 top-full mt-2 w-64 bg-card border border-border rounded-xl shadow-lg z-50">
                  {networks.map((network) => (
                    <button
                      key={network.id}
                      onClick={() => {
                        setSelectedNetwork(network.id);
                        setShowNetworkDropdown(false);
                      }}
                      className="w-full flex items-center gap-3 p-3 hover:bg-muted transition-colors first:rounded-t-xl last:rounded-b-xl"
                    >
                      <span className="text-lg">{network.icon}</span>
                      <div className="flex-1 text-left">
                        <div className="font-medium">{network.name}</div>
                        <div className="text-xs text-muted-foreground">Chain ID: {network.chainId}</div>
                      </div>
                      {selectedNetwork === network.id && (
                        <Check className="w-4 h-4 text-primary" />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* 総資産 */}
          <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-6 border border-primary/20">
            <div className="text-center">
              <div className="text-sm text-muted-foreground mb-2">総資産価値</div>
              <div className="text-4xl font-bold mb-2">${totalValue.toLocaleString()}</div>
              <div className="text-sm text-green-500">+12.4% (24h)</div>
            </div>
          </div>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-8">
        {/* タブナビゲーション */}
        <div className="flex gap-1 mb-8 bg-muted p-1 rounded-xl">
          {[
            { id: 'assets', label: '資産', icon: '💰' },
            { id: 'security', label: 'セキュリティ', icon: '🔐' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-lg transition-all ${
                activeTab === tab.id
                  ? 'bg-background text-primary shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <span>{tab.icon}</span>
              <span className="font-medium">{tab.label}</span>
            </button>
          ))}
        </div>

        {/* 資産タブ */}
        {activeTab === 'assets' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* クイックアクション */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Button className="flex flex-col gap-2 h-20">
                <Send className="w-5 h-5" />
                <span>送金</span>
              </Button>
              <Button variant="outline" className="flex flex-col gap-2 h-20">
                <Download className="w-5 h-5" />
                <span>受取</span>
              </Button>
              <Button 
                variant="outline" 
                className="flex flex-col gap-2 h-20"
                onClick={() => navigate('/mp-coin-swap')}
              >
                <RefreshCw className="w-5 h-5" />
                <span>スワップ</span>
              </Button>
              <Button 
                variant="outline" 
                className="flex flex-col gap-2 h-20"
                onClick={addNetworkToMetaMask}
              >
                <Settings className="w-5 h-5" />
                <span>MetaMaskに追加</span>
              </Button>
            </div>

            {/* 資産リスト */}
            <div className="space-y-3">
              {assets.map((asset, index) => (
                <motion.div
                  key={`${asset.symbol}-${index}`}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`bg-card rounded-xl p-4 border hover:shadow-lg transition-all ${
                    asset.isOriginal ? 'border-primary/30 bg-primary/5' : ''
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="text-2xl">{asset.icon}</div>
                      <div>
                        <div className="flex items-center gap-2">
                          <div className="font-semibold">{asset.symbol}</div>
                          {asset.isOriginal && (
                            <span className="px-2 py-1 bg-primary/20 text-primary text-xs rounded-full">
                              2018年オリジナル
                            </span>
                          )}
                          {asset.bridged && (
                            <span className="px-2 py-1 bg-accent/20 text-accent text-xs rounded-full">
                              ブリッジ済み
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground">{asset.name}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">{asset.balance}</div>
                      <div className="text-sm text-muted-foreground">{asset.value}</div>
                      <div className={`text-xs ${asset.changePositive ? 'text-green-500' : 'text-red-500'}`}>
                        {asset.change}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* セキュリティタブ */}
        {activeTab === 'security' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* ウォレットアドレス */}
            <div className="bg-card rounded-xl p-6 border">
              <h3 className="font-semibold mb-4">ウォレットアドレス</h3>
              <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                <code className="flex-1 text-sm font-mono">{walletAddress}</code>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => copyToClipboard(walletAddress)}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="bg-card rounded-xl p-6 border border-border">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-5 h-5 text-orange-500" />
                <h3 className="font-semibold">秘密鍵の管理</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Cheataは秘密鍵を保存・表示しません。署名は接続したウォレットに委任します。
              </p>
            </div>
          </motion.div>
        )}
      </main>
    </div>
  );
}