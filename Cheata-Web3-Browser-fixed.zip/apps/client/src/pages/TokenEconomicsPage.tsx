import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  Coins,
  TrendingUp,
  Users,
  Shield,
  Zap,
  Globe,
  PieChart,
  BarChart3,
  LineChart,
  DollarSign,
  Wallet,
  Lock,
  Gift,
  Target,
  Calendar,
  CheckCircle,
  Star,
  ArrowRight,
  Download,
  ExternalLink
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function TokenEconomicsPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'overview' | 'distribution' | 'roadmap' | 'staking'>('overview');
  const [stakingAmount, setStakingAmount] = useState("");
  const [stakingPeriod, setStakingPeriod] = useState<'30' | '90' | '180' | '365'>('90');

  const tokenStats = [
    {
      label: "総供給量",
      value: "1,000,000,000",
      unit: "CHEATA",
      change: "固定供給",
      icon: Coins,
      color: "text-blue-500"
    },
    {
      label: "現在価格",
      value: "$0.0245",
      unit: "USD",
      change: "+12.5%",
      icon: TrendingUp,
      color: "text-green-500"
    },
    {
      label: "時価総額",
      value: "$24.5M",
      unit: "USD",
      change: "+8.3%",
      icon: BarChart3,
      color: "text-purple-500"
    },
    {
      label: "ホルダー数",
      value: "125,000",
      unit: "アドレス",
      change: "+15.2%",
      icon: Users,
      color: "text-orange-500"
    }
  ];

  const distribution = [
    {
      category: "コミュニティ報酬",
      percentage: 40,
      amount: "400,000,000",
      description: "ユーザー活動、ガバナンス参加、エコシステム貢献への報酬",
      color: "bg-blue-500",
      unlockSchedule: "4年間で段階的解放"
    },
    {
      category: "エコシステム基金",
      percentage: 25,
      amount: "250,000,000",
      description: "パートナーシップ、統合、エコシステム開発資金",
      color: "bg-green-500",
      unlockSchedule: "5年間で段階的解放"
    },
    {
      category: "開発チーム",
      percentage: 20,
      amount: "200,000,000",
      description: "開発チームへの報酬、1年間のロック期間",
      color: "bg-purple-500",
      unlockSchedule: "1年ロック後、3年間で解放"
    },
    {
      category: "パートナー・アドバイザー",
      percentage: 15,
      amount: "150,000,000",
      description: "戦略的パートナーとアドバイザーへの配分",
      color: "bg-orange-500",
      unlockSchedule: "6ヶ月ロック後、2年間で解放"
    }
  ];

  const roadmapPhases = [
    {
      phase: "フェーズ 1",
      title: "トークン発行・配布",
      status: "完了",
      date: "2026年Q1",
      items: [
        "CHEATAトークンの発行",
        "初期コミュニティ配布",
        "DEXでの流動性提供開始",
        "基本的なステーキング機能"
      ],
      icon: CheckCircle,
      color: "text-green-500"
    },
    {
      phase: "フェーズ 2",
      title: "ガバナンス・ユーティリティ",
      status: "進行中",
      date: "2026年Q2",
      items: [
        "DAOガバナンス機能実装",
        "プレミアム機能のトークン決済",
        "ステーキング報酬の最適化",
        "コミュニティ提案システム"
      ],
      icon: Zap,
      color: "text-blue-500"
    },
    {
      phase: "フェーズ 3",
      title: "DeFi統合・拡張",
      status: "予定",
      date: "2026年Q3",
      items: [
        "流動性マイニングプログラム",
        "イールドファーミング機能",
        "クロスチェーン対応",
        "NFTマーケットプレイス統合"
      ],
      icon: Globe,
      color: "text-purple-500"
    },
    {
      phase: "フェーズ 4",
      title: "エコシステム完成",
      status: "予定",
      date: "2026年Q4",
      items: [
        "完全分散化移行",
        "レイヤー2ソリューション",
        "企業向けソリューション",
        "グローバル展開完了"
      ],
      icon: Target,
      color: "text-orange-500"
    }
  ];

  const stakingRewards = {
    '30': { apy: 5.2, multiplier: 1.0 },
    '90': { apy: 8.5, multiplier: 1.2 },
    '180': { apy: 12.8, multiplier: 1.5 },
    '365': { apy: 18.5, multiplier: 2.0 }
  };

  const calculateStakingRewards = () => {
    const amount = parseFloat(stakingAmount) || 0;
    const { apy, multiplier } = stakingRewards[stakingPeriod];
    const dailyReward = (amount * apy / 100) / 365;
    const totalReward = dailyReward * parseInt(stakingPeriod);
    return {
      dailyReward: dailyReward.toFixed(4),
      totalReward: totalReward.toFixed(2),
      apy,
      multiplier
    };
  };

  const rewards = calculateStakingRewards();

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="font-brand text-2xl font-bold text-primary">
              💰 CHEATAトークンエコノミクス
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            持続可能なトークン経済システムで、ユーザーとプラットフォームが共に成長するエコシステム
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-12">
        {/* タブナビゲーション */}
        <div className="flex justify-center mb-12">
          <div className="inline-flex p-1 bg-muted rounded-xl">
            <button
              onClick={() => setActiveTab('overview')}
              className={cn(
                "px-6 py-3 rounded-lg text-sm font-semibold transition-all flex items-center gap-2",
                activeTab === 'overview' 
                  ? "bg-primary text-primary-foreground shadow-lg" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <PieChart className="w-4 h-4" />
              概要
            </button>
            <button
              onClick={() => setActiveTab('distribution')}
              className={cn(
                "px-6 py-3 rounded-lg text-sm font-semibold transition-all flex items-center gap-2",
                activeTab === 'distribution' 
                  ? "bg-primary text-primary-foreground shadow-lg" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <BarChart3 className="w-4 h-4" />
              配分
            </button>
            <button
              onClick={() => setActiveTab('roadmap')}
              className={cn(
                "px-6 py-3 rounded-lg text-sm font-semibold transition-all flex items-center gap-2",
                activeTab === 'roadmap' 
                  ? "bg-primary text-primary-foreground shadow-lg" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Calendar className="w-4 h-4" />
              ロードマップ
            </button>
            <button
              onClick={() => setActiveTab('staking')}
              className={cn(
                "px-6 py-3 rounded-lg text-sm font-semibold transition-all flex items-center gap-2",
                activeTab === 'staking' 
                  ? "bg-primary text-primary-foreground shadow-lg" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Gift className="w-4 h-4" />
              ステーキング
            </button>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {/* 概要タブ */}
          {activeTab === 'overview' && (
            <motion.div
              key="overview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              {/* トークン統計 */}
              <section>
                <h2 className="text-2xl font-bold mb-6">リアルタイム統計</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {tokenStats.map((stat, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-card rounded-xl p-6 border"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <stat.icon className={cn("w-8 h-8", stat.color)} />
                        <span className={cn("text-sm font-semibold", 
                          stat.change.startsWith('+') ? 'text-green-500' : 
                          stat.change.startsWith('-') ? 'text-red-500' : 'text-muted-foreground'
                        )}>
                          {stat.change}
                        </span>
                      </div>
                      <div className="text-2xl font-bold mb-1">{stat.value}</div>
                      <div className="text-sm text-muted-foreground">{stat.label}</div>
                      <div className="text-xs text-muted-foreground mt-1">{stat.unit}</div>
                    </motion.div>
                  ))}
                </div>
              </section>

              {/* トークンユーティリティ */}
              <section>
                <h2 className="text-2xl font-bold mb-6">トークンユーティリティ</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-card rounded-xl p-6 border">
                    <Shield className="w-12 h-12 text-blue-500 mb-4" />
                    <h3 className="font-semibold mb-2">ガバナンス</h3>
                    <p className="text-sm text-muted-foreground">
                      プロトコルの重要な決定に参加し、エコシステムの方向性を決定
                    </p>
                  </div>
                  <div className="bg-card rounded-xl p-6 border">
                    <Zap className="w-12 h-12 text-yellow-500 mb-4" />
                    <h3 className="font-semibold mb-2">プレミアム機能</h3>
                    <p className="text-sm text-muted-foreground">
                      高度なDeFi機能、AI分析、優先サポートへのアクセス
                    </p>
                  </div>
                  <div className="bg-card rounded-xl p-6 border">
                    <Gift className="w-12 h-12 text-green-500 mb-4" />
                    <h3 className="font-semibold mb-2">ステーキング報酬</h3>
                    <p className="text-sm text-muted-foreground">
                      トークンをステーキングして継続的な報酬を獲得
                    </p>
                  </div>
                </div>
              </section>
            </motion.div>
          )}

          {/* 配分タブ */}
          {activeTab === 'distribution' && (
            <motion.div
              key="distribution"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <section>
                <h2 className="text-2xl font-bold mb-6">トークン配分詳細</h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* 円グラフ表現 */}
                  <div className="bg-card rounded-xl p-8 border">
                    <h3 className="font-semibold mb-6 text-center">配分比率</h3>
                    <div className="relative w-64 h-64 mx-auto mb-6">
                      <div className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-500 via-green-500 via-purple-500 to-orange-500 opacity-20"></div>
                      <div className="absolute inset-8 rounded-full bg-card flex items-center justify-center">
                        <div className="text-center">
                          <div className="text-3xl font-bold">CHEATA</div>
                          <div className="text-sm text-muted-foreground">Token</div>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-3">
                      {distribution.map((item, index) => (
                        <div key={index} className="flex items-center gap-3">
                          <div className={cn("w-4 h-4 rounded-full", item.color)}></div>
                          <span className="text-sm font-medium">{item.category}</span>
                          <span className="text-sm text-muted-foreground ml-auto">{item.percentage}%</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 詳細情報 */}
                  <div className="space-y-4">
                    {distribution.map((item, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="bg-card rounded-xl p-6 border"
                      >
                        <div className="flex items-start gap-4">
                          <div className={cn("w-3 h-3 rounded-full mt-2", item.color)}></div>
                          <div className="flex-1">
                            <h4 className="font-semibold mb-2">{item.category}</h4>
                            <p className="text-sm text-muted-foreground mb-3">{item.description}</p>
                            <div className="flex justify-between items-center text-sm">
                              <span className="font-medium">{item.amount} CHEATA</span>
                              <span className="text-muted-foreground">{item.unlockSchedule}</span>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </section>
            </motion.div>
          )}

          {/* ロードマップタブ */}
          {activeTab === 'roadmap' && (
            <motion.div
              key="roadmap"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <section>
                <h2 className="text-2xl font-bold mb-6">開発ロードマップ</h2>
                <div className="space-y-6">
                  {roadmapPhases.map((phase, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-card rounded-xl p-6 border"
                    >
                      <div className="flex items-start gap-6">
                        <div className={cn(
                          "w-12 h-12 rounded-xl flex items-center justify-center",
                          phase.status === '完了' ? 'bg-green-100' :
                          phase.status === '進行中' ? 'bg-blue-100' : 'bg-gray-100'
                        )}>
                          <phase.icon className={cn("w-6 h-6", phase.color)} />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-4 mb-3">
                            <h3 className="text-xl font-bold">{phase.phase}: {phase.title}</h3>
                            <span className={cn(
                              "px-3 py-1 rounded-full text-xs font-semibold",
                              phase.status === '完了' ? 'bg-green-100 text-green-800' :
                              phase.status === '進行中' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
                            )}>
                              {phase.status}
                            </span>
                            <span className="text-sm text-muted-foreground">{phase.date}</span>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {phase.items.map((item, idx) => (
                              <div key={idx} className="flex items-center gap-2 text-sm">
                                <CheckCircle className={cn(
                                  "w-4 h-4",
                                  phase.status === '完了' ? 'text-green-500' :
                                  phase.status === '進行中' ? 'text-blue-500' : 'text-gray-400'
                                )} />
                                <span>{item}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </section>
            </motion.div>
          )}

          {/* ステーキングタブ */}
          {activeTab === 'staking' && (
            <motion.div
              key="staking"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <section>
                <h2 className="text-2xl font-bold mb-6">ステーキング計算機</h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* 計算機 */}
                  <div className="bg-card rounded-xl p-6 border">
                    <h3 className="font-semibold mb-6">報酬シミュレーション</h3>
                    <div className="space-y-6">
                      <div>
                        <label className="block text-sm font-medium mb-2">ステーキング量</label>
                        <Input
                          type="number"
                          placeholder="1000"
                          value={stakingAmount}
                          onChange={(e) => setStakingAmount(e.target.value)}
                          className="text-lg"
                        />
                        <p className="text-xs text-muted-foreground mt-1">CHEATA トークン</p>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-2">ステーキング期間</label>
                        <div className="grid grid-cols-2 gap-2">
                          {Object.entries(stakingRewards).map(([period, data]) => (
                            <button
                              key={period}
                              onClick={() => setStakingPeriod(period as any)}
                              className={cn(
                                "p-3 rounded-lg border text-sm font-medium transition-all",
                                stakingPeriod === period
                                  ? "border-primary bg-primary/5 text-primary"
                                  : "border-border hover:border-primary/50"
                              )}
                            >
                              <div>{period}日</div>
                              <div className="text-xs text-muted-foreground">APY {data.apy}%</div>
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="bg-muted/50 rounded-lg p-4 space-y-3">
                        <div className="flex justify-between">
                          <span className="text-sm">日次報酬:</span>
                          <span className="font-semibold">{rewards.dailyReward} CHEATA</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">総報酬:</span>
                          <span className="font-semibold">{rewards.totalReward} CHEATA</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">APY:</span>
                          <span className="font-semibold text-green-500">{rewards.apy}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">報酬倍率:</span>
                          <span className="font-semibold text-blue-500">{rewards.multiplier}x</span>
                        </div>
                      </div>

                      <Button className="w-full" onClick={() => navigate('/demo')}>
                        <Wallet className="w-4 h-4 mr-2" />
                        ステーキングを開始
                      </Button>
                    </div>
                  </div>

                  {/* ステーキング情報 */}
                  <div className="space-y-6">
                    <div className="bg-card rounded-xl p-6 border">
                      <h3 className="font-semibold mb-4">ステーキングの特徴</h3>
                      <div className="space-y-4">
                        <div className="flex items-start gap-3">
                          <Lock className="w-5 h-5 text-blue-500 mt-0.5" />
                          <div>
                            <h4 className="font-medium">安全なロック</h4>
                            <p className="text-sm text-muted-foreground">スマートコントラクトによる安全なトークンロック</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-3">
                          <TrendingUp className="w-5 h-5 text-green-500 mt-0.5" />
                          <div>
                            <h4 className="font-medium">複利効果</h4>
                            <p className="text-sm text-muted-foreground">報酬の自動再投資で複利効果を最大化</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-3">
                          <Shield className="w-5 h-5 text-purple-500 mt-0.5" />
                          <div>
                            <h4 className="font-medium">ガバナンス権</h4>
                            <p className="text-sm text-muted-foreground">ステーキング中もガバナンス投票に参加可能</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-xl p-6 border border-primary/20">
                      <h3 className="font-semibold mb-4">早期ステーキング特典</h3>
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center gap-2">
                          <Star className="w-4 h-4 text-yellow-500" />
                          <span className="text-sm">初回ステーキング: +20% ボーナス</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Star className="w-4 h-4 text-yellow-500" />
                          <span className="text-sm">長期ステーキング: 最大2倍報酬</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Star className="w-4 h-4 text-yellow-500" />
                          <span className="text-sm">NFT報酬: 限定NFTを獲得</span>
                        </div>
                      </div>
                      <Button variant="outline" className="w-full">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        詳細を確認
                      </Button>
                    </div>
                  </div>
                </div>
              </section>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 最終CTA */}
        <section className="mt-16 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-primary to-accent rounded-2xl p-8 text-white"
          >
            <Coins className="w-16 h-16 mx-auto mb-6" />
            <h2 className="text-3xl font-bold mb-4">CHEATAエコシステムに参加</h2>
            <p className="mb-6 opacity-90 max-w-2xl mx-auto">
              持続可能なトークン経済で、Web3の未来を一緒に構築しましょう
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-white text-primary hover:bg-white/90 h-14 px-8"
                onClick={() => navigate('/demo')}
              >
                <Wallet className="mr-2 w-5 h-5" />
                トークンを獲得
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white/30 text-white hover:bg-white/10 h-14 px-8"
                onClick={() => navigate('/demo')}
              >
                <Users className="mr-2 w-5 h-5" />
                ガバナンスに参加
              </Button>
            </div>
          </motion.div>
        </section>
      </main>
    </div>
  );
}