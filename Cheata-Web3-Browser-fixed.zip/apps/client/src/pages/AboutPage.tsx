import React from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft, 
  Building2,
  Users,
  Globe,
  Shield,
  Zap,
  Target,
  Award,
  TrendingUp,
  Heart,
  Code,
  Palette,
  Rocket,
  Mail,
  MapPin,
  Calendar,
  ExternalLink
} from "lucide-react";
import { IMAGES } from "@/assets/images";

export default function AboutPage() {
  const navigate = useNavigate();

  const stats = [
    { label: "設立年", value: "2025", icon: Calendar },
    { label: "プロダクト数", value: "10+", icon: Code },
    { label: "ユーザー数", value: "50K+", icon: Users },
    { label: "取引量", value: "$2.4M", icon: TrendingUp }
  ];

  const values = [
    {
      icon: Shield,
      title: "セキュリティファースト",
      description: "ユーザーの資産とプライバシーを最優先に考えた設計"
    },
    {
      icon: Zap,
      title: "革新的技術",
      description: "最新のWeb3技術を活用した次世代プラットフォーム"
    },
    {
      icon: Heart,
      title: "ユーザー中心",
      description: "使いやすさと美しさを両立したユーザー体験"
    },
    {
      icon: Globe,
      title: "グローバル展開",
      description: "世界中のユーザーに価値を提供するプラットフォーム"
    }
  ];

  const team = [
    {
      name: "CEO & Founder",
      role: "最高経営責任者",
      description: "Web3業界で10年以上の経験を持つビジョナリー",
      avatar: "👨‍💼"
    },
    {
      name: "CTO",
      role: "最高技術責任者", 
      description: "ブロックチェーン技術のエキスパート",
      avatar: "👩‍💻"
    },
    {
      name: "Head of Design",
      role: "デザイン責任者",
      description: "UX/UIデザインのスペシャリスト",
      avatar: "🎨"
    },
    {
      name: "Head of Security",
      role: "セキュリティ責任者",
      description: "サイバーセキュリティの専門家",
      avatar: "🛡️"
    }
  ];

  const milestones = [
    {
      year: "2025",
      title: "CheatA Labs設立",
      description: "Web3ブラウザの開発を開始"
    },
    {
      year: "2025 Q2",
      title: "プロトタイプ完成",
      description: "初期バージョンのリリース"
    },
    {
      year: "2025 Q4",
      title: "ベータ版公開",
      description: "限定ユーザーへのベータテスト開始"
    },
    {
      year: "2026 Q1",
      title: "正式版リリース",
      description: "一般ユーザー向け正式サービス開始"
    },
    {
      year: "2026 Q2",
      title: "グローバル展開",
      description: "多言語対応と海外市場進出"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* ヘッダー */}
      <header className="bg-card border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigate("/")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              ホームに戻る
            </Button>
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 flex items-center justify-center">
                <img 
                  src="/images/777.png" 
                  alt="CheatA Labs Logo" 
                  className="w-10 h-10 object-contain drop-shadow-md z-10"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                    if (fallback) fallback.style.display = 'flex';
                  }}
                />
                <div 
                  className="absolute inset-0 w-auto h-10 flex items-center justify-center text-lg font-bold tracking-tight"
                  style={{ 
                    display: 'none',
                    background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 50%, #1e3a8a 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text'
                  }}
                >
                  CheatA
                </div>
              </div>
              <div className="font-brand text-2xl font-bold text-primary">
                🏢 CheatA Labs について
              </div>
            </div>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            Web3の未来を創造する革新的なテクノロジー企業。
            次世代ブラウザとDAppsプラットフォームの開発に取り組んでいます。
          </p>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-6 py-12">
        {/* 企業概要 */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16"
        >
          <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-3xl p-8 md:p-12 border border-primary/20">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold mb-4">CheatA Labs</h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                私たちは、Web3技術を活用して次世代のインターネット体験を創造する革新的なテクノロジー企業です。
                ユーザーファーストの思想のもと、美しく使いやすいプロダクトを開発しています。
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center p-6 bg-card rounded-xl border"
                >
                  <stat.icon className="w-8 h-8 mx-auto mb-3 text-primary" />
                  <div className="text-3xl font-bold mb-2">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>

        {/* ミッション・ビジョン */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-16"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-card rounded-2xl p-8 border">
              <div className="flex items-center gap-3 mb-6">
                <Target className="w-8 h-8 text-primary" />
                <h2 className="text-2xl font-bold">ミッション</h2>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                Web3技術を通じて、より自由で安全なインターネットを実現する。
                ユーザーが自分のデータと資産を完全にコントロールできる世界を創造し、
                誰もが平等にデジタル経済に参加できる環境を提供します。
              </p>
            </div>

            <div className="bg-card rounded-2xl p-8 border">
              <div className="flex items-center gap-3 mb-6">
                <Rocket className="w-8 h-8 text-primary" />
                <h2 className="text-2xl font-bold">ビジョン</h2>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                2030年までに、世界で最も愛されるWeb3プラットフォームになる。
                革新的な技術と美しいデザインを組み合わせ、
                10億人のユーザーにWeb3の価値を届けることを目指します。
              </p>
            </div>
          </div>
        </motion.section>

        {/* 企業価値観 */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">私たちの価値観</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              CheatA Labsが大切にする4つの核となる価値観
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + index * 0.1 }}
                className="bg-card rounded-2xl p-8 border hover:shadow-lg transition-all"
              >
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                    <value.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold">{value.title}</h3>
                </div>
                <p className="text-muted-foreground">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* チーム */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">リーダーシップチーム</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              各分野のエキスパートが集結したプロフェッショナルチーム
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {team.map((member, index) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 + index * 0.1 }}
                className="bg-card rounded-2xl p-6 border text-center hover:shadow-lg transition-all"
              >
                <div className="text-6xl mb-4">{member.avatar}</div>
                <h3 className="font-semibold text-lg mb-1">{member.name}</h3>
                <p className="text-primary text-sm mb-3">{member.role}</p>
                <p className="text-muted-foreground text-sm">{member.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* 沿革 */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">会社沿革</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              CheatA Labsの成長の軌跡
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              {milestones.map((milestone, index) => (
                <motion.div
                  key={milestone.year}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.8 + index * 0.1 }}
                  className="flex items-center gap-8"
                >
                  <div className="w-24 text-right">
                    <div className="text-lg font-bold text-primary">{milestone.year}</div>
                  </div>
                  <div className="w-4 h-4 bg-primary rounded-full flex-shrink-0" />
                  <div className="flex-1 bg-card rounded-xl p-6 border">
                    <h3 className="font-semibold text-lg mb-2">{milestone.title}</h3>
                    <p className="text-muted-foreground">{milestone.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>

        {/* 会社情報 */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0 }}
          className="mb-16"
        >
          <div className="bg-card rounded-2xl p-8 border">
            <h2 className="text-2xl font-bold mb-8 text-center">会社情報</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <Building2 className="w-5 h-5 text-primary mt-1" />
                  <div>
                    <div className="font-semibold mb-1">会社名</div>
                    <div className="text-muted-foreground">CheatA Labs株式会社</div>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Calendar className="w-5 h-5 text-primary mt-1" />
                  <div>
                    <div className="font-semibold mb-1">設立</div>
                    <div className="text-muted-foreground">2025年1月</div>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <MapPin className="w-5 h-5 text-primary mt-1" />
                  <div>
                    <div className="font-semibold mb-1">本社所在地</div>
                    <div className="text-muted-foreground">東京都渋谷区</div>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <Users className="w-5 h-5 text-primary mt-1" />
                  <div>
                    <div className="font-semibold mb-1">従業員数</div>
                    <div className="text-muted-foreground">25名（2026年2月現在）</div>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Code className="w-5 h-5 text-primary mt-1" />
                  <div>
                    <div className="font-semibold mb-1">事業内容</div>
                    <div className="text-muted-foreground">Web3ブラウザ・DAppsプラットフォーム開発</div>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Mail className="w-5 h-5 text-primary mt-1" />
                  <div>
                    <div className="font-semibold mb-1">お問い合わせ</div>
                    <div className="text-muted-foreground">contact@cheata-labs.com</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.section>

        {/* CTA */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className="text-center"
        >
          <div className="bg-gradient-to-r from-primary to-accent rounded-2xl p-8 text-white">
            <h2 className="text-2xl font-bold mb-4">一緒にWeb3の未来を創造しませんか？</h2>
            <p className="mb-6 opacity-90">
              CheatA Labsでは、革新的なプロダクトを一緒に作り上げる仲間を募集しています
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90">
                採用情報を見る
              </Button>
              <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10">
                <ExternalLink className="w-4 h-4 mr-2" />
                お問い合わせ
              </Button>
            </div>
          </div>
        </motion.section>
      </main>
    </div>
  );
}