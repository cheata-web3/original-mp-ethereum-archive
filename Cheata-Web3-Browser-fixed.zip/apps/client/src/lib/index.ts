export const ROUTE_PATHS = {
  HOME: '/',
  FEATURE_DETAIL: '/feature/:id',
  DEMO: '/demo',
  BEST_PRACTICES: '/best-practices',
  COMMUNICATION: '/communication',
  DOWNLOAD: '/download',
  TRY_NOW: '/try-now',
  TOKEN_ECONOMICS: '/token-economics',
  REVENUE_FORECAST: '/revenue-forecast',
  INVESTOR_DECK: '/investor-deck',
  BUSINESS_GUIDE: '/business-guide',
  DAPPS_BUILDER: '/dapps-builder',
  MP_WALLET: '/mp-wallet',
  ABOUT: '/about',
  POLYGON_WALLET: '/polygon-wallet',
  MP_COIN_SWAP: '/mp-coin-swap',
  NFT_MARKETPLACE_TEMPLATE: '/templates/nft-marketplace',
  DEX_TEMPLATE: '/templates/dex',
  DAO_TEMPLATE: '/templates/dao',
  GAMING_PLATFORM_TEMPLATE: '/templates/gaming-platform',
  MP_STAKING: '/mp-staking',
  MP_DEFI_DASHBOARD: '/mp-defi-dashboard',
  MP_ANALYTICS: '/mp-analytics',
  MP_COMMUNITY: '/mp-community',
} as const;

export interface Feature {
  id: string;
  title: string;
  description: string;
  value: string;
  icon: string;
  label: string;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  btnText: string;
  badge?: string;
  category: 'communication' | 'web3' | 'creative';
}

export interface RevenueModel {
  id: string;
  title: string;
  description: string;
  icon: string;
  type: 'browser' | 'user';
}

export interface TokenInfo {
  id: string;
  name: string;
  value: string;
  icon: string;
  btnText: string;
  isPrimary?: boolean;
}

/**
 * Utility to concatenate class names (simplified version of clsx)
 */
export function cn(...classes: (string | boolean | undefined | null)[]) {
  return classes.filter(Boolean).join(' ');
}

/**
 * Formats token amounts for display in the Japanese locale
 */
export function formatTokenAmount(amount: number): string {
  return new Intl.NumberFormat('ja-JP', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}