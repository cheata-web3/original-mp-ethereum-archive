const { app, BrowserWindow, WebContentsView, ipcMain, session, shell } = require('electron');
const path = require('node:path');

const CHEATA_HOME = process.env.CHEATA_HOME_URL || 'https://app.cheata.win/home';
let mainWindow;
let pageView;

function isAllowedUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' || (url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname));
  } catch {
    return false;
  }
}

function navigate(value) {
  if (!pageView || !isAllowedUrl(value)) return false;
  pageView.webContents.loadURL(value);
  return true;
}

function sendState() {
  if (!mainWindow || !pageView) return;
  mainWindow.webContents.send('browser:state', {
    url: pageView.webContents.getURL(),
    title: pageView.webContents.getTitle(),
    canGoBack: pageView.webContents.canGoBack(),
    canGoForward: pageView.webContents.canGoForward()
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1000,
    minHeight: 700,
    backgroundColor: '#f7f9fc',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'shell.html'));

  pageView = new WebContentsView({
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true
    }
  });
  mainWindow.contentView.addChildView(pageView);

  const resize = () => {
    const [width, height] = mainWindow.getContentSize();
    pageView.setBounds({ x: 0, y: 78, width, height: Math.max(0, height - 78) });
  };
  mainWindow.on('resize', resize);
  mainWindow.webContents.on('did-finish-load', () => {
    resize();
    navigate(CHEATA_HOME);
  });

  pageView.webContents.setWindowOpenHandler(({ url }) => {
    if (isAllowedUrl(url)) {
      navigate(url);
      return { action: 'deny' };
    }
    shell.openExternal(url);
    return { action: 'deny' };
  });

  pageView.webContents.on('will-navigate', (event, url) => {
    if (!isAllowedUrl(url)) event.preventDefault();
  });
  pageView.webContents.on('did-navigate', sendState);
  pageView.webContents.on('did-navigate-in-page', sendState);
  pageView.webContents.on('page-title-updated', sendState);
  pageView.webContents.on('did-fail-load', sendState);

  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
    const url = webContents.getURL();
    try {
      const parsed = new URL(url);
      callback(parsed.protocol === 'https:' && ['notifications', 'clipboard-read', 'clipboard-sanitized-write'].includes(permission));
    } catch {
      callback(false);
    }
  });
}

ipcMain.handle('browser:navigate', (_event, url) => navigate(url));
ipcMain.handle('browser:back', () => pageView?.webContents.canGoBack() && pageView.webContents.goBack());
ipcMain.handle('browser:forward', () => pageView?.webContents.canGoForward() && pageView.webContents.goForward());
ipcMain.handle('browser:reload', () => pageView?.webContents.reload());
ipcMain.handle('browser:home', () => navigate(CHEATA_HOME));

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
