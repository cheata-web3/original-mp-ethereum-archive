const $ = (id) => document.getElementById(id);
const address = $('address');
function submit() {
  const raw = address.value.trim();
  if (!raw) return;
  const url = /^https?:\/\//i.test(raw) ? raw : `https://www.google.com/search?q=${encodeURIComponent(raw)}`;
  window.cheataBrowser.navigate(url);
}
$('addressForm').addEventListener('submit', (e) => { e.preventDefault(); submit(); });
$('back').onclick = () => window.cheataBrowser.back();
$('forward').onclick = () => window.cheataBrowser.forward();
$('reload').onclick = () => window.cheataBrowser.reload();
$('home').onclick = () => window.cheataBrowser.home();
window.cheataBrowser.onState((state) => {
  if (state.url) address.value = state.url;
  document.title = state.title ? `${state.title} — Cheata` : 'Cheata';
  $('back').disabled = !state.canGoBack;
  $('forward').disabled = !state.canGoForward;
});
