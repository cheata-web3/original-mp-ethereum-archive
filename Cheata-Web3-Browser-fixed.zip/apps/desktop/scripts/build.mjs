import { mkdir, cp, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const dist = path.join(root, 'dist');
await mkdir(dist, { recursive: true });
for (const name of ['main.cjs', 'preload.cjs', 'shell.html', 'shell.css', 'shell.js']) {
  await cp(path.join(root, name), path.join(dist, name));
}
const pkg = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'));
pkg.main = 'dist/main.cjs';
await writeFile(path.join(root, 'package.json'), JSON.stringify(pkg, null, 2) + '\n');
console.log('Cheata desktop shell prepared in apps/desktop/dist');
